/*
               File: GAM_UserHeader
        Description: GAM_User Header
             Author: GeneXus .NET Generator version 18_0_4-173650
       Generated on: 7/1/2023 0:31:39.39
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_userheader', true, function (CmpContext) {
   this.ServerClass =  "gam_userheader" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_userheader.aspx" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV16UserGUID=gx.fn.getControlValue("vUSERGUID") ;
      this.AV14PanelId=gx.fn.getControlValue("vPANELID") ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
   };
   this.s112_client=function()
   {
      /* 'LOADBUTTONSTOOLBAR' Routine */
      this.AV7ActionGroupItem =  {Id:"",Caption:"",Link:"",EventName:"",Class:"",TooltipText:"",Children:[]}  ;
      if ( gx.text.compare( this.AV9BtnToolbar , "EditUser" ) == 0 )
      {
         this.AV7ActionGroupItem.Id =  gx.getMessage( "EditUser")  ;
         this.AV7ActionGroupItem.Class =  gx.text.format( "%1 %2 %3", "action-group-option", "Button", "button-primary", "", "", "", "", "", "")  ;
         this.AV7ActionGroupItem.EventName =  gx.getMessage( "Edit")  ;
         this.AV7ActionGroupItem.Caption =  gx.getMessage( "Edit user")  ;
         this.AV7ActionGroupItem.TooltipText =  gx.getMessage( "Edit user information")  ;
      }
      else if ( gx.text.compare( this.AV9BtnToolbar , "UndeleteUser" ) == 0 )
      {
         this.AV7ActionGroupItem.Id =  gx.getMessage( "UndeleteUser")  ;
         this.AV7ActionGroupItem.Class =  gx.text.format( "%1", "action-group-option", "", "", "", "", "", "", "", "")  ;
         this.AV7ActionGroupItem.EventName =  gx.getMessage( "Undelete")  ;
         this.AV7ActionGroupItem.Caption =  gx.getMessage( "Undelete user")  ;
         this.AV7ActionGroupItem.TooltipText =  gx.getMessage( "Undelete the user")  ;
      }
      else if ( gx.text.compare( this.AV9BtnToolbar , "DeletePhysically" ) == 0 )
      {
         this.AV7ActionGroupItem.Id =  gx.getMessage( "DeletePhysically")  ;
         this.AV7ActionGroupItem.Class =  gx.text.format( "%1 %2 %3", "action-group-option", "Button", "button-primary", "", "", "", "", "", "")  ;
         this.AV7ActionGroupItem.EventName =  gx.getMessage( "DeletePhysically")  ;
         this.AV7ActionGroupItem.Caption =  gx.getMessage( "Delete permanently")  ;
         this.AV7ActionGroupItem.TooltipText =  gx.getMessage( "Permanently delete the user")  ;
      }
      else if ( gx.text.compare( this.AV9BtnToolbar , "EditRoles" ) == 0 )
      {
         this.AV7ActionGroupItem.Id =  gx.getMessage( "EditRoles")  ;
         this.AV7ActionGroupItem.Class =  gx.text.format( "%1 %2 %3", "action-group-option", "Button", "button-tertiary", "", "", "", "", "", "")  ;
         this.AV7ActionGroupItem.EventName =  gx.getMessage( "Roles")  ;
         this.AV7ActionGroupItem.Caption =  gx.getMessage( "Edit roles")  ;
         this.AV7ActionGroupItem.TooltipText =  gx.getMessage( "Edit user roles")  ;
      }
   };
   this.e13351_client=function()
   {
      /* 'Delete' Routine */
      this.clearMessages();
      this.call("gam_userentry.aspx", ["DLT", this.AV16UserGUID], null, ["Mode","UserGUID"]);
      this.refreshOutputs([{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e22352_client=function()
   {
      /* 'Undelete' Routine */
      this.clearMessages();
      this.AV17Window.Url =  gx.http.formatLink("gam_warningnotification.aspx",["user:undelete", this.AV16UserGUID])  ;
      this.AV17Window.ReturnParms =  []  ;
      this.popupOpen(this.AV17Window) ;
      this.call("gam_userentry.aspx", ["DSP", this.AV16UserGUID], null, ["Mode","UserGUID"]);
      this.refreshOutputs([{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e23352_client=function()
   {
      /* 'DeletePhysically' Routine */
      this.clearMessages();
      this.AV17Window.Url =  gx.http.formatLink("gam_warningnotification.aspx",["user:physicaldelete", this.AV16UserGUID])  ;
      this.AV17Window.ReturnParms =  []  ;
      this.popupOpen(this.AV17Window) ;
      this.call("gam_wwusers.aspx", [], null, []);
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e24352_client=function()
   {
      /* 'Roles' Routine */
      this.clearMessages();
      this.call("gam_wwuserroles.aspx", [this.AV16UserGUID], null, ["UserGUID"]);
      this.refreshOutputs([{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e25352_client=function()
   {
      /* 'Edit' Routine */
      this.clearMessages();
      this.call("gam_userentry.aspx", ["UPD", this.AV16UserGUID], null, ["Mode","UserGUID"]);
      this.refreshOutputs([{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e12351_client=function()
   {
      /* 'Change Password' Routine */
      this.clearMessages();
      this.call("gam_setpassword.aspx", [this.AV16UserGUID], null, ["UserGUID"]);
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e11351_client=function()
   {
      /* 'UserPermissions' Routine */
      this.clearMessages();
      this.call("gam_wwuserpermissions.aspx", [this.AV16UserGUID, 0], null, ["UserGUID","pApplicationId"]);
      this.refreshOutputs([{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e26351_client=function()
   {
      /* Gam_headerentry_tableback_Click Routine */
      this.clearMessages();
      this.s132_client();
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.s132_client=function()
   {
      /* 'GOBACK' Routine */
      if ( gx.text.compare( this.AV14PanelId , "user:entry" ) == 0 || gx.text.compare( this.AV14PanelId , "user:chgpwd" ) == 0 || gx.text.compare( this.AV14PanelId , "totp" ) == 0 || gx.text.compare( this.AV14PanelId , "user:deleted" ) == 0 )
      {
         this.call("gam_wwusers.aspx", [], null, []);
      }
   };
   this.e15352_client=function()
   {
      /* 'EnableDisableInRepository' Routine */
      return this.executeServerEvent("'ENABLEDISABLEINREPOSITORY'", true, null, false, false);
   };
   this.e16352_client=function()
   {
      /* 'KillSessions' Routine */
      return this.executeServerEvent("'KILLSESSIONS'", true, null, false, false);
   };
   this.e17352_client=function()
   {
      /* 'SendActivationEmail' Routine */
      return this.executeServerEvent("'SENDACTIVATIONEMAIL'", true, null, false, false);
   };
   this.e18352_client=function()
   {
      /* 'UnblockOTPCodes' Routine */
      return this.executeServerEvent("'UNBLOCKOTPCODES'", true, null, false, false);
   };
   this.e19352_client=function()
   {
      /* 'AuthenticatorApp' Routine */
      return this.executeServerEvent("'AUTHENTICATORAPP'", true, null, false, false);
   };
   this.e20352_client=function()
   {
      /* 'BlockOrUnblockUser' Routine */
      return this.executeServerEvent("'BLOCKORUNBLOCKUSER'", true, null, false, false);
   };
   this.e27352_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e28352_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47];
   this.GXLastCtrlId =47;
   this.BUTTONSTOOLBARContainer = gx.uc.getNew(this, 30, 0, "gx.ui.controls.actionGroup.dynamicItems", this.CmpContext + "BUTTONSTOOLBARContainer", "Buttonstoolbar", "BUTTONSTOOLBAR");
   var BUTTONSTOOLBARContainer = this.BUTTONSTOOLBARContainer;
   BUTTONSTOOLBARContainer.setProp("Class", "Class", "", "char");
   BUTTONSTOOLBARContainer.setProp("Enabled", "Enabled", true, "boolean");
   BUTTONSTOOLBARContainer.addV2CFunction('AV8ActionGroupItemCollection', "vACTIONGROUPITEMCOLLECTION", 'setItems');
   BUTTONSTOOLBARContainer.addC2VFunction(function(UC) { UC.ParentObject.AV8ActionGroupItemCollection=UC.getItems();gx.fn.setControlValue("vACTIONGROUPITEMCOLLECTION",UC.ParentObject.AV8ActionGroupItemCollection); });
   BUTTONSTOOLBARContainer.setProp("ItemPressed", "Itempressed", '', "str");
   BUTTONSTOOLBARContainer.setProp("Visible", "Visible", true, "bool");
   BUTTONSTOOLBARContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(BUTTONSTOOLBARContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"HEADERENTRY",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERENTRY",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERENTRY_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERENTRY_TABLEBACK",grid:0,evt:"e26351_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERENTRY_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERENTRY_TABLETITLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERENTRY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERENTRY_TXTSTATUS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GAM_HEADERENTRY_TBLTOOLBARS",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"GAM_HEADERENTRY_BUTTONSTOOLBAR_INNER",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"GAM_HEADERENTRY_MENUTABLE",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[37]={ id: 37, fld:"GAM_HEADERENTRY_MENUTOOLBAR_INNER",grid:0};
   GXValidFnc[38]={ id: 38, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[39]={ id: 39, fld:"BTNPERMISSIONS", format:0,grid:0,evt:"e11351_client", ctrltype: "textblock"};
   GXValidFnc[40]={ id: 40, fld:"BTNSENDACTIVATIONEMAIL", format:0,grid:0,evt:"e17352_client", ctrltype: "textblock"};
   GXValidFnc[41]={ id: 41, fld:"BTNCHANGEPASSWORD", format:0,grid:0,evt:"e12351_client", ctrltype: "textblock"};
   GXValidFnc[42]={ id: 42, fld:"BTNTOTPAUTHENTICATOR", format:0,grid:0,evt:"e19352_client", ctrltype: "textblock"};
   GXValidFnc[43]={ id: 43, fld:"BTNUNBLOCKOTPCODES", format:0,grid:0,evt:"e18352_client", ctrltype: "textblock"};
   GXValidFnc[44]={ id: 44, fld:"BTNUNBLOCKUSER", format:0,grid:0,evt:"e20352_client", ctrltype: "textblock"};
   GXValidFnc[45]={ id: 45, fld:"BTNKILLSESSIONS", format:0,grid:0,evt:"e16352_client", ctrltype: "textblock"};
   GXValidFnc[46]={ id: 46, fld:"BTNENABLEINREPO", format:0,grid:0,evt:"e15352_client", ctrltype: "textblock"};
   GXValidFnc[47]={ id: 47, fld:"BTNDELETEUSER", format:0,grid:0,evt:"e13351_client", ctrltype: "textblock"};
   this.AV8ActionGroupItemCollection = [ ] ;
   this.AV14PanelId = "" ;
   this.AV16UserGUID = "" ;
   this.Gx_mode = "" ;
   this.AV7ActionGroupItem = {Id:"",Caption:"",Link:"",EventName:"",Class:"",TooltipText:"",Children:[]} ;
   this.AV9BtnToolbar = "" ;
   this.AV17Window = {} ;
   this.Events = {"e15352_client": ["'ENABLEDISABLEINREPOSITORY'", true] ,"e16352_client": ["'KILLSESSIONS'", true] ,"e17352_client": ["'SENDACTIVATIONEMAIL'", true] ,"e18352_client": ["'UNBLOCKOTPCODES'", true] ,"e19352_client": ["'AUTHENTICATORAPP'", true] ,"e20352_client": ["'BLOCKORUNBLOCKUSER'", true] ,"e27352_client": ["ENTER", true] ,"e28352_client": ["CANCEL", true] ,"e13351_client": ["'DELETE'", false] ,"e22352_client": ["'UNDELETE'", false] ,"e23352_client": ["'DELETEPHYSICALLY'", false] ,"e24352_client": ["'ROLES'", false] ,"e25352_client": ["'EDIT'", false] ,"e12351_client": ["'CHANGE PASSWORD'", false] ,"e11351_client": ["'USERPERMISSIONS'", false] ,"e26351_client": ["GAM_HEADERENTRY_TABLEBACK.CLICK", false]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["'ENABLEDISABLEINREPOSITORY'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'KILLSESSIONS'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'DELETE'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'UNDELETE'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'DELETEPHYSICALLY'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[]];
   this.EvtParms["'ROLES'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'EDIT'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'CHANGE PASSWORD'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[]];
   this.EvtParms["'USERPERMISSIONS'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'SENDACTIVATIONEMAIL'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'UNBLOCKOTPCODES'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'AUTHENTICATORAPP'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["'BLOCKORUNBLOCKUSER'"] = [[{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}],[{av:'gx.fn.getCtrlProperty("BTNUNBLOCKUSER","Caption")',ctrl:'BTNUNBLOCKUSER',prop:'Caption'},{av:'AV16UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["GAM_HEADERENTRY_TABLEBACK.CLICK"] = [[{av:'AV14PanelId',fld:'vPANELID',pic:''}],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV16UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV14PanelId", "vPANELID", 0, "svchar", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV14PanelId", "vPANELID", 0, "svchar", 40, 0);
   this.setVCMap("AV16UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV16UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.Initialize( );
});
