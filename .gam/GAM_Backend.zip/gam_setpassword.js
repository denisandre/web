/*
               File: GAM_SetPassword
        Description: Set new password
             Author: GeneXus .NET Generator version 18_0_4-173650
       Generated on: 7/1/2023 0:32:28.30
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_setpassword', false, function () {
   this.ServerClass =  "gam_setpassword" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_setpassword.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV20UserGUID=gx.fn.getControlValue("vUSERGUID") ;
   };
   this.Validv_Email=function()
   {
      return this.validCliEvt("Validv_Email", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vEMAIL");
         this.AnyError  = 0;
         if ( ! ( gx.util.regExp.isMatch(this.AV21Email, "^((\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*)|(\\s*))$") ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXM_DoesNotMatchRegExp"), gx.getMessage( "Email"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s122_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e140r2_client=function()
   {
      /* 'Cancel' Routine */
      this.clearMessages();
      this.call("gam_userentry.aspx", ["DSP", this.AV20UserGUID], null, ["Mode","UserGUID"]);
      this.refreshOutputs([{av:'AV20UserGUID',fld:'vUSERGUID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e120r2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e150r1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,44,45,46,47,48,49,50,51,52,53];
   this.GXLastCtrlId =53;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"TBLCHGPWD",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_DATACARD",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"GAM_DATACARD_TABLEGENERALTITLE",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_DATACARD_TABLEDATAGENERAL",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",fmt:0,gxz:"ZV10UserName",gxold:"OV10UserName",gxvar:"AV10UserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10UserName=Value},v2c:function(){gx.fn.setControlValue("vUSERNAME",gx.O.AV10UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10UserName=this.val()},val:function(){return gx.fn.getControlValue("vUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id:30 ,lvl:0,type:"svchar",len:100,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Email,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAIL",fmt:0,gxz:"ZV21Email",gxold:"OV21Email",gxvar:"AV21Email",ucs:[],op:[],ip:[30],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV21Email=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Email=Value},v2c:function(){gx.fn.setControlValue("vEMAIL",gx.O.AV21Email,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV21Email=this.val()},val:function(){return gx.fn.getControlValue("vEMAIL")},nac:gx.falseFn,hasRVFmt:true};
   this.declareDomainHdlr( 30 , function() {
      gx.fn.setCtrlProperty("vEMAIL","Link", (!gx.fn.getCtrlProperty("vEMAIL","Enabled") ? "mailto:"+this.AV21Email : "") );
   });
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORDNEW",fmt:0,gxz:"ZV11UserPasswordNew",gxold:"OV11UserPasswordNew",gxvar:"AV11UserPasswordNew",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11UserPasswordNew=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11UserPasswordNew=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORDNEW",gx.O.AV11UserPasswordNew,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11UserPasswordNew=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORDNEW")},nac:gx.falseFn};
   this.declareDomainHdlr( 35 , function() {
   });
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id:40 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORDNEWCONF",fmt:0,gxz:"ZV12UserPasswordNewConf",gxold:"OV12UserPasswordNewConf",gxvar:"AV12UserPasswordNewConf",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12UserPasswordNewConf=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12UserPasswordNewConf=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORDNEWCONF",gx.O.AV12UserPasswordNewConf,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12UserPasswordNewConf=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORDNEWCONF")},nac:gx.falseFn};
   this.declareDomainHdlr( 40 , function() {
   });
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"TBLCHGPWDFOOTER",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"TBLCHGPWDFOOTER_TABLEBUTTONS",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"TBLCHGPWDFOOTER_BTNCANCEL",grid:0,evt:"e150r1_client"};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"TBLCHGPWDFOOTER_BTNCONFIRM",grid:0,evt:"e120r2_client",std:"ENTER"};
   this.AV10UserName = "" ;
   this.ZV10UserName = "" ;
   this.OV10UserName = "" ;
   this.AV21Email = "" ;
   this.ZV21Email = "" ;
   this.OV21Email = "" ;
   this.AV11UserPasswordNew = "" ;
   this.ZV11UserPasswordNew = "" ;
   this.OV11UserPasswordNew = "" ;
   this.AV12UserPasswordNewConf = "" ;
   this.ZV12UserPasswordNewConf = "" ;
   this.OV12UserPasswordNewConf = "" ;
   this.AV10UserName = "" ;
   this.AV21Email = "" ;
   this.AV11UserPasswordNew = "" ;
   this.AV12UserPasswordNewConf = "" ;
   this.AV20UserGUID = "" ;
   this.Events = {"e120r2_client": ["ENTER", true] ,"e150r1_client": ["CANCEL", true] ,"e140r2_client": ["'CANCEL'", false]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["ENTER"] = [[{av:'AV20UserGUID',fld:'vUSERGUID',pic:''},{av:'AV11UserPasswordNew',fld:'vUSERPASSWORDNEW',pic:''},{av:'AV12UserPasswordNewConf',fld:'vUSERPASSWORDNEWCONF',pic:''}],[{av:'gx.fn.getCtrlProperty("vUSERPASSWORDNEW","Enabled")',ctrl:'vUSERPASSWORDNEW',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vUSERPASSWORDNEWCONF","Enabled")',ctrl:'vUSERPASSWORDNEWCONF',prop:'Enabled'},{ctrl:'TBLCHGPWDFOOTER_BTNCONFIRM',prop:'Visible'},{ctrl:'TBLCHGPWDFOOTER_BTNCANCEL',prop:'Caption'},{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'CANCEL'"] = [[{av:'AV20UserGUID',fld:'vUSERGUID',pic:''}],[{av:'AV20UserGUID',fld:'vUSERGUID',pic:''}]];
   this.EvtParms["VALIDV_EMAIL"] = [[],[]];
   this.EnterCtrl = ["TBLCHGPWDFOOTER_BTNCONFIRM"];
   this.setVCMap("AV20UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV20UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.Initialize( );
   this.setComponent({id: "WCHEADER" ,GXClass: null , Prefix: "W0006" , lvl: 1 });
   this.setComponent({id: "WCGENERALUSERINFO" ,GXClass: null , Prefix: "W0009" , lvl: 1 });
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0043" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_setpassword);});
