/*
               File: GAM_ConnectionKeys
        Description: Connection keys
             Author: GeneXus .NET Generator version 18_0_4-173650
       Generated on: 7/1/2023 0:34:28.66
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_connectionkeys', false, function () {
   this.ServerClass =  "gam_connectionkeys" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_connectionkeys.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV9CurrentConnectionKey=gx.fn.getControlValue("vCURRENTCONNECTIONKEY") ;
      this.AV20pConnectionName=gx.fn.getControlValue("vPCONNECTIONNAME") ;
      this.AV12FileXML=gx.fn.getControlValue("vFILEXML") ;
      this.subGridwwsysconns_Recordcount=gx.fn.getIntegerValue("subGridwwsysconns_Recordcount",gx.thousandSeparator) ;
   };
   this.s112_client=function()
   {
      /* 'INIT FORM' Routine */
      gx.fn.setCtrlProperty("GAM_HEADERENTRY_TXTSTATUS","Visible", false );
      gx.fn.setCtrlProperty("GAM_HEADERENTRY_TXTBACK","Caption", gx.getMessage( "Back to Connections") );
      gx.fn.setCtrlProperty("GAM_HEADERENTRY_TITLE","Caption", gx.text.format( gx.getMessage( "Connection key list for %1"), gx.text.upper( this.AV20pConnectionName), "", "", "", "", "", "", "", "") );
      gx.fn.setCtrlProperty("vCONNECTIONFILEXML","Visible", false );
      gx.fn.setCtrlProperty("vFILECONNECTIONKEY","Visible", false );
      gx.fn.setCtrlProperty("GAM_FOOTERENTRY_TABLEBUTTONS","Visible", false );
      gx.fn.setCtrlProperty("GAM_FOOTERENTRY","Visible", false );
   };
   this.s122_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e18371_client=function()
   {
      /* Gam_headerentry_tableback_Click Routine */
      this.clearMessages();
      this.call("gam_wwconnections.aspx", [], null, []);
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e11372_client=function()
   {
      /* 'UseAutomaticConnKey' Routine */
      return this.executeServerEvent("'USEAUTOMATICCONNKEY'", true, null, false, false);
   };
   this.e12372_client=function()
   {
      /* 'UseCurrentConnKey' Routine */
      return this.executeServerEvent("'USECURRENTCONNKEY'", true, null, false, false);
   };
   this.e13372_client=function()
   {
      /* 'SaveNewConnKey' Routine */
      return this.executeServerEvent("'SAVENEWCONNKEY'", false, null, false, false);
   };
   this.e16372_client=function()
   {
      /* 'GenerateConnectionFile' Routine */
      return this.executeServerEvent("'GENERATECONNECTIONFILE'", true, arguments[0], false, false);
   };
   this.e17372_client=function()
   {
      /* 'DeleteConnectionKey' Routine */
      return this.executeServerEvent("'DELETECONNECTIONKEY'", true, arguments[0], false, false);
   };
   this.e19372_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e20372_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,77,78,79,80,81,82,83,84,85,86];
   this.GXLastCtrlId =86;
   this.GridwwsysconnsContainer = new gx.grid.grid(this, 2,"WbpLvl2",59,"Gridwwsysconns","Gridwwsysconns","GridwwsysconnsContainer",this.CmpContext,this.IsMasterPage,"gam_connectionkeys",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwsysconnsContainer = this.GridwwsysconnsContainer;
   GridwwsysconnsContainer.addSingleLineEdit("Connectionkey",60,"vCONNECTIONKEY",gx.getMessage( "Connection Key"),"","ConnectionKey","char",0,"px",40,40,"start",null,[],"Connectionkey","ConnectionKey",true,0,false,false,"Attribute",0,"column");
   GridwwsysconnsContainer.addSingleLineEdit("Iscurrentkey",61,"vISCURRENTKEY","","","isCurrentKey","svchar",130,"px",40,40,"start",null,[],"Iscurrentkey","isCurrentKey",true,0,false,false,"Attribute",0,"column column-optional");
   GridwwsysconnsContainer.addSingleLineEdit("Btnfile",62,"vBTNFILE","","","BtnFile","svchar",0,"px",40,40,"start","e16372_client",[],"Btnfile","BtnFile",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn");
   GridwwsysconnsContainer.addSingleLineEdit("Btndlt",63,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"start","e17372_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn");
   this.GridwwsysconnsContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwsysconnsContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERENTRY",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERENTRY_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERENTRY_TABLEBACK",grid:0,evt:"e18371_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERENTRY_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERENTRY_TABLETITLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERENTRY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERENTRY_TXTSTATUS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GAM_HEADERENTRY_TBLTOOLBARS",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"GAM_HEADERENTRY_BUTTONSTOOLBAR_INNER",grid:0};
   GXValidFnc[30]={ id: 30, fld:"BUTTONUSEAUTOMATICKEY", format:0,grid:0,evt:"e11372_client", ctrltype: "textblock"};
   GXValidFnc[31]={ id: 31, fld:"BUTTONUSECURRENTKEY", format:0,grid:0,evt:"e12372_client", ctrltype: "textblock"};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"GAM_HEADERENTRY_MENUTABLE",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"GAM_DATACARD",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"GAM_DATACARD_TABLEGENERALTITLE",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"GAM_DATACARD_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"GAM_DATACARD_TABLEDATAGENERAL",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"TABLEDATAGENERAL",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id:54 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNEWCONNECTIONKEY",fmt:0,gxz:"ZV19NewConnectionKey",gxold:"OV19NewConnectionKey",gxvar:"AV19NewConnectionKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV19NewConnectionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19NewConnectionKey=Value},v2c:function(){gx.fn.setControlValue("vNEWCONNECTIONKEY",gx.O.AV19NewConnectionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV19NewConnectionKey=this.val()},val:function(){return gx.fn.getControlValue("vNEWCONNECTIONKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 54 , function() {
   });
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"SAVENEWCONNKEY",grid:0,evt:"e13372_client"};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[60]={ id:60 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:59,gxgrid:this.GridwwsysconnsContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONNECTIONKEY",fmt:0,gxz:"ZV8ConnectionKey",gxold:"OV8ConnectionKey",gxvar:"AV8ConnectionKey",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV8ConnectionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8ConnectionKey=Value},v2c:function(row){gx.fn.setGridControlValue("vCONNECTIONKEY",row || gx.fn.currentGridRowImpl(59),gx.O.AV8ConnectionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8ConnectionKey=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vCONNECTIONKEY",row || gx.fn.currentGridRowImpl(59))},nac:gx.falseFn};
   GXValidFnc[61]={ id:61 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:59,gxgrid:this.GridwwsysconnsContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vISCURRENTKEY",fmt:0,gxz:"ZV17isCurrentKey",gxold:"OV17isCurrentKey",gxvar:"AV17isCurrentKey",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV17isCurrentKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17isCurrentKey=Value},v2c:function(row){gx.fn.setGridControlValue("vISCURRENTKEY",row || gx.fn.currentGridRowImpl(59),gx.O.AV17isCurrentKey,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17isCurrentKey=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vISCURRENTKEY",row || gx.fn.currentGridRowImpl(59))},nac:gx.falseFn};
   GXValidFnc[62]={ id:62 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:59,gxgrid:this.GridwwsysconnsContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNFILE",fmt:0,gxz:"ZV6BtnFile",gxold:"OV6BtnFile",gxvar:"AV6BtnFile",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnFile=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnFile=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNFILE",row || gx.fn.currentGridRowImpl(59),gx.O.AV6BtnFile,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnFile=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNFILE",row || gx.fn.currentGridRowImpl(59))},nac:gx.falseFn,evt:"e16372_client"};
   GXValidFnc[63]={ id:63 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:59,gxgrid:this.GridwwsysconnsContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV5BtnDlt",gxold:"OV5BtnDlt",gxvar:"AV5BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(59),gx.O.AV5BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(59))},nac:gx.falseFn,evt:"e17372_client"};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id:68 ,lvl:0,type:"char",len:2048,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONNECTIONFILEXML",fmt:0,gxz:"ZV7ConnectionFileXML",gxold:"OV7ConnectionFileXML",gxvar:"AV7ConnectionFileXML",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7ConnectionFileXML=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7ConnectionFileXML=Value},v2c:function(){gx.fn.setControlValue("vCONNECTIONFILEXML",gx.O.AV7ConnectionFileXML,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV7ConnectionFileXML=this.val()},val:function(){return gx.fn.getControlValue("vCONNECTIONFILEXML")},nac:gx.falseFn};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id:73 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILECONNECTIONKEY",fmt:0,gxz:"ZV11FileConnectionKey",gxold:"OV11FileConnectionKey",gxvar:"AV11FileConnectionKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11FileConnectionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11FileConnectionKey=Value},v2c:function(){gx.fn.setControlValue("vFILECONNECTIONKEY",gx.O.AV11FileConnectionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11FileConnectionKey=this.val()},val:function(){return gx.fn.getControlValue("vFILECONNECTIONKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 73 , function() {
   });
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id: 84, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e21371_client"};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e22371_client"};
   this.AV19NewConnectionKey = "" ;
   this.ZV19NewConnectionKey = "" ;
   this.OV19NewConnectionKey = "" ;
   this.ZV8ConnectionKey = "" ;
   this.OV8ConnectionKey = "" ;
   this.ZV17isCurrentKey = "" ;
   this.OV17isCurrentKey = "" ;
   this.ZV6BtnFile = "" ;
   this.OV6BtnFile = "" ;
   this.ZV5BtnDlt = "" ;
   this.OV5BtnDlt = "" ;
   this.AV7ConnectionFileXML = "" ;
   this.ZV7ConnectionFileXML = "" ;
   this.OV7ConnectionFileXML = "" ;
   this.AV11FileConnectionKey = "" ;
   this.ZV11FileConnectionKey = "" ;
   this.OV11FileConnectionKey = "" ;
   this.AV19NewConnectionKey = "" ;
   this.AV7ConnectionFileXML = "" ;
   this.AV11FileConnectionKey = "" ;
   this.AV20pConnectionName = "" ;
   this.AV8ConnectionKey = "" ;
   this.AV17isCurrentKey = "" ;
   this.AV6BtnFile = "" ;
   this.AV5BtnDlt = "" ;
   this.AV9CurrentConnectionKey = "" ;
   this.AV12FileXML = "" ;
   this.Events = {"e11372_client": ["'USEAUTOMATICCONNKEY'", true] ,"e12372_client": ["'USECURRENTCONNKEY'", true] ,"e13372_client": ["'SAVENEWCONNKEY'", true] ,"e16372_client": ["'GENERATECONNECTIONFILE'", true] ,"e17372_client": ["'DELETECONNECTIONKEY'", true] ,"e19372_client": ["ENTER", true] ,"e20372_client": ["CANCEL", true] ,"e18371_client": ["GAM_HEADERENTRY_TABLEBACK.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWWSYSCONNS_nFirstRecordOnPage'},{av:'GRIDWWSYSCONNS_nEOF'},{av:'AV9CurrentConnectionKey',fld:'vCURRENTCONNECTIONKEY',pic:'',hsh:true},{av:'AV12FileXML',fld:'vFILEXML',pic:'',hsh:true},{av:'AV20pConnectionName',fld:'vPCONNECTIONNAME',pic:'',hsh:true}],[]];
   this.EvtParms["GRIDWWSYSCONNS.LOAD"] = [[{av:'AV9CurrentConnectionKey',fld:'vCURRENTCONNECTIONKEY',pic:'',hsh:true},{av:'AV20pConnectionName',fld:'vPCONNECTIONNAME',pic:'',hsh:true}],[{av:'AV8ConnectionKey',fld:'vCONNECTIONKEY',pic:'',hsh:true},{av:'AV17isCurrentKey',fld:'vISCURRENTKEY',pic:''},{av:'AV6BtnFile',fld:'vBTNFILE',pic:''},{av:'AV5BtnDlt',fld:'vBTNDLT',pic:''},{av:'gx.fn.getCtrlProperty("BUTTONUSECURRENTKEY","Visible")',ctrl:'BUTTONUSECURRENTKEY',prop:'Visible'}]];
   this.EvtParms["'USEAUTOMATICCONNKEY'"] = [[],[{av:'AV19NewConnectionKey',fld:'vNEWCONNECTIONKEY',pic:''}]];
   this.EvtParms["'USECURRENTCONNKEY'"] = [[{av:'AV9CurrentConnectionKey',fld:'vCURRENTCONNECTIONKEY',pic:'',hsh:true}],[{av:'AV19NewConnectionKey',fld:'vNEWCONNECTIONKEY',pic:''}]];
   this.EvtParms["'SAVENEWCONNKEY'"] = [[{av:'GRIDWWSYSCONNS_nFirstRecordOnPage'},{av:'GRIDWWSYSCONNS_nEOF'},{av:'AV9CurrentConnectionKey',fld:'vCURRENTCONNECTIONKEY',pic:'',hsh:true},{av:'AV20pConnectionName',fld:'vPCONNECTIONNAME',pic:'',hsh:true},{av:'AV12FileXML',fld:'vFILEXML',pic:'',hsh:true},{av:'AV19NewConnectionKey',fld:'vNEWCONNECTIONKEY',pic:''}],[{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'GENERATECONNECTIONFILE'"] = [[{av:'AV11FileConnectionKey',fld:'vFILECONNECTIONKEY',pic:''},{av:'AV8ConnectionKey',fld:'vCONNECTIONKEY',pic:'',hsh:true},{av:'AV20pConnectionName',fld:'vPCONNECTIONNAME',pic:'',hsh:true},{av:'AV12FileXML',fld:'vFILEXML',pic:'',hsh:true}],[{av:'AV7ConnectionFileXML',fld:'vCONNECTIONFILEXML',pic:''},{av:'AV11FileConnectionKey',fld:'vFILECONNECTIONKEY',pic:''},{av:'gx.fn.getCtrlProperty("vCONNECTIONFILEXML","Visible")',ctrl:'vCONNECTIONFILEXML',prop:'Visible'},{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'DELETECONNECTIONKEY'"] = [[{av:'GRIDWWSYSCONNS_nFirstRecordOnPage'},{av:'GRIDWWSYSCONNS_nEOF'},{av:'AV9CurrentConnectionKey',fld:'vCURRENTCONNECTIONKEY',pic:'',hsh:true},{av:'AV20pConnectionName',fld:'vPCONNECTIONNAME',pic:'',hsh:true},{av:'AV12FileXML',fld:'vFILEXML',pic:'',hsh:true},{av:'AV8ConnectionKey',fld:'vCONNECTIONKEY',pic:'',hsh:true}],[{ctrl:'WCMESSAGES'}]];
   this.EvtParms["GAM_HEADERENTRY_TABLEBACK.CLICK"] = [[],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV9CurrentConnectionKey", "vCURRENTCONNECTIONKEY", 0, "char", 40, 0);
   this.setVCMap("AV20pConnectionName", "vPCONNECTIONNAME", 0, "char", 254, 0);
   this.setVCMap("AV12FileXML", "vFILEXML", 0, "char", 2048, 0);
   this.setVCMap("AV9CurrentConnectionKey", "vCURRENTCONNECTIONKEY", 0, "char", 40, 0);
   this.setVCMap("AV20pConnectionName", "vPCONNECTIONNAME", 0, "char", 254, 0);
   this.setVCMap("AV9CurrentConnectionKey", "vCURRENTCONNECTIONKEY", 0, "char", 40, 0);
   this.setVCMap("AV20pConnectionName", "vPCONNECTIONNAME", 0, "char", 254, 0);
   GridwwsysconnsContainer.addRefreshingVar({rfrVar:"AV9CurrentConnectionKey"});
   GridwwsysconnsContainer.addRefreshingVar({rfrVar:"AV20pConnectionName"});
   GridwwsysconnsContainer.addRefreshingVar({rfrVar:"AV12FileXML"});
   GridwwsysconnsContainer.addRefreshingParm({rfrVar:"AV9CurrentConnectionKey"});
   GridwwsysconnsContainer.addRefreshingParm({rfrVar:"AV20pConnectionName"});
   GridwwsysconnsContainer.addRefreshingParm({rfrVar:"AV12FileXML"});
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0076" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_connectionkeys);});
