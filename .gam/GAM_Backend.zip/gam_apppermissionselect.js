/*
               File: GAM_AppPermissionSelect
        Description: Select permissions
             Author: GeneXus .NET Generator version 18_0_4-173650
       Generated on: 7/1/2023 0:33:10.87
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_apppermissionselect', false, function () {
   this.ServerClass =  "gam_apppermissionselect" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_apppermissionselect.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV7ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV19PermissionId=gx.fn.getControlValue("vPERMISSIONID") ;
      this.AV17isOK=gx.fn.getControlValue("vISOK") ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.Validv_Accesstype=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(22);
      return this.validCliEvt("Validv_Accesstype", 22, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vACCESSTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV21AccessType , "A" ) == 0 || gx.text.compare( this.AV21AccessType , "R" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Default Access"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s112_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e111f2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e121f2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e151f2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e161f2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23,24,25,26,27,28,29,30,32,33,34,35,36,37,38,39,40,41];
   this.GXLastCtrlId =41;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",22,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_apppermissionselect",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,true,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addCheckBox("Select",23,"vSELECT",gx.getMessage( "Select"),"","Select","boolean","true","false",null,true,false,60,"px","");
   GridwwContainer.addSingleLineEdit("Name",24,"vNAME",gx.getMessage( "Permission name"),"","Name","char",0,"px",254,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Dsc",25,"vDSC",gx.getMessage( "Description"),"","Dsc","char",0,"px",254,80,"start",null,[],"Dsc","Dsc",true,0,false,false,"Attribute",0,"column column-optional");
   GridwwContainer.addComboBox("Accesstype",26,"vACCESSTYPE",gx.getMessage( "Default Access"),"AccessType","char",null,0,true,false,130,"px","column column-optional");
   GridwwContainer.addSingleLineEdit("Id",27,"vID",gx.getMessage( "GUID"),"","Id","char",0,"px",40,40,"start",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   GridwwContainer.addSingleLineEdit("Appid",28,"vAPPID",gx.getMessage( "Key Numeric Long"),"","AppId","int",0,"px",12,12,"end",null,[],"Appid","AppId",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWNOFILTERS",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWNOFILTERS_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_HEADERWWNOFILTERS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_HEADERWWNOFILTERS_ADDNEW",grid:0,evt:"e171f1_client"};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV22Search",gxold:"OV22Search",gxvar:"AV22Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV22Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV22Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV22Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV22Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"GRIDCONTAINER",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[23]={ id:23 ,lvl:2,type:"boolean",len:4,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSELECT",fmt:0,gxz:"ZV20Select",gxold:"OV20Select",gxvar:"AV20Select",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV20Select=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV20Select=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vSELECT",row || gx.fn.currentGridRowImpl(22),gx.O.AV20Select,true)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV20Select=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vSELECT",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[24]={ id:24 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV18Name",gxold:"OV18Name",gxvar:"AV18Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV18Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(22),gx.O.AV18Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV18Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn};
   GXValidFnc[25]={ id:25 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV11Dsc",gxold:"OV11Dsc",gxvar:"AV11Dsc",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Dsc=Value},v2c:function(row){gx.fn.setGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(22),gx.O.AV11Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11Dsc=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:this.Validv_Accesstype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCESSTYPE",fmt:0,gxz:"ZV21AccessType",gxold:"OV21AccessType",gxvar:"AV21AccessType",ucs:[],op:[26],ip:[26],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV21AccessType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21AccessType=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(22),gx.O.AV21AccessType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV21AccessType=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV16Id",gxold:"OV16Id",gxvar:"AV16Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV16Id=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Id=Value},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(22),gx.O.AV16Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16Id=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vID",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAPPID",fmt:0,gxz:"ZV6AppId",gxold:"OV6AppId",gxvar:"AV6AppId",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV6AppId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV6AppId=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vAPPID",row || gx.fn.currentGridRowImpl(22),gx.O.AV6AppId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6AppId=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vAPPID",row || gx.fn.currentGridRowImpl(22),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e121f2_client"};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e111f2_client"};
   this.AV22Search = "" ;
   this.ZV22Search = "" ;
   this.OV22Search = "" ;
   this.ZV20Select = false ;
   this.OV20Select = false ;
   this.ZV18Name = "" ;
   this.OV18Name = "" ;
   this.ZV11Dsc = "" ;
   this.OV11Dsc = "" ;
   this.ZV21AccessType = "" ;
   this.OV21AccessType = "" ;
   this.ZV16Id = "" ;
   this.OV16Id = "" ;
   this.ZV6AppId = 0 ;
   this.OV6AppId = 0 ;
   this.AV22Search = "" ;
   this.AV7ApplicationId = 0 ;
   this.AV19PermissionId = "" ;
   this.AV20Select = false ;
   this.AV18Name = "" ;
   this.AV11Dsc = "" ;
   this.AV21AccessType = "" ;
   this.AV16Id = "" ;
   this.AV6AppId = 0 ;
   this.AV17isOK = false ;
   this.Events = {"e111f2_client": ["'CONFIRM'", true] ,"e121f2_client": ["'CANCEL'", true] ,"e151f2_client": ["ENTER", true] ,"e161f2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV22Search',fld:'vSEARCH',pic:''},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV19PermissionId',fld:'vPERMISSIONID',pic:'',hsh:true}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV19PermissionId',fld:'vPERMISSIONID',pic:'',hsh:true},{av:'AV22Search',fld:'vSEARCH',pic:''}],[{ctrl:'FORM',prop:'Caption'},{av:'AV6AppId',fld:'vAPPID',pic:'ZZZZZZZZZZZ9'},{av:'AV16Id',fld:'vID',pic:'',hsh:true},{av:'AV18Name',fld:'vNAME',pic:''},{av:'AV11Dsc',fld:'vDSC',pic:''},{ctrl:'vACCESSTYPE'},{av:'AV21AccessType',fld:'vACCESSTYPE',pic:''}]];
   this.EvtParms["'CONFIRM'"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV20Select',fld:'vSELECT',grid:22,pic:''},{av:'GRIDWW_nFirstRecordOnPage'},{av:'nRC_GXsfl_22',ctrl:'GRIDWW',grid:22,prop:'GridRC',grid:22},{av:'AV19PermissionId',fld:'vPERMISSIONID',pic:'',hsh:true},{av:'AV16Id',fld:'vID',grid:22,pic:'',hsh:true},{av:'AV17isOK',fld:'vISOK',pic:''}],[{av:'AV17isOK',fld:'vISOK',pic:''},{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'CANCEL'"] = [[{av:'AV19PermissionId',fld:'vPERMISSIONID',pic:'',hsh:true},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV19PermissionId',fld:'vPERMISSIONID',pic:'',hsh:true},{av:'AV22Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV19PermissionId',fld:'vPERMISSIONID',pic:'',hsh:true},{av:'AV22Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV19PermissionId',fld:'vPERMISSIONID',pic:'',hsh:true},{av:'AV22Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV19PermissionId',fld:'vPERMISSIONID',pic:'',hsh:true},{av:'AV22Search',fld:'vSEARCH',pic:''},{av:'subGridww_Recordcount'}],[]];
   this.EvtParms["VALIDV_ACCESSTYPE"] = [[{ctrl:'vACCESSTYPE'},{av:'AV21AccessType',fld:'vACCESSTYPE',pic:''}],[{ctrl:'vACCESSTYPE'},{av:'AV21AccessType',fld:'vACCESSTYPE',pic:''}]];
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV19PermissionId", "vPERMISSIONID", 0, "char", 40, 0);
   this.setVCMap("AV17isOK", "vISOK", 0, "boolean", 4, 0);
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV19PermissionId", "vPERMISSIONID", 0, "char", 40, 0);
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV19PermissionId", "vPERMISSIONID", 0, "char", 40, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV7ApplicationId"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV19PermissionId"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV7ApplicationId"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV19PermissionId"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[16]);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0031" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_apppermissionselect);});
