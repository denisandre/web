/*
               File: GAM_RepositoryConfiguration
        Description: Repository configuration
             Author: GeneXus .NET Generator version 18_0_4-173650
       Generated on: 7/1/2023 0:33:5.7
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_repositoryconfiguration', false, function () {
   this.ServerClass =  "gam_repositoryconfiguration" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_repositoryconfiguration.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV40SecurityAdministratorEmail=gx.fn.getControlValue("vSECURITYADMINISTRATOREMAIL") ;
      this.AV8CanRegisterUsers=gx.fn.getControlValue("vCANREGISTERUSERS") ;
      this.AV22Id=gx.fn.getIntegerValue("vID",gx.thousandSeparator) ;
   };
   this.Validv_Logoutbehavior=function()
   {
      return this.validCliEvt("Validv_Logoutbehavior", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vLOGOUTBEHAVIOR");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV27LogoutBehavior , "clionl" ) == 0 || gx.text.compare( this.AV27LogoutBehavior , "cliip" ) == 0 || gx.text.compare( this.AV27LogoutBehavior , "all" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "SSO logout behavior"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Enabletracing=function()
   {
      return this.validCliEvt("Validv_Enabletracing", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vENABLETRACING");
         this.AnyError  = 0;
         if ( ! ( ( this.AV13EnableTracing == 0 ) || ( this.AV13EnableTracing == 1 ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Enable tracing"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Useridentification=function()
   {
      return this.validCliEvt("Validv_Useridentification", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERIDENTIFICATION");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV47UserIdentification , "name" ) == 0 || gx.text.compare( this.AV47UserIdentification , "email" ) == 0 || gx.text.compare( this.AV47UserIdentification , "namema" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User identification by"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Useractivationmethod=function()
   {
      return this.validCliEvt("Validv_Useractivationmethod", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERACTIVATIONMETHOD");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV44UserActivationMethod , "A" ) == 0 || gx.text.compare( this.AV44UserActivationMethod , "U" ) == 0 || gx.text.compare( this.AV44UserActivationMethod , "D" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User activation method"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Userremembermetype=function()
   {
      return this.validCliEvt("Validv_Userremembermetype", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERREMEMBERMETYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV50UserRememberMeType , "None" ) == 0 || gx.text.compare( this.AV50UserRememberMeType , "Login" ) == 0 || gx.text.compare( this.AV50UserRememberMeType , "Auth" ) == 0 || gx.text.compare( this.AV50UserRememberMeType , "Both" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User remember me type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Generatesessionstatistics=function()
   {
      return this.validCliEvt("Validv_Generatesessionstatistics", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vGENERATESESSIONSTATISTICS");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV19GenerateSessionStatistics , "None" ) == 0 || gx.text.compare( this.AV19GenerateSessionStatistics , "Minimum" ) == 0 || gx.text.compare( this.AV19GenerateSessionStatistics , "Detail" ) == 0 || gx.text.compare( this.AV19GenerateSessionStatistics , "Full" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Generate session statistics?"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Intsecbydomainmode=function()
   {
      return this.validCliEvt("Validv_Intsecbydomainmode", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vINTSECBYDOMAINMODE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV87IntSecByDomainMode , "server" ) == 0 || gx.text.compare( this.AV87IntSecByDomainMode , "client" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Integrated security by domain mode"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s112_client=function()
   {
      /* 'VALIDVIEWEMAILSCONFIGURATIONS' Routine */
      if ( gx.text.compare( this.AV47UserIdentification , "email" ) == 0 || gx.text.compare( this.AV47UserIdentification , "namema" ) == 0 )
      {
         this.AV46UserEmailisUnique =  true  ;
         this.AV34RequiredEmail =  true  ;
         gx.fn.setCtrlProperty("CELLUSEREMAILUNIQUE","Visible", false );
         gx.fn.setCtrlProperty("CELLUSERREQUIEREDEMAIL","Visible", false );
      }
      else
      {
         gx.fn.setCtrlProperty("CELLUSEREMAILUNIQUE","Visible", true );
         gx.fn.setCtrlProperty("CELLUSERREQUIEREDEMAIL","Visible", true );
      }
   };
   this.s122_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e150d1_client=function()
   {
      /* Useridentification_Controlvaluechanged Routine */
      this.clearMessages();
      this.s112_client();
      this.refreshOutputs([{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'gx.fn.getCtrlProperty("CELLUSEREMAILUNIQUE","Visible")',ctrl:'CELLUSEREMAILUNIQUE',prop:'Visible'},{av:'gx.fn.getCtrlProperty("CELLUSERREQUIEREDEMAIL","Visible")',ctrl:'CELLUSERREQUIEREDEMAIL',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e160d1_client=function()
   {
      /* Emailserverusesauthentication_Click Routine */
      this.clearMessages();
      if ( this.AV74EmailServerUsesAuthentication )
      {
         gx.fn.setCtrlProperty("vEMAILSERVERAUTHENTICATIONUSERNAME","Visible", true );
         gx.fn.setCtrlProperty("vEMAILSERVERAUTHENTICATIONUSERPASSWORD","Visible", true );
      }
      else
      {
         gx.fn.setCtrlProperty("vEMAILSERVERAUTHENTICATIONUSERNAME","Visible", false );
         gx.fn.setCtrlProperty("vEMAILSERVERAUTHENTICATIONUSERPASSWORD","Visible", false );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("vEMAILSERVERAUTHENTICATIONUSERNAME","Visible")',ctrl:'vEMAILSERVERAUTHENTICATIONUSERNAME',prop:'Visible'},{av:'gx.fn.getCtrlProperty("vEMAILSERVERAUTHENTICATIONUSERPASSWORD","Visible")',ctrl:'vEMAILSERVERAUTHENTICATIONUSERPASSWORD',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e170d1_client=function()
   {
      /* Emailserver_sendemailwhenuseractivateaccount_Click Routine */
      this.clearMessages();
      if ( this.AV65EmailServer_SendEmailWhenUserActivateAccount )
      {
         gx.fn.setCtrlProperty("TBLUSERACTIVATEACCOUNT","Visible", true );
      }
      else
      {
         gx.fn.setCtrlProperty("TBLUSERACTIVATEACCOUNT","Visible", false );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBLUSERACTIVATEACCOUNT","Visible")',ctrl:'TBLUSERACTIVATEACCOUNT',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e180d1_client=function()
   {
      /* Emailserver_sendemailwhenuserchangepassword_Click Routine */
      this.clearMessages();
      if ( this.AV67EmailServer_SendEmailWhenUserChangePassword )
      {
         gx.fn.setCtrlProperty("TBLUSERCHANGEPASSWORD","Visible", true );
      }
      else
      {
         gx.fn.setCtrlProperty("TBLUSERCHANGEPASSWORD","Visible", false );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBLUSERCHANGEPASSWORD","Visible")',ctrl:'TBLUSERCHANGEPASSWORD',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e190d1_client=function()
   {
      /* Emailserver_sendemailwhenuserchangeemail_Click Routine */
      this.clearMessages();
      if ( this.AV66EmailServer_SendEmailWhenUserChangeEmail )
      {
         gx.fn.setCtrlProperty("TBLUSERCHANGEEMAIL","Visible", true );
      }
      else
      {
         gx.fn.setCtrlProperty("TBLUSERCHANGEEMAIL","Visible", false );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBLUSERCHANGEEMAIL","Visible")',ctrl:'TBLUSERCHANGEEMAIL',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e200d1_client=function()
   {
      /* Emailserver_sendemailforrecoverypassword_Click Routine */
      this.clearMessages();
      if ( this.AV64EmailServer_SendEmailForRecoveryPassword )
      {
         gx.fn.setCtrlProperty("TBLUSERRECOVERYPASSWORD","Visible", true );
      }
      else
      {
         gx.fn.setCtrlProperty("TBLUSERRECOVERYPASSWORD","Visible", false );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBLUSERRECOVERYPASSWORD","Visible")',ctrl:'TBLUSERRECOVERYPASSWORD',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e210d1_client=function()
   {
      /* Intsecbydomainenable_Click Routine */
      this.clearMessages();
      if ( this.AV88IntSecByDomainEnable )
      {
         gx.fn.setCtrlProperty("TBLINTSECBYDOMAIN","Visible", true );
      }
      else
      {
         gx.fn.setCtrlProperty("TBLINTSECBYDOMAIN","Visible", false );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBLINTSECBYDOMAIN","Visible")',ctrl:'TBLINTSECBYDOMAIN',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e120d2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e130d2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e220d2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e230d2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,35,36,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,114,115,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,209,210,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,277,278,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,417,418,419,420,421,422,423,424,425,426];
   this.GXLastCtrlId =426;
   this.TABREPOContainer = gx.uc.getNew(this, 33, 0, "gx.ui.controls.BasicTab", "TABREPOContainer", "Tabrepo", "TABREPO");
   var TABREPOContainer = this.TABREPOContainer;
   TABREPOContainer.setProp("Enabled", "Enabled", true, "boolean");
   TABREPOContainer.setProp("ActivePage", "Activepage", '', "int");
   TABREPOContainer.setProp("ActivePageControlName", "Activepagecontrolname", "", "char");
   TABREPOContainer.setProp("PageCount", "Pagecount", 4, "num");
   TABREPOContainer.setProp("Class", "Class", "Tab", "str");
   TABREPOContainer.setProp("HistoryManagement", "Historymanagement", false, "bool");
   TABREPOContainer.setProp("Visible", "Visible", true, "bool");
   TABREPOContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(TABREPOContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERENTRY",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERENTRY_TBLBACKCONTAINER",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERENTRY_TBLBACK",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERENTRY_IMGBACK",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"GAM_HEADERENTRY_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERENTRY_TABLETITLEACTIONS",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERENTRY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GAM_HEADERENTRY_TXTSTATUS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"GAM_HEADERENTRY_TBLTOOLBARS",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"GAM_HEADERENTRY_MENUTABLE",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"GENERAL_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"TABPAGE1TABLE",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id:43 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREPOID",fmt:0,gxz:"ZV77RepoId",gxold:"OV77RepoId",gxvar:"AV77RepoId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV77RepoId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV77RepoId=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vREPOID",gx.O.AV77RepoId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV77RepoId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vREPOID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 43 , function() {
   });
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id:48 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",fmt:0,gxz:"ZV21GUID",gxold:"OV21GUID",gxvar:"AV21GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV21GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV21GUID,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV21GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id:53 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAMESPACE",fmt:0,gxz:"ZV30NameSpace",gxold:"OV30NameSpace",gxvar:"AV30NameSpace",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV30NameSpace=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV30NameSpace=Value},v2c:function(){gx.fn.setControlValue("vNAMESPACE",gx.O.AV30NameSpace,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV30NameSpace=this.val()},val:function(){return gx.fn.getControlValue("vNAMESPACE")},nac:gx.falseFn};
   this.declareDomainHdlr( 53 , function() {
   });
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id:58 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV29Name",gxold:"OV29Name",gxvar:"AV29Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV29Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV29Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV29Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 58 , function() {
   });
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id:63 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV12Dsc",gxold:"OV12Dsc",gxvar:"AV12Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV12Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 63 , function() {
   });
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"TBLMASTERREPO",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id:71 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAUTHENTICATIONMASTERREPOSITORY",fmt:0,gxz:"ZV55AuthenticationMasterRepository",gxold:"OV55AuthenticationMasterRepository",gxvar:"AV55AuthenticationMasterRepository",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV55AuthenticationMasterRepository=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV55AuthenticationMasterRepository=Value},v2c:function(){gx.fn.setControlValue("vAUTHENTICATIONMASTERREPOSITORY",gx.O.AV55AuthenticationMasterRepository,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV55AuthenticationMasterRepository=this.val()},val:function(){return gx.fn.getControlValue("vAUTHENTICATIONMASTERREPOSITORY")},nac:gx.falseFn};
   this.declareDomainHdlr( 71 , function() {
   });
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"TBLDONTHAVEMASTERREPO",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"DEFAULTAUTHTYPENAMECELL",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id:79 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDEFAULTAUTHTYPENAME",fmt:0,gxz:"ZV9DefaultAuthTypeName",gxold:"OV9DefaultAuthTypeName",gxvar:"AV9DefaultAuthTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV9DefaultAuthTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV9DefaultAuthTypeName=Value},v2c:function(){gx.fn.setComboBoxValue("vDEFAULTAUTHTYPENAME",gx.O.AV9DefaultAuthTypeName);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV9DefaultAuthTypeName=this.val()},val:function(){return gx.fn.getControlValue("vDEFAULTAUTHTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 79 , function() {
   });
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"DEFAULTROLEIDCELL",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id:84 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDEFAULTROLEID",fmt:0,gxz:"ZV10DefaultRoleId",gxold:"OV10DefaultRoleId",gxvar:"AV10DefaultRoleId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV10DefaultRoleId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV10DefaultRoleId=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vDEFAULTROLEID",gx.O.AV10DefaultRoleId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10DefaultRoleId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vDEFAULTROLEID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 84 , function() {
   });
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"DEFAULTSECURITYPOLICYIDCELL",grid:0};
   GXValidFnc[87]={ id: 87, fld:"",grid:0};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id:89 ,lvl:0,type:"int",len:9,dec:0,sign:false,pic:"ZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDEFAULTSECURITYPOLICYID",fmt:0,gxz:"ZV11DefaultSecurityPolicyId",gxold:"OV11DefaultSecurityPolicyId",gxvar:"AV11DefaultSecurityPolicyId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV11DefaultSecurityPolicyId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV11DefaultSecurityPolicyId=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vDEFAULTSECURITYPOLICYID",gx.O.AV11DefaultSecurityPolicyId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11DefaultSecurityPolicyId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vDEFAULTSECURITYPOLICYID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 89 , function() {
   });
   GXValidFnc[90]={ id: 90, fld:"",grid:0};
   GXValidFnc[91]={ id: 91, fld:"",grid:0};
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id:94 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vALLOWOAUTHACCESS",fmt:0,gxz:"ZV5AllowOauthAccess",gxold:"OV5AllowOauthAccess",gxvar:"AV5AllowOauthAccess",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV5AllowOauthAccess=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV5AllowOauthAccess=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vALLOWOAUTHACCESS",gx.O.AV5AllowOauthAccess,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5AllowOauthAccess=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vALLOWOAUTHACCESS")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 94 , function() {
   });
   GXValidFnc[95]={ id: 95, fld:"",grid:0};
   GXValidFnc[96]={ id: 96, fld:"SSOBEHAVIORCELL",grid:0};
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id: 98, fld:"",grid:0};
   GXValidFnc[99]={ id:99 ,lvl:0,type:"char",len:6,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Logoutbehavior,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLOGOUTBEHAVIOR",fmt:0,gxz:"ZV27LogoutBehavior",gxold:"OV27LogoutBehavior",gxvar:"AV27LogoutBehavior",ucs:[],op:[99],ip:[99],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV27LogoutBehavior=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV27LogoutBehavior=Value},v2c:function(){gx.fn.setComboBoxValue("vLOGOUTBEHAVIOR",gx.O.AV27LogoutBehavior);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV27LogoutBehavior=this.val()},val:function(){return gx.fn.getControlValue("vLOGOUTBEHAVIOR")},nac:gx.falseFn};
   this.declareDomainHdlr( 99 , function() {
   });
   GXValidFnc[100]={ id: 100, fld:"",grid:0};
   GXValidFnc[101]={ id: 101, fld:"",grid:0};
   GXValidFnc[102]={ id: 102, fld:"TBLENABLEWORKINASMANAGER",grid:0};
   GXValidFnc[103]={ id: 103, fld:"",grid:0};
   GXValidFnc[104]={ id: 104, fld:"",grid:0};
   GXValidFnc[105]={ id: 105, fld:"",grid:0};
   GXValidFnc[106]={ id: 106, fld:"",grid:0};
   GXValidFnc[107]={ id:107 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENABLEWORKINGASGAMMANAGERREPO",fmt:0,gxz:"ZV52EnableWorkingAsGAMManagerRepo",gxold:"OV52EnableWorkingAsGAMManagerRepo",gxvar:"AV52EnableWorkingAsGAMManagerRepo",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV52EnableWorkingAsGAMManagerRepo=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV52EnableWorkingAsGAMManagerRepo=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vENABLEWORKINGASGAMMANAGERREPO",gx.O.AV52EnableWorkingAsGAMManagerRepo,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV52EnableWorkingAsGAMManagerRepo=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vENABLEWORKINGASGAMMANAGERREPO")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 107 , function() {
   });
   GXValidFnc[108]={ id: 108, fld:"",grid:0};
   GXValidFnc[109]={ id: 109, fld:"",grid:0};
   GXValidFnc[110]={ id: 110, fld:"",grid:0};
   GXValidFnc[111]={ id: 111, fld:"",grid:0};
   GXValidFnc[112]={ id:112 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:this.Validv_Enabletracing,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENABLETRACING",fmt:0,gxz:"ZV13EnableTracing",gxold:"OV13EnableTracing",gxvar:"AV13EnableTracing",ucs:[],op:[112],ip:[112],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV13EnableTracing=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV13EnableTracing=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vENABLETRACING",gx.O.AV13EnableTracing);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13EnableTracing=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vENABLETRACING",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 112 , function() {
   });
   GXValidFnc[114]={ id: 114, fld:"USERS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[115]={ id: 115, fld:"",grid:0};
   GXValidFnc[117]={ id: 117, fld:"TABPAGE2TABLE",grid:0};
   GXValidFnc[118]={ id: 118, fld:"",grid:0};
   GXValidFnc[119]={ id: 119, fld:"",grid:0};
   GXValidFnc[120]={ id: 120, fld:"",grid:0};
   GXValidFnc[121]={ id: 121, fld:"",grid:0};
   GXValidFnc[122]={ id:122 ,lvl:0,type:"char",len:6,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Useridentification,isvalid:null,evt_cvc:'e150d1_client',evt_cvcing:null,rgrid:[],fld:"vUSERIDENTIFICATION",fmt:0,gxz:"ZV47UserIdentification",gxold:"OV47UserIdentification",gxvar:"AV47UserIdentification",ucs:[],op:[122],ip:[122],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV47UserIdentification=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV47UserIdentification=Value},v2c:function(){gx.fn.setComboBoxValue("vUSERIDENTIFICATION",gx.O.AV47UserIdentification);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV47UserIdentification=this.val()},val:function(){return gx.fn.getControlValue("vUSERIDENTIFICATION")},nac:gx.falseFn};
   this.declareDomainHdlr( 122 , function() {
   });
   GXValidFnc[123]={ id: 123, fld:"",grid:0};
   GXValidFnc[124]={ id: 124, fld:"CELLUSEREMAILUNIQUE",grid:0};
   GXValidFnc[125]={ id: 125, fld:"",grid:0};
   GXValidFnc[126]={ id: 126, fld:"",grid:0};
   GXValidFnc[127]={ id:127 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSEREMAILISUNIQUE",fmt:0,gxz:"ZV46UserEmailisUnique",gxold:"OV46UserEmailisUnique",gxvar:"AV46UserEmailisUnique",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV46UserEmailisUnique=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV46UserEmailisUnique=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vUSEREMAILISUNIQUE",gx.O.AV46UserEmailisUnique,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV46UserEmailisUnique=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vUSEREMAILISUNIQUE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 127 , function() {
   });
   GXValidFnc[128]={ id: 128, fld:"",grid:0};
   GXValidFnc[129]={ id: 129, fld:"",grid:0};
   GXValidFnc[130]={ id: 130, fld:"",grid:0};
   GXValidFnc[131]={ id: 131, fld:"",grid:0};
   GXValidFnc[132]={ id:132 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Useractivationmethod,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERACTIVATIONMETHOD",fmt:0,gxz:"ZV44UserActivationMethod",gxold:"OV44UserActivationMethod",gxvar:"AV44UserActivationMethod",ucs:[],op:[132],ip:[132],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV44UserActivationMethod=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV44UserActivationMethod=Value},v2c:function(){gx.fn.setComboBoxValue("vUSERACTIVATIONMETHOD",gx.O.AV44UserActivationMethod);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV44UserActivationMethod=this.val()},val:function(){return gx.fn.getControlValue("vUSERACTIVATIONMETHOD")},nac:gx.falseFn};
   this.declareDomainHdlr( 132 , function() {
   });
   GXValidFnc[133]={ id: 133, fld:"",grid:0};
   GXValidFnc[134]={ id: 134, fld:"",grid:0};
   GXValidFnc[135]={ id: 135, fld:"",grid:0};
   GXValidFnc[136]={ id: 136, fld:"",grid:0};
   GXValidFnc[137]={ id:137 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERAUTOMATICACTIVATIONTIMEOUT",fmt:0,gxz:"ZV45UserAutomaticActivationTimeout",gxold:"OV45UserAutomaticActivationTimeout",gxvar:"AV45UserAutomaticActivationTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV45UserAutomaticActivationTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV45UserAutomaticActivationTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERAUTOMATICACTIVATIONTIMEOUT",gx.O.AV45UserAutomaticActivationTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV45UserAutomaticActivationTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERAUTOMATICACTIVATIONTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[138]={ id: 138, fld:"",grid:0};
   GXValidFnc[139]={ id: 139, fld:"",grid:0};
   GXValidFnc[140]={ id: 140, fld:"",grid:0};
   GXValidFnc[141]={ id: 141, fld:"",grid:0};
   GXValidFnc[142]={ id:142 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERRECOVERYPASSWORDKEYTIMEOUT",fmt:0,gxz:"ZV48UserRecoveryPasswordKeyTimeOut",gxold:"OV48UserRecoveryPasswordKeyTimeOut",gxvar:"AV48UserRecoveryPasswordKeyTimeOut",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV48UserRecoveryPasswordKeyTimeOut=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV48UserRecoveryPasswordKeyTimeOut=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERRECOVERYPASSWORDKEYTIMEOUT",gx.O.AV48UserRecoveryPasswordKeyTimeOut,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV48UserRecoveryPasswordKeyTimeOut=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERRECOVERYPASSWORDKEYTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[143]={ id: 143, fld:"",grid:0};
   GXValidFnc[144]={ id: 144, fld:"",grid:0};
   GXValidFnc[145]={ id: 145, fld:"",grid:0};
   GXValidFnc[146]={ id: 146, fld:"",grid:0};
   GXValidFnc[147]={ id:147 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERRECOVERYPASSWORDKEYDAILYMAXIMUM",fmt:0,gxz:"ZV83UserRecoveryPasswordKeyDailyMaximum",gxold:"OV83UserRecoveryPasswordKeyDailyMaximum",gxvar:"AV83UserRecoveryPasswordKeyDailyMaximum",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV83UserRecoveryPasswordKeyDailyMaximum=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV83UserRecoveryPasswordKeyDailyMaximum=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERRECOVERYPASSWORDKEYDAILYMAXIMUM",gx.O.AV83UserRecoveryPasswordKeyDailyMaximum,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV83UserRecoveryPasswordKeyDailyMaximum=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERRECOVERYPASSWORDKEYDAILYMAXIMUM",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[148]={ id: 148, fld:"",grid:0};
   GXValidFnc[149]={ id: 149, fld:"",grid:0};
   GXValidFnc[150]={ id: 150, fld:"",grid:0};
   GXValidFnc[151]={ id: 151, fld:"",grid:0};
   GXValidFnc[152]={ id:152 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERRECOVERYPASSWORDKEYMONTHLYMAXIMUM",fmt:0,gxz:"ZV84UserRecoveryPasswordKeyMonthlyMaximum",gxold:"OV84UserRecoveryPasswordKeyMonthlyMaximum",gxvar:"AV84UserRecoveryPasswordKeyMonthlyMaximum",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV84UserRecoveryPasswordKeyMonthlyMaximum=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV84UserRecoveryPasswordKeyMonthlyMaximum=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERRECOVERYPASSWORDKEYMONTHLYMAXIMUM",gx.O.AV84UserRecoveryPasswordKeyMonthlyMaximum,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV84UserRecoveryPasswordKeyMonthlyMaximum=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERRECOVERYPASSWORDKEYMONTHLYMAXIMUM",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[153]={ id: 153, fld:"",grid:0};
   GXValidFnc[154]={ id: 154, fld:"",grid:0};
   GXValidFnc[155]={ id: 155, fld:"",grid:0};
   GXValidFnc[156]={ id: 156, fld:"",grid:0};
   GXValidFnc[157]={ id:157 ,lvl:0,type:"int",len:2,dec:0,sign:false,pic:"Z9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLOGINATTEMPTSTOLOCKUSER",fmt:0,gxz:"ZV26LoginAttemptsToLockUser",gxold:"OV26LoginAttemptsToLockUser",gxvar:"AV26LoginAttemptsToLockUser",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV26LoginAttemptsToLockUser=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV26LoginAttemptsToLockUser=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vLOGINATTEMPTSTOLOCKUSER",gx.O.AV26LoginAttemptsToLockUser,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV26LoginAttemptsToLockUser=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vLOGINATTEMPTSTOLOCKUSER",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[158]={ id: 158, fld:"",grid:0};
   GXValidFnc[159]={ id: 159, fld:"",grid:0};
   GXValidFnc[160]={ id: 160, fld:"",grid:0};
   GXValidFnc[161]={ id: 161, fld:"",grid:0};
   GXValidFnc[162]={ id:162 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMUNBLOCKUSERTIMEOUT",fmt:0,gxz:"ZV18GAMUnblockUserTimeout",gxold:"OV18GAMUnblockUserTimeout",gxvar:"AV18GAMUnblockUserTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18GAMUnblockUserTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV18GAMUnblockUserTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vGAMUNBLOCKUSERTIMEOUT",gx.O.AV18GAMUnblockUserTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV18GAMUnblockUserTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vGAMUNBLOCKUSERTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[163]={ id: 163, fld:"",grid:0};
   GXValidFnc[164]={ id: 164, fld:"",grid:0};
   GXValidFnc[165]={ id: 165, fld:"",grid:0};
   GXValidFnc[166]={ id: 166, fld:"",grid:0};
   GXValidFnc[167]={ id:167 ,lvl:0,type:"char",len:6,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Userremembermetype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERREMEMBERMETYPE",fmt:0,gxz:"ZV50UserRememberMeType",gxold:"OV50UserRememberMeType",gxvar:"AV50UserRememberMeType",ucs:[],op:[167],ip:[167],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV50UserRememberMeType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV50UserRememberMeType=Value},v2c:function(){gx.fn.setComboBoxValue("vUSERREMEMBERMETYPE",gx.O.AV50UserRememberMeType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV50UserRememberMeType=this.val()},val:function(){return gx.fn.getControlValue("vUSERREMEMBERMETYPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 167 , function() {
   });
   GXValidFnc[168]={ id: 168, fld:"",grid:0};
   GXValidFnc[169]={ id: 169, fld:"",grid:0};
   GXValidFnc[170]={ id: 170, fld:"",grid:0};
   GXValidFnc[171]={ id: 171, fld:"",grid:0};
   GXValidFnc[172]={ id:172 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERREMEMBERMETIMEOUT",fmt:0,gxz:"ZV49UserRememberMeTimeOut",gxold:"OV49UserRememberMeTimeOut",gxvar:"AV49UserRememberMeTimeOut",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV49UserRememberMeTimeOut=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV49UserRememberMeTimeOut=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERREMEMBERMETIMEOUT",gx.O.AV49UserRememberMeTimeOut,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV49UserRememberMeTimeOut=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERREMEMBERMETIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[173]={ id: 173, fld:"",grid:0};
   GXValidFnc[174]={ id: 174, fld:"",grid:0};
   GXValidFnc[175]={ id: 175, fld:"",grid:0};
   GXValidFnc[176]={ id: 176, fld:"",grid:0};
   GXValidFnc[177]={ id:177 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTOTPSECRETKEYLENGTH",fmt:0,gxz:"ZV82TOTPSecretKeyLength",gxold:"OV82TOTPSecretKeyLength",gxvar:"AV82TOTPSecretKeyLength",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV82TOTPSecretKeyLength=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV82TOTPSecretKeyLength=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vTOTPSECRETKEYLENGTH",gx.O.AV82TOTPSecretKeyLength,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV82TOTPSecretKeyLength=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vTOTPSECRETKEYLENGTH",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 177 , function() {
   });
   GXValidFnc[178]={ id: 178, fld:"",grid:0};
   GXValidFnc[179]={ id: 179, fld:"CELLUSERREQUIEREDEMAIL",grid:0};
   GXValidFnc[180]={ id: 180, fld:"",grid:0};
   GXValidFnc[181]={ id: 181, fld:"",grid:0};
   GXValidFnc[182]={ id:182 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDEMAIL",fmt:0,gxz:"ZV34RequiredEmail",gxold:"OV34RequiredEmail",gxvar:"AV34RequiredEmail",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV34RequiredEmail=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV34RequiredEmail=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDEMAIL",gx.O.AV34RequiredEmail,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV34RequiredEmail=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDEMAIL")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 182 , function() {
   });
   GXValidFnc[183]={ id: 183, fld:"",grid:0};
   GXValidFnc[184]={ id: 184, fld:"",grid:0};
   GXValidFnc[185]={ id: 185, fld:"",grid:0};
   GXValidFnc[186]={ id: 186, fld:"",grid:0};
   GXValidFnc[187]={ id:187 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDPASSWORD",fmt:0,gxz:"ZV37RequiredPassword",gxold:"OV37RequiredPassword",gxvar:"AV37RequiredPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV37RequiredPassword=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV37RequiredPassword=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDPASSWORD",gx.O.AV37RequiredPassword,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV37RequiredPassword=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDPASSWORD")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 187 , function() {
   });
   GXValidFnc[188]={ id: 188, fld:"",grid:0};
   GXValidFnc[189]={ id: 189, fld:"",grid:0};
   GXValidFnc[190]={ id: 190, fld:"",grid:0};
   GXValidFnc[191]={ id: 191, fld:"",grid:0};
   GXValidFnc[192]={ id:192 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDFIRSTNAME",fmt:0,gxz:"ZV35RequiredFirstName",gxold:"OV35RequiredFirstName",gxvar:"AV35RequiredFirstName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV35RequiredFirstName=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV35RequiredFirstName=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDFIRSTNAME",gx.O.AV35RequiredFirstName,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV35RequiredFirstName=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDFIRSTNAME")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 192 , function() {
   });
   GXValidFnc[193]={ id: 193, fld:"",grid:0};
   GXValidFnc[194]={ id: 194, fld:"",grid:0};
   GXValidFnc[195]={ id: 195, fld:"",grid:0};
   GXValidFnc[196]={ id: 196, fld:"",grid:0};
   GXValidFnc[197]={ id:197 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDLASTNAME",fmt:0,gxz:"ZV36RequiredLastName",gxold:"OV36RequiredLastName",gxvar:"AV36RequiredLastName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV36RequiredLastName=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV36RequiredLastName=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDLASTNAME",gx.O.AV36RequiredLastName,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV36RequiredLastName=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDLASTNAME")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 197 , function() {
   });
   GXValidFnc[198]={ id: 198, fld:"",grid:0};
   GXValidFnc[199]={ id: 199, fld:"",grid:0};
   GXValidFnc[200]={ id: 200, fld:"",grid:0};
   GXValidFnc[201]={ id: 201, fld:"",grid:0};
   GXValidFnc[202]={ id:202 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDBIRTHDAY",fmt:0,gxz:"ZV53RequiredBirthday",gxold:"OV53RequiredBirthday",gxvar:"AV53RequiredBirthday",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV53RequiredBirthday=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV53RequiredBirthday=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDBIRTHDAY",gx.O.AV53RequiredBirthday,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV53RequiredBirthday=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDBIRTHDAY")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 202 , function() {
   });
   GXValidFnc[203]={ id: 203, fld:"",grid:0};
   GXValidFnc[204]={ id: 204, fld:"",grid:0};
   GXValidFnc[205]={ id: 205, fld:"",grid:0};
   GXValidFnc[206]={ id: 206, fld:"",grid:0};
   GXValidFnc[207]={ id:207 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDGENDER",fmt:0,gxz:"ZV54RequiredGender",gxold:"OV54RequiredGender",gxvar:"AV54RequiredGender",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV54RequiredGender=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV54RequiredGender=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDGENDER",gx.O.AV54RequiredGender,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV54RequiredGender=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDGENDER")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 207 , function() {
   });
   GXValidFnc[209]={ id: 209, fld:"SESSIONS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[210]={ id: 210, fld:"",grid:0};
   GXValidFnc[212]={ id: 212, fld:"TABPAGE3TABLE",grid:0};
   GXValidFnc[213]={ id: 213, fld:"",grid:0};
   GXValidFnc[214]={ id: 214, fld:"",grid:0};
   GXValidFnc[215]={ id: 215, fld:"",grid:0};
   GXValidFnc[216]={ id: 216, fld:"",grid:0};
   GXValidFnc[217]={ id:217 ,lvl:0,type:"char",len:20,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Generatesessionstatistics,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGENERATESESSIONSTATISTICS",fmt:0,gxz:"ZV19GenerateSessionStatistics",gxold:"OV19GenerateSessionStatistics",gxvar:"AV19GenerateSessionStatistics",ucs:[],op:[217],ip:[217],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV19GenerateSessionStatistics=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19GenerateSessionStatistics=Value},v2c:function(){gx.fn.setComboBoxValue("vGENERATESESSIONSTATISTICS",gx.O.AV19GenerateSessionStatistics);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV19GenerateSessionStatistics=this.val()},val:function(){return gx.fn.getControlValue("vGENERATESESSIONSTATISTICS")},nac:gx.falseFn};
   this.declareDomainHdlr( 217 , function() {
   });
   GXValidFnc[218]={ id: 218, fld:"",grid:0};
   GXValidFnc[219]={ id: 219, fld:"",grid:0};
   GXValidFnc[220]={ id: 220, fld:"",grid:0};
   GXValidFnc[221]={ id: 221, fld:"",grid:0};
   GXValidFnc[222]={ id:222 ,lvl:0,type:"int",len:6,dec:0,sign:false,pic:"ZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERSESSIONCACHETIMEOUT",fmt:0,gxz:"ZV51UserSessionCacheTimeout",gxold:"OV51UserSessionCacheTimeout",gxvar:"AV51UserSessionCacheTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV51UserSessionCacheTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV51UserSessionCacheTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERSESSIONCACHETIMEOUT",gx.O.AV51UserSessionCacheTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV51UserSessionCacheTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERSESSIONCACHETIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[223]={ id: 223, fld:"",grid:0};
   GXValidFnc[224]={ id: 224, fld:"",grid:0};
   GXValidFnc[225]={ id: 225, fld:"",grid:0};
   GXValidFnc[226]={ id: 226, fld:"",grid:0};
   GXValidFnc[227]={ id:227 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGIVEANONYMOUSSESSION",fmt:0,gxz:"ZV20GiveAnonymousSession",gxold:"OV20GiveAnonymousSession",gxvar:"AV20GiveAnonymousSession",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV20GiveAnonymousSession=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV20GiveAnonymousSession=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vGIVEANONYMOUSSESSION",gx.O.AV20GiveAnonymousSession,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20GiveAnonymousSession=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vGIVEANONYMOUSSESSION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 227 , function() {
   });
   GXValidFnc[228]={ id: 228, fld:"",grid:0};
   GXValidFnc[229]={ id: 229, fld:"",grid:0};
   GXValidFnc[230]={ id: 230, fld:"",grid:0};
   GXValidFnc[231]={ id: 231, fld:"",grid:0};
   GXValidFnc[232]={ id:232 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSESSIONEXPIRESONIPCHANGE",fmt:0,gxz:"ZV43SessionExpiresOnIPChange",gxold:"OV43SessionExpiresOnIPChange",gxvar:"AV43SessionExpiresOnIPChange",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV43SessionExpiresOnIPChange=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV43SessionExpiresOnIPChange=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vSESSIONEXPIRESONIPCHANGE",gx.O.AV43SessionExpiresOnIPChange,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV43SessionExpiresOnIPChange=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vSESSIONEXPIRESONIPCHANGE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 232 , function() {
   });
   GXValidFnc[233]={ id: 233, fld:"",grid:0};
   GXValidFnc[234]={ id: 234, fld:"",grid:0};
   GXValidFnc[235]={ id: 235, fld:"",grid:0};
   GXValidFnc[236]={ id: 236, fld:"",grid:0};
   GXValidFnc[237]={ id:237 ,lvl:0,type:"int",len:2,dec:0,sign:false,pic:"Z9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLOGINATTEMPTSTOLOCKSESSION",fmt:0,gxz:"ZV25LoginAttemptsToLockSession",gxold:"OV25LoginAttemptsToLockSession",gxvar:"AV25LoginAttemptsToLockSession",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25LoginAttemptsToLockSession=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV25LoginAttemptsToLockSession=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vLOGINATTEMPTSTOLOCKSESSION",gx.O.AV25LoginAttemptsToLockSession,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV25LoginAttemptsToLockSession=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vLOGINATTEMPTSTOLOCKSESSION",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[238]={ id: 238, fld:"",grid:0};
   GXValidFnc[239]={ id: 239, fld:"",grid:0};
   GXValidFnc[240]={ id: 240, fld:"",grid:0};
   GXValidFnc[241]={ id: 241, fld:"",grid:0};
   GXValidFnc[242]={ id:242 ,lvl:0,type:"int",len:2,dec:0,sign:false,pic:"Z9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMINIMUMAMOUNTCHARACTERSINLOGIN",fmt:0,gxz:"ZV28MinimumAmountCharactersInLogin",gxold:"OV28MinimumAmountCharactersInLogin",gxvar:"AV28MinimumAmountCharactersInLogin",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV28MinimumAmountCharactersInLogin=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV28MinimumAmountCharactersInLogin=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vMINIMUMAMOUNTCHARACTERSINLOGIN",gx.O.AV28MinimumAmountCharactersInLogin,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV28MinimumAmountCharactersInLogin=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vMINIMUMAMOUNTCHARACTERSINLOGIN",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[243]={ id: 243, fld:"",grid:0};
   GXValidFnc[244]={ id: 244, fld:"",grid:0};
   GXValidFnc[245]={ id: 245, fld:"",grid:0};
   GXValidFnc[246]={ id: 246, fld:"",grid:0};
   GXValidFnc[247]={ id:247 ,lvl:0,type:"int",len:6,dec:0,sign:false,pic:"ZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREPOSITORYCACHETIMEOUT",fmt:0,gxz:"ZV33RepositoryCacheTimeout",gxold:"OV33RepositoryCacheTimeout",gxvar:"AV33RepositoryCacheTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV33RepositoryCacheTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV33RepositoryCacheTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vREPOSITORYCACHETIMEOUT",gx.O.AV33RepositoryCacheTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV33RepositoryCacheTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vREPOSITORYCACHETIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[248]={ id: 248, fld:"",grid:0};
   GXValidFnc[249]={ id: 249, fld:"",grid:0};
   GXValidFnc[250]={ id: 250, fld:"",grid:0};
   GXValidFnc[251]={ id: 251, fld:"",grid:0};
   GXValidFnc[252]={ id:252 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vINTSECBYDOMAINENABLE",fmt:0,gxz:"ZV88IntSecByDomainEnable",gxold:"OV88IntSecByDomainEnable",gxvar:"AV88IntSecByDomainEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV88IntSecByDomainEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV88IntSecByDomainEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vINTSECBYDOMAINENABLE",gx.O.AV88IntSecByDomainEnable,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV88IntSecByDomainEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vINTSECBYDOMAINENABLE")},nac:gx.falseFn,evt:"e210d1_client",values:['true','false']};
   GXValidFnc[253]={ id: 253, fld:"",grid:0};
   GXValidFnc[254]={ id: 254, fld:"",grid:0};
   GXValidFnc[255]={ id: 255, fld:"TBLINTSECBYDOMAIN",grid:0};
   GXValidFnc[256]={ id: 256, fld:"",grid:0};
   GXValidFnc[257]={ id: 257, fld:"",grid:0};
   GXValidFnc[258]={ id: 258, fld:"",grid:0};
   GXValidFnc[259]={ id: 259, fld:"",grid:0};
   GXValidFnc[260]={ id:260 ,lvl:0,type:"char",len:10,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Intsecbydomainmode,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vINTSECBYDOMAINMODE",fmt:0,gxz:"ZV87IntSecByDomainMode",gxold:"OV87IntSecByDomainMode",gxvar:"AV87IntSecByDomainMode",ucs:[],op:[260],ip:[260],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV87IntSecByDomainMode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV87IntSecByDomainMode=Value},v2c:function(){gx.fn.setComboBoxValue("vINTSECBYDOMAINMODE",gx.O.AV87IntSecByDomainMode);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV87IntSecByDomainMode=this.val()},val:function(){return gx.fn.getControlValue("vINTSECBYDOMAINMODE")},nac:gx.falseFn};
   this.declareDomainHdlr( 260 , function() {
   });
   GXValidFnc[261]={ id: 261, fld:"",grid:0};
   GXValidFnc[262]={ id: 262, fld:"",grid:0};
   GXValidFnc[263]={ id: 263, fld:"",grid:0};
   GXValidFnc[264]={ id: 264, fld:"",grid:0};
   GXValidFnc[265]={ id:265 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vINTSECBYDOMAINNAME",fmt:0,gxz:"ZV90IntSecByDomainName",gxold:"OV90IntSecByDomainName",gxvar:"AV90IntSecByDomainName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV90IntSecByDomainName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV90IntSecByDomainName=Value},v2c:function(){gx.fn.setControlValue("vINTSECBYDOMAINNAME",gx.O.AV90IntSecByDomainName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV90IntSecByDomainName=this.val()},val:function(){return gx.fn.getControlValue("vINTSECBYDOMAINNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 265 , function() {
   });
   GXValidFnc[266]={ id: 266, fld:"",grid:0};
   GXValidFnc[267]={ id: 267, fld:"",grid:0};
   GXValidFnc[268]={ id: 268, fld:"",grid:0};
   GXValidFnc[269]={ id: 269, fld:"",grid:0};
   GXValidFnc[270]={ id:270 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vINTSECBYDOMAINJWTSECRET",fmt:0,gxz:"ZV86IntSecByDomainJWTSecret",gxold:"OV86IntSecByDomainJWTSecret",gxvar:"AV86IntSecByDomainJWTSecret",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV86IntSecByDomainJWTSecret=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV86IntSecByDomainJWTSecret=Value},v2c:function(){gx.fn.setControlValue("vINTSECBYDOMAINJWTSECRET",gx.O.AV86IntSecByDomainJWTSecret,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV86IntSecByDomainJWTSecret=this.val()},val:function(){return gx.fn.getControlValue("vINTSECBYDOMAINJWTSECRET")},nac:gx.falseFn};
   this.declareDomainHdlr( 270 , function() {
   });
   GXValidFnc[271]={ id: 271, fld:"",grid:0};
   GXValidFnc[272]={ id: 272, fld:"",grid:0};
   GXValidFnc[273]={ id: 273, fld:"",grid:0};
   GXValidFnc[274]={ id: 274, fld:"",grid:0};
   GXValidFnc[275]={ id:275 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vINTSECBYDOMAINENCRYPTIONKEY",fmt:0,gxz:"ZV89IntSecByDomainEncryptionKey",gxold:"OV89IntSecByDomainEncryptionKey",gxvar:"AV89IntSecByDomainEncryptionKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV89IntSecByDomainEncryptionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV89IntSecByDomainEncryptionKey=Value},v2c:function(){gx.fn.setControlValue("vINTSECBYDOMAINENCRYPTIONKEY",gx.O.AV89IntSecByDomainEncryptionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV89IntSecByDomainEncryptionKey=this.val()},val:function(){return gx.fn.getControlValue("vINTSECBYDOMAINENCRYPTIONKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 275 , function() {
   });
   GXValidFnc[277]={ id: 277, fld:"EMAILS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[278]={ id: 278, fld:"",grid:0};
   GXValidFnc[280]={ id: 280, fld:"TABPAGE1TABLE1",grid:0};
   GXValidFnc[281]={ id: 281, fld:"",grid:0};
   GXValidFnc[282]={ id: 282, fld:"",grid:0};
   GXValidFnc[283]={ id: 283, fld:"GROUP1",grid:0};
   GXValidFnc[284]={ id: 284, fld:"GROUP1TABLE",grid:0};
   GXValidFnc[285]={ id: 285, fld:"",grid:0};
   GXValidFnc[286]={ id: 286, fld:"",grid:0};
   GXValidFnc[287]={ id: 287, fld:"",grid:0};
   GXValidFnc[288]={ id: 288, fld:"",grid:0};
   GXValidFnc[289]={ id:289 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVERHOST",fmt:0,gxz:"ZV70EmailServerHost",gxold:"OV70EmailServerHost",gxvar:"AV70EmailServerHost",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV70EmailServerHost=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV70EmailServerHost=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVERHOST",gx.O.AV70EmailServerHost,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV70EmailServerHost=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVERHOST")},nac:gx.falseFn};
   this.declareDomainHdlr( 289 , function() {
   });
   GXValidFnc[290]={ id: 290, fld:"",grid:0};
   GXValidFnc[291]={ id: 291, fld:"",grid:0};
   GXValidFnc[292]={ id: 292, fld:"",grid:0};
   GXValidFnc[293]={ id:293 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVERPORT",fmt:0,gxz:"ZV71EmailServerPort",gxold:"OV71EmailServerPort",gxvar:"AV71EmailServerPort",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV71EmailServerPort=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV71EmailServerPort=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vEMAILSERVERPORT",gx.O.AV71EmailServerPort,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV71EmailServerPort=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vEMAILSERVERPORT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[294]={ id: 294, fld:"",grid:0};
   GXValidFnc[295]={ id: 295, fld:"",grid:0};
   GXValidFnc[296]={ id: 296, fld:"",grid:0};
   GXValidFnc[297]={ id: 297, fld:"",grid:0};
   GXValidFnc[298]={ id:298 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVERTIMEOUT",fmt:0,gxz:"ZV73EmailServerTimeout",gxold:"OV73EmailServerTimeout",gxvar:"AV73EmailServerTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV73EmailServerTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV73EmailServerTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vEMAILSERVERTIMEOUT",gx.O.AV73EmailServerTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV73EmailServerTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vEMAILSERVERTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[299]={ id: 299, fld:"",grid:0};
   GXValidFnc[300]={ id: 300, fld:"",grid:0};
   GXValidFnc[301]={ id: 301, fld:"",grid:0};
   GXValidFnc[302]={ id:302 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVERSECURE",fmt:0,gxz:"ZV72EmailServerSecure",gxold:"OV72EmailServerSecure",gxvar:"AV72EmailServerSecure",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV72EmailServerSecure=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV72EmailServerSecure=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vEMAILSERVERSECURE",gx.O.AV72EmailServerSecure,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV72EmailServerSecure=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vEMAILSERVERSECURE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 302 , function() {
   });
   GXValidFnc[303]={ id: 303, fld:"",grid:0};
   GXValidFnc[304]={ id: 304, fld:"",grid:0};
   GXValidFnc[305]={ id: 305, fld:"",grid:0};
   GXValidFnc[306]={ id: 306, fld:"",grid:0};
   GXValidFnc[307]={ id:307 ,lvl:0,type:"svchar",len:100,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSERVERSENDERADDRESS",fmt:0,gxz:"ZV79ServerSenderAddress",gxold:"OV79ServerSenderAddress",gxvar:"AV79ServerSenderAddress",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV79ServerSenderAddress=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV79ServerSenderAddress=Value},v2c:function(){gx.fn.setControlValue("vSERVERSENDERADDRESS",gx.O.AV79ServerSenderAddress,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV79ServerSenderAddress=this.val()},val:function(){return gx.fn.getControlValue("vSERVERSENDERADDRESS")},nac:gx.falseFn};
   this.declareDomainHdlr( 307 , function() {
   });
   GXValidFnc[308]={ id: 308, fld:"",grid:0};
   GXValidFnc[309]={ id: 309, fld:"",grid:0};
   GXValidFnc[310]={ id: 310, fld:"",grid:0};
   GXValidFnc[311]={ id:311 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSERVERSENDERNAME",fmt:0,gxz:"ZV80ServerSenderName",gxold:"OV80ServerSenderName",gxvar:"AV80ServerSenderName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV80ServerSenderName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV80ServerSenderName=Value},v2c:function(){gx.fn.setControlValue("vSERVERSENDERNAME",gx.O.AV80ServerSenderName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV80ServerSenderName=this.val()},val:function(){return gx.fn.getControlValue("vSERVERSENDERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 311 , function() {
   });
   GXValidFnc[312]={ id: 312, fld:"",grid:0};
   GXValidFnc[313]={ id: 313, fld:"",grid:0};
   GXValidFnc[314]={ id: 314, fld:"",grid:0};
   GXValidFnc[315]={ id: 315, fld:"",grid:0};
   GXValidFnc[316]={ id:316 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVERUSESAUTHENTICATION",fmt:0,gxz:"ZV74EmailServerUsesAuthentication",gxold:"OV74EmailServerUsesAuthentication",gxvar:"AV74EmailServerUsesAuthentication",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV74EmailServerUsesAuthentication=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV74EmailServerUsesAuthentication=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vEMAILSERVERUSESAUTHENTICATION",gx.O.AV74EmailServerUsesAuthentication,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV74EmailServerUsesAuthentication=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vEMAILSERVERUSESAUTHENTICATION")},nac:gx.falseFn,evt:"e160d1_client",values:['true','false']};
   this.declareDomainHdlr( 316 , function() {
   });
   GXValidFnc[317]={ id: 317, fld:"",grid:0};
   GXValidFnc[318]={ id: 318, fld:"",grid:0};
   GXValidFnc[319]={ id: 319, fld:"",grid:0};
   GXValidFnc[320]={ id: 320, fld:"",grid:0};
   GXValidFnc[321]={ id:321 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVERAUTHENTICATIONUSERNAME",fmt:0,gxz:"ZV68EmailServerAuthenticationUsername",gxold:"OV68EmailServerAuthenticationUsername",gxvar:"AV68EmailServerAuthenticationUsername",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV68EmailServerAuthenticationUsername=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV68EmailServerAuthenticationUsername=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVERAUTHENTICATIONUSERNAME",gx.O.AV68EmailServerAuthenticationUsername,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV68EmailServerAuthenticationUsername=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVERAUTHENTICATIONUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 321 , function() {
   });
   GXValidFnc[322]={ id: 322, fld:"",grid:0};
   GXValidFnc[323]={ id: 323, fld:"",grid:0};
   GXValidFnc[324]={ id: 324, fld:"",grid:0};
   GXValidFnc[325]={ id:325 ,lvl:0,type:"char",len:254,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVERAUTHENTICATIONUSERPASSWORD",fmt:0,gxz:"ZV69EmailServerAuthenticationUserPassword",gxold:"OV69EmailServerAuthenticationUserPassword",gxvar:"AV69EmailServerAuthenticationUserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV69EmailServerAuthenticationUserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV69EmailServerAuthenticationUserPassword=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVERAUTHENTICATIONUSERPASSWORD",gx.O.AV69EmailServerAuthenticationUserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV69EmailServerAuthenticationUserPassword=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVERAUTHENTICATIONUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 325 , function() {
   });
   GXValidFnc[326]={ id: 326, fld:"",grid:0};
   GXValidFnc[327]={ id: 327, fld:"",grid:0};
   GXValidFnc[328]={ id: 328, fld:"GROUP2",grid:0};
   GXValidFnc[329]={ id: 329, fld:"GROUP2TABLE",grid:0};
   GXValidFnc[330]={ id: 330, fld:"",grid:0};
   GXValidFnc[331]={ id: 331, fld:"",grid:0};
   GXValidFnc[332]={ id: 332, fld:"",grid:0};
   GXValidFnc[333]={ id: 333, fld:"",grid:0};
   GXValidFnc[334]={ id:334 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_SENDEMAILWHENUSERACTIVATEACCOUNT",fmt:0,gxz:"ZV65EmailServer_SendEmailWhenUserActivateAccount",gxold:"OV65EmailServer_SendEmailWhenUserActivateAccount",gxvar:"AV65EmailServer_SendEmailWhenUserActivateAccount",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV65EmailServer_SendEmailWhenUserActivateAccount=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV65EmailServer_SendEmailWhenUserActivateAccount=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vEMAILSERVER_SENDEMAILWHENUSERACTIVATEACCOUNT",gx.O.AV65EmailServer_SendEmailWhenUserActivateAccount,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV65EmailServer_SendEmailWhenUserActivateAccount=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vEMAILSERVER_SENDEMAILWHENUSERACTIVATEACCOUNT")},nac:gx.falseFn,evt:"e170d1_client",values:['true','false']};
   this.declareDomainHdlr( 334 , function() {
   });
   GXValidFnc[335]={ id: 335, fld:"",grid:0};
   GXValidFnc[336]={ id: 336, fld:"",grid:0};
   GXValidFnc[337]={ id: 337, fld:"TBLUSERACTIVATEACCOUNT",grid:0};
   GXValidFnc[338]={ id: 338, fld:"",grid:0};
   GXValidFnc[339]={ id: 339, fld:"",grid:0};
   GXValidFnc[340]={ id: 340, fld:"",grid:0};
   GXValidFnc[341]={ id: 341, fld:"",grid:0};
   GXValidFnc[342]={ id:342 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_EMAILSUBJECTWHENUSERACTIVATEACCOUNT",fmt:0,gxz:"ZV61EmailServer_EmailSubjectWhenUserActivateAccount",gxold:"OV61EmailServer_EmailSubjectWhenUserActivateAccount",gxvar:"AV61EmailServer_EmailSubjectWhenUserActivateAccount",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV61EmailServer_EmailSubjectWhenUserActivateAccount=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV61EmailServer_EmailSubjectWhenUserActivateAccount=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVER_EMAILSUBJECTWHENUSERACTIVATEACCOUNT",gx.O.AV61EmailServer_EmailSubjectWhenUserActivateAccount,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV61EmailServer_EmailSubjectWhenUserActivateAccount=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVER_EMAILSUBJECTWHENUSERACTIVATEACCOUNT")},nac:gx.falseFn};
   this.declareDomainHdlr( 342 , function() {
   });
   GXValidFnc[343]={ id: 343, fld:"",grid:0};
   GXValidFnc[344]={ id: 344, fld:"",grid:0};
   GXValidFnc[345]={ id: 345, fld:"",grid:0};
   GXValidFnc[346]={ id: 346, fld:"",grid:0};
   GXValidFnc[347]={ id:347 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_EMAILBODYWHENUSERACTIVATEACCOUNT",fmt:0,gxz:"ZV57EmailServer_EmailBodyWhenUserActivateAccount",gxold:"OV57EmailServer_EmailBodyWhenUserActivateAccount",gxvar:"AV57EmailServer_EmailBodyWhenUserActivateAccount",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV57EmailServer_EmailBodyWhenUserActivateAccount=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV57EmailServer_EmailBodyWhenUserActivateAccount=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVER_EMAILBODYWHENUSERACTIVATEACCOUNT",gx.O.AV57EmailServer_EmailBodyWhenUserActivateAccount,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV57EmailServer_EmailBodyWhenUserActivateAccount=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVER_EMAILBODYWHENUSERACTIVATEACCOUNT")},nac:gx.falseFn};
   this.declareDomainHdlr( 347 , function() {
   });
   GXValidFnc[348]={ id: 348, fld:"",grid:0};
   GXValidFnc[349]={ id: 349, fld:"",grid:0};
   GXValidFnc[350]={ id: 350, fld:"GROUP3",grid:0};
   GXValidFnc[351]={ id: 351, fld:"GROUP3TABLE",grid:0};
   GXValidFnc[352]={ id: 352, fld:"",grid:0};
   GXValidFnc[353]={ id: 353, fld:"",grid:0};
   GXValidFnc[354]={ id: 354, fld:"",grid:0};
   GXValidFnc[355]={ id: 355, fld:"",grid:0};
   GXValidFnc[356]={ id:356 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_SENDEMAILWHENUSERCHANGEPASSWORD",fmt:0,gxz:"ZV67EmailServer_SendEmailWhenUserChangePassword",gxold:"OV67EmailServer_SendEmailWhenUserChangePassword",gxvar:"AV67EmailServer_SendEmailWhenUserChangePassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV67EmailServer_SendEmailWhenUserChangePassword=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV67EmailServer_SendEmailWhenUserChangePassword=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vEMAILSERVER_SENDEMAILWHENUSERCHANGEPASSWORD",gx.O.AV67EmailServer_SendEmailWhenUserChangePassword,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV67EmailServer_SendEmailWhenUserChangePassword=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vEMAILSERVER_SENDEMAILWHENUSERCHANGEPASSWORD")},nac:gx.falseFn,evt:"e180d1_client",values:['true','false']};
   this.declareDomainHdlr( 356 , function() {
   });
   GXValidFnc[357]={ id: 357, fld:"",grid:0};
   GXValidFnc[358]={ id: 358, fld:"",grid:0};
   GXValidFnc[359]={ id: 359, fld:"TBLUSERCHANGEPASSWORD",grid:0};
   GXValidFnc[360]={ id: 360, fld:"",grid:0};
   GXValidFnc[361]={ id: 361, fld:"",grid:0};
   GXValidFnc[362]={ id: 362, fld:"",grid:0};
   GXValidFnc[363]={ id: 363, fld:"",grid:0};
   GXValidFnc[364]={ id:364 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_EMAILSUBJECTWHENUSERCHANGEPASSWORD",fmt:0,gxz:"ZV63EmailServer_EmailSubjectWhenUserChangePassword",gxold:"OV63EmailServer_EmailSubjectWhenUserChangePassword",gxvar:"AV63EmailServer_EmailSubjectWhenUserChangePassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV63EmailServer_EmailSubjectWhenUserChangePassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV63EmailServer_EmailSubjectWhenUserChangePassword=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVER_EMAILSUBJECTWHENUSERCHANGEPASSWORD",gx.O.AV63EmailServer_EmailSubjectWhenUserChangePassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV63EmailServer_EmailSubjectWhenUserChangePassword=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVER_EMAILSUBJECTWHENUSERCHANGEPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 364 , function() {
   });
   GXValidFnc[365]={ id: 365, fld:"",grid:0};
   GXValidFnc[366]={ id: 366, fld:"",grid:0};
   GXValidFnc[367]={ id: 367, fld:"",grid:0};
   GXValidFnc[368]={ id: 368, fld:"",grid:0};
   GXValidFnc[369]={ id:369 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_EMAILBODYWHENUSERCHANGEPASSWORD",fmt:0,gxz:"ZV59EmailServer_EmailBodyWhenUserChangePassword",gxold:"OV59EmailServer_EmailBodyWhenUserChangePassword",gxvar:"AV59EmailServer_EmailBodyWhenUserChangePassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV59EmailServer_EmailBodyWhenUserChangePassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV59EmailServer_EmailBodyWhenUserChangePassword=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVER_EMAILBODYWHENUSERCHANGEPASSWORD",gx.O.AV59EmailServer_EmailBodyWhenUserChangePassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV59EmailServer_EmailBodyWhenUserChangePassword=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVER_EMAILBODYWHENUSERCHANGEPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 369 , function() {
   });
   GXValidFnc[370]={ id: 370, fld:"",grid:0};
   GXValidFnc[371]={ id: 371, fld:"",grid:0};
   GXValidFnc[372]={ id: 372, fld:"GROUP4",grid:0};
   GXValidFnc[373]={ id: 373, fld:"GROUP4TABLE",grid:0};
   GXValidFnc[374]={ id: 374, fld:"",grid:0};
   GXValidFnc[375]={ id: 375, fld:"",grid:0};
   GXValidFnc[376]={ id: 376, fld:"",grid:0};
   GXValidFnc[377]={ id: 377, fld:"",grid:0};
   GXValidFnc[378]={ id:378 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_SENDEMAILWHENUSERCHANGEEMAIL",fmt:0,gxz:"ZV66EmailServer_SendEmailWhenUserChangeEmail",gxold:"OV66EmailServer_SendEmailWhenUserChangeEmail",gxvar:"AV66EmailServer_SendEmailWhenUserChangeEmail",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV66EmailServer_SendEmailWhenUserChangeEmail=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV66EmailServer_SendEmailWhenUserChangeEmail=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vEMAILSERVER_SENDEMAILWHENUSERCHANGEEMAIL",gx.O.AV66EmailServer_SendEmailWhenUserChangeEmail,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV66EmailServer_SendEmailWhenUserChangeEmail=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vEMAILSERVER_SENDEMAILWHENUSERCHANGEEMAIL")},nac:gx.falseFn,evt:"e190d1_client",values:['true','false']};
   this.declareDomainHdlr( 378 , function() {
   });
   GXValidFnc[379]={ id: 379, fld:"",grid:0};
   GXValidFnc[380]={ id: 380, fld:"",grid:0};
   GXValidFnc[381]={ id: 381, fld:"TBLUSERCHANGEEMAIL",grid:0};
   GXValidFnc[382]={ id: 382, fld:"",grid:0};
   GXValidFnc[383]={ id: 383, fld:"",grid:0};
   GXValidFnc[384]={ id: 384, fld:"",grid:0};
   GXValidFnc[385]={ id: 385, fld:"",grid:0};
   GXValidFnc[386]={ id:386 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_EMAILSUBJECTWHENUSERCHANGEEMAIL",fmt:0,gxz:"ZV62EmailServer_EmailSubjectWhenUserChangeEmail",gxold:"OV62EmailServer_EmailSubjectWhenUserChangeEmail",gxvar:"AV62EmailServer_EmailSubjectWhenUserChangeEmail",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV62EmailServer_EmailSubjectWhenUserChangeEmail=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV62EmailServer_EmailSubjectWhenUserChangeEmail=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVER_EMAILSUBJECTWHENUSERCHANGEEMAIL",gx.O.AV62EmailServer_EmailSubjectWhenUserChangeEmail,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV62EmailServer_EmailSubjectWhenUserChangeEmail=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVER_EMAILSUBJECTWHENUSERCHANGEEMAIL")},nac:gx.falseFn};
   this.declareDomainHdlr( 386 , function() {
   });
   GXValidFnc[387]={ id: 387, fld:"",grid:0};
   GXValidFnc[388]={ id: 388, fld:"",grid:0};
   GXValidFnc[389]={ id: 389, fld:"",grid:0};
   GXValidFnc[390]={ id: 390, fld:"",grid:0};
   GXValidFnc[391]={ id:391 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_EMAILBODYWHENUSERCHANGEEMAIL",fmt:0,gxz:"ZV58EmailServer_EmailBodyWhenUserChangeEmail",gxold:"OV58EmailServer_EmailBodyWhenUserChangeEmail",gxvar:"AV58EmailServer_EmailBodyWhenUserChangeEmail",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV58EmailServer_EmailBodyWhenUserChangeEmail=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV58EmailServer_EmailBodyWhenUserChangeEmail=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVER_EMAILBODYWHENUSERCHANGEEMAIL",gx.O.AV58EmailServer_EmailBodyWhenUserChangeEmail,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV58EmailServer_EmailBodyWhenUserChangeEmail=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVER_EMAILBODYWHENUSERCHANGEEMAIL")},nac:gx.falseFn};
   this.declareDomainHdlr( 391 , function() {
   });
   GXValidFnc[392]={ id: 392, fld:"",grid:0};
   GXValidFnc[393]={ id: 393, fld:"",grid:0};
   GXValidFnc[394]={ id: 394, fld:"GROUP5",grid:0};
   GXValidFnc[395]={ id: 395, fld:"GROUP5TABLE",grid:0};
   GXValidFnc[396]={ id: 396, fld:"",grid:0};
   GXValidFnc[397]={ id: 397, fld:"",grid:0};
   GXValidFnc[398]={ id: 398, fld:"",grid:0};
   GXValidFnc[399]={ id: 399, fld:"",grid:0};
   GXValidFnc[400]={ id:400 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_SENDEMAILFORRECOVERYPASSWORD",fmt:0,gxz:"ZV64EmailServer_SendEmailForRecoveryPassword",gxold:"OV64EmailServer_SendEmailForRecoveryPassword",gxvar:"AV64EmailServer_SendEmailForRecoveryPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV64EmailServer_SendEmailForRecoveryPassword=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV64EmailServer_SendEmailForRecoveryPassword=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vEMAILSERVER_SENDEMAILFORRECOVERYPASSWORD",gx.O.AV64EmailServer_SendEmailForRecoveryPassword,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV64EmailServer_SendEmailForRecoveryPassword=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vEMAILSERVER_SENDEMAILFORRECOVERYPASSWORD")},nac:gx.falseFn,evt:"e200d1_client",values:['true','false']};
   this.declareDomainHdlr( 400 , function() {
   });
   GXValidFnc[401]={ id: 401, fld:"",grid:0};
   GXValidFnc[402]={ id: 402, fld:"",grid:0};
   GXValidFnc[403]={ id: 403, fld:"TBLUSERRECOVERYPASSWORD",grid:0};
   GXValidFnc[404]={ id: 404, fld:"",grid:0};
   GXValidFnc[405]={ id: 405, fld:"",grid:0};
   GXValidFnc[406]={ id: 406, fld:"",grid:0};
   GXValidFnc[407]={ id: 407, fld:"",grid:0};
   GXValidFnc[408]={ id:408 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_EMAILSUBJECTFORRECOVERYPASSWORD",fmt:0,gxz:"ZV60EmailServer_EmailSubjectForRecoveryPassword",gxold:"OV60EmailServer_EmailSubjectForRecoveryPassword",gxvar:"AV60EmailServer_EmailSubjectForRecoveryPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV60EmailServer_EmailSubjectForRecoveryPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV60EmailServer_EmailSubjectForRecoveryPassword=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVER_EMAILSUBJECTFORRECOVERYPASSWORD",gx.O.AV60EmailServer_EmailSubjectForRecoveryPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV60EmailServer_EmailSubjectForRecoveryPassword=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVER_EMAILSUBJECTFORRECOVERYPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 408 , function() {
   });
   GXValidFnc[409]={ id: 409, fld:"",grid:0};
   GXValidFnc[410]={ id: 410, fld:"",grid:0};
   GXValidFnc[411]={ id: 411, fld:"",grid:0};
   GXValidFnc[412]={ id: 412, fld:"",grid:0};
   GXValidFnc[413]={ id:413 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAILSERVER_EMAILBODYFORRECOVERYPASSWORD",fmt:0,gxz:"ZV56EmailServer_EmailBodyForRecoveryPassword",gxold:"OV56EmailServer_EmailBodyForRecoveryPassword",gxvar:"AV56EmailServer_EmailBodyForRecoveryPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV56EmailServer_EmailBodyForRecoveryPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV56EmailServer_EmailBodyForRecoveryPassword=Value},v2c:function(){gx.fn.setControlValue("vEMAILSERVER_EMAILBODYFORRECOVERYPASSWORD",gx.O.AV56EmailServer_EmailBodyForRecoveryPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV56EmailServer_EmailBodyForRecoveryPassword=this.val()},val:function(){return gx.fn.getControlValue("vEMAILSERVER_EMAILBODYFORRECOVERYPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 413 , function() {
   });
   GXValidFnc[414]={ id: 414, fld:"",grid:0};
   GXValidFnc[415]={ id: 415, fld:"",grid:0};
   GXValidFnc[417]={ id: 417, fld:"",grid:0};
   GXValidFnc[418]={ id: 418, fld:"",grid:0};
   GXValidFnc[419]={ id: 419, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[420]={ id: 420, fld:"",grid:0};
   GXValidFnc[421]={ id: 421, fld:"",grid:0};
   GXValidFnc[422]={ id: 422, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[423]={ id: 423, fld:"",grid:0};
   GXValidFnc[424]={ id: 424, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e130d2_client"};
   GXValidFnc[425]={ id: 425, fld:"",grid:0};
   GXValidFnc[426]={ id: 426, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e120d2_client"};
   this.AV77RepoId = 0 ;
   this.ZV77RepoId = 0 ;
   this.OV77RepoId = 0 ;
   this.AV21GUID = "" ;
   this.ZV21GUID = "" ;
   this.OV21GUID = "" ;
   this.AV30NameSpace = "" ;
   this.ZV30NameSpace = "" ;
   this.OV30NameSpace = "" ;
   this.AV29Name = "" ;
   this.ZV29Name = "" ;
   this.OV29Name = "" ;
   this.AV12Dsc = "" ;
   this.ZV12Dsc = "" ;
   this.OV12Dsc = "" ;
   this.AV55AuthenticationMasterRepository = "" ;
   this.ZV55AuthenticationMasterRepository = "" ;
   this.OV55AuthenticationMasterRepository = "" ;
   this.AV9DefaultAuthTypeName = "" ;
   this.ZV9DefaultAuthTypeName = "" ;
   this.OV9DefaultAuthTypeName = "" ;
   this.AV10DefaultRoleId = 0 ;
   this.ZV10DefaultRoleId = 0 ;
   this.OV10DefaultRoleId = 0 ;
   this.AV11DefaultSecurityPolicyId = 0 ;
   this.ZV11DefaultSecurityPolicyId = 0 ;
   this.OV11DefaultSecurityPolicyId = 0 ;
   this.AV5AllowOauthAccess = false ;
   this.ZV5AllowOauthAccess = false ;
   this.OV5AllowOauthAccess = false ;
   this.AV27LogoutBehavior = "" ;
   this.ZV27LogoutBehavior = "" ;
   this.OV27LogoutBehavior = "" ;
   this.AV52EnableWorkingAsGAMManagerRepo = false ;
   this.ZV52EnableWorkingAsGAMManagerRepo = false ;
   this.OV52EnableWorkingAsGAMManagerRepo = false ;
   this.AV13EnableTracing = 0 ;
   this.ZV13EnableTracing = 0 ;
   this.OV13EnableTracing = 0 ;
   this.AV47UserIdentification = "" ;
   this.ZV47UserIdentification = "" ;
   this.OV47UserIdentification = "" ;
   this.AV46UserEmailisUnique = false ;
   this.ZV46UserEmailisUnique = false ;
   this.OV46UserEmailisUnique = false ;
   this.AV44UserActivationMethod = "" ;
   this.ZV44UserActivationMethod = "" ;
   this.OV44UserActivationMethod = "" ;
   this.AV45UserAutomaticActivationTimeout = 0 ;
   this.ZV45UserAutomaticActivationTimeout = 0 ;
   this.OV45UserAutomaticActivationTimeout = 0 ;
   this.AV48UserRecoveryPasswordKeyTimeOut = 0 ;
   this.ZV48UserRecoveryPasswordKeyTimeOut = 0 ;
   this.OV48UserRecoveryPasswordKeyTimeOut = 0 ;
   this.AV83UserRecoveryPasswordKeyDailyMaximum = 0 ;
   this.ZV83UserRecoveryPasswordKeyDailyMaximum = 0 ;
   this.OV83UserRecoveryPasswordKeyDailyMaximum = 0 ;
   this.AV84UserRecoveryPasswordKeyMonthlyMaximum = 0 ;
   this.ZV84UserRecoveryPasswordKeyMonthlyMaximum = 0 ;
   this.OV84UserRecoveryPasswordKeyMonthlyMaximum = 0 ;
   this.AV26LoginAttemptsToLockUser = 0 ;
   this.ZV26LoginAttemptsToLockUser = 0 ;
   this.OV26LoginAttemptsToLockUser = 0 ;
   this.AV18GAMUnblockUserTimeout = 0 ;
   this.ZV18GAMUnblockUserTimeout = 0 ;
   this.OV18GAMUnblockUserTimeout = 0 ;
   this.AV50UserRememberMeType = "" ;
   this.ZV50UserRememberMeType = "" ;
   this.OV50UserRememberMeType = "" ;
   this.AV49UserRememberMeTimeOut = 0 ;
   this.ZV49UserRememberMeTimeOut = 0 ;
   this.OV49UserRememberMeTimeOut = 0 ;
   this.AV82TOTPSecretKeyLength = 0 ;
   this.ZV82TOTPSecretKeyLength = 0 ;
   this.OV82TOTPSecretKeyLength = 0 ;
   this.AV34RequiredEmail = false ;
   this.ZV34RequiredEmail = false ;
   this.OV34RequiredEmail = false ;
   this.AV37RequiredPassword = false ;
   this.ZV37RequiredPassword = false ;
   this.OV37RequiredPassword = false ;
   this.AV35RequiredFirstName = false ;
   this.ZV35RequiredFirstName = false ;
   this.OV35RequiredFirstName = false ;
   this.AV36RequiredLastName = false ;
   this.ZV36RequiredLastName = false ;
   this.OV36RequiredLastName = false ;
   this.AV53RequiredBirthday = false ;
   this.ZV53RequiredBirthday = false ;
   this.OV53RequiredBirthday = false ;
   this.AV54RequiredGender = false ;
   this.ZV54RequiredGender = false ;
   this.OV54RequiredGender = false ;
   this.AV19GenerateSessionStatistics = "" ;
   this.ZV19GenerateSessionStatistics = "" ;
   this.OV19GenerateSessionStatistics = "" ;
   this.AV51UserSessionCacheTimeout = 0 ;
   this.ZV51UserSessionCacheTimeout = 0 ;
   this.OV51UserSessionCacheTimeout = 0 ;
   this.AV20GiveAnonymousSession = false ;
   this.ZV20GiveAnonymousSession = false ;
   this.OV20GiveAnonymousSession = false ;
   this.AV43SessionExpiresOnIPChange = false ;
   this.ZV43SessionExpiresOnIPChange = false ;
   this.OV43SessionExpiresOnIPChange = false ;
   this.AV25LoginAttemptsToLockSession = 0 ;
   this.ZV25LoginAttemptsToLockSession = 0 ;
   this.OV25LoginAttemptsToLockSession = 0 ;
   this.AV28MinimumAmountCharactersInLogin = 0 ;
   this.ZV28MinimumAmountCharactersInLogin = 0 ;
   this.OV28MinimumAmountCharactersInLogin = 0 ;
   this.AV33RepositoryCacheTimeout = 0 ;
   this.ZV33RepositoryCacheTimeout = 0 ;
   this.OV33RepositoryCacheTimeout = 0 ;
   this.AV88IntSecByDomainEnable = false ;
   this.ZV88IntSecByDomainEnable = false ;
   this.OV88IntSecByDomainEnable = false ;
   this.AV87IntSecByDomainMode = "" ;
   this.ZV87IntSecByDomainMode = "" ;
   this.OV87IntSecByDomainMode = "" ;
   this.AV90IntSecByDomainName = "" ;
   this.ZV90IntSecByDomainName = "" ;
   this.OV90IntSecByDomainName = "" ;
   this.AV86IntSecByDomainJWTSecret = "" ;
   this.ZV86IntSecByDomainJWTSecret = "" ;
   this.OV86IntSecByDomainJWTSecret = "" ;
   this.AV89IntSecByDomainEncryptionKey = "" ;
   this.ZV89IntSecByDomainEncryptionKey = "" ;
   this.OV89IntSecByDomainEncryptionKey = "" ;
   this.AV70EmailServerHost = "" ;
   this.ZV70EmailServerHost = "" ;
   this.OV70EmailServerHost = "" ;
   this.AV71EmailServerPort = 0 ;
   this.ZV71EmailServerPort = 0 ;
   this.OV71EmailServerPort = 0 ;
   this.AV73EmailServerTimeout = 0 ;
   this.ZV73EmailServerTimeout = 0 ;
   this.OV73EmailServerTimeout = 0 ;
   this.AV72EmailServerSecure = false ;
   this.ZV72EmailServerSecure = false ;
   this.OV72EmailServerSecure = false ;
   this.AV79ServerSenderAddress = "" ;
   this.ZV79ServerSenderAddress = "" ;
   this.OV79ServerSenderAddress = "" ;
   this.AV80ServerSenderName = "" ;
   this.ZV80ServerSenderName = "" ;
   this.OV80ServerSenderName = "" ;
   this.AV74EmailServerUsesAuthentication = false ;
   this.ZV74EmailServerUsesAuthentication = false ;
   this.OV74EmailServerUsesAuthentication = false ;
   this.AV68EmailServerAuthenticationUsername = "" ;
   this.ZV68EmailServerAuthenticationUsername = "" ;
   this.OV68EmailServerAuthenticationUsername = "" ;
   this.AV69EmailServerAuthenticationUserPassword = "" ;
   this.ZV69EmailServerAuthenticationUserPassword = "" ;
   this.OV69EmailServerAuthenticationUserPassword = "" ;
   this.AV65EmailServer_SendEmailWhenUserActivateAccount = false ;
   this.ZV65EmailServer_SendEmailWhenUserActivateAccount = false ;
   this.OV65EmailServer_SendEmailWhenUserActivateAccount = false ;
   this.AV61EmailServer_EmailSubjectWhenUserActivateAccount = "" ;
   this.ZV61EmailServer_EmailSubjectWhenUserActivateAccount = "" ;
   this.OV61EmailServer_EmailSubjectWhenUserActivateAccount = "" ;
   this.AV57EmailServer_EmailBodyWhenUserActivateAccount = "" ;
   this.ZV57EmailServer_EmailBodyWhenUserActivateAccount = "" ;
   this.OV57EmailServer_EmailBodyWhenUserActivateAccount = "" ;
   this.AV67EmailServer_SendEmailWhenUserChangePassword = false ;
   this.ZV67EmailServer_SendEmailWhenUserChangePassword = false ;
   this.OV67EmailServer_SendEmailWhenUserChangePassword = false ;
   this.AV63EmailServer_EmailSubjectWhenUserChangePassword = "" ;
   this.ZV63EmailServer_EmailSubjectWhenUserChangePassword = "" ;
   this.OV63EmailServer_EmailSubjectWhenUserChangePassword = "" ;
   this.AV59EmailServer_EmailBodyWhenUserChangePassword = "" ;
   this.ZV59EmailServer_EmailBodyWhenUserChangePassword = "" ;
   this.OV59EmailServer_EmailBodyWhenUserChangePassword = "" ;
   this.AV66EmailServer_SendEmailWhenUserChangeEmail = false ;
   this.ZV66EmailServer_SendEmailWhenUserChangeEmail = false ;
   this.OV66EmailServer_SendEmailWhenUserChangeEmail = false ;
   this.AV62EmailServer_EmailSubjectWhenUserChangeEmail = "" ;
   this.ZV62EmailServer_EmailSubjectWhenUserChangeEmail = "" ;
   this.OV62EmailServer_EmailSubjectWhenUserChangeEmail = "" ;
   this.AV58EmailServer_EmailBodyWhenUserChangeEmail = "" ;
   this.ZV58EmailServer_EmailBodyWhenUserChangeEmail = "" ;
   this.OV58EmailServer_EmailBodyWhenUserChangeEmail = "" ;
   this.AV64EmailServer_SendEmailForRecoveryPassword = false ;
   this.ZV64EmailServer_SendEmailForRecoveryPassword = false ;
   this.OV64EmailServer_SendEmailForRecoveryPassword = false ;
   this.AV60EmailServer_EmailSubjectForRecoveryPassword = "" ;
   this.ZV60EmailServer_EmailSubjectForRecoveryPassword = "" ;
   this.OV60EmailServer_EmailSubjectForRecoveryPassword = "" ;
   this.AV56EmailServer_EmailBodyForRecoveryPassword = "" ;
   this.ZV56EmailServer_EmailBodyForRecoveryPassword = "" ;
   this.OV56EmailServer_EmailBodyForRecoveryPassword = "" ;
   this.AV77RepoId = 0 ;
   this.AV21GUID = "" ;
   this.AV30NameSpace = "" ;
   this.AV29Name = "" ;
   this.AV12Dsc = "" ;
   this.AV55AuthenticationMasterRepository = "" ;
   this.AV9DefaultAuthTypeName = "" ;
   this.AV10DefaultRoleId = 0 ;
   this.AV11DefaultSecurityPolicyId = 0 ;
   this.AV5AllowOauthAccess = false ;
   this.AV27LogoutBehavior = "" ;
   this.AV52EnableWorkingAsGAMManagerRepo = false ;
   this.AV13EnableTracing = 0 ;
   this.AV47UserIdentification = "" ;
   this.AV46UserEmailisUnique = false ;
   this.AV44UserActivationMethod = "" ;
   this.AV45UserAutomaticActivationTimeout = 0 ;
   this.AV48UserRecoveryPasswordKeyTimeOut = 0 ;
   this.AV83UserRecoveryPasswordKeyDailyMaximum = 0 ;
   this.AV84UserRecoveryPasswordKeyMonthlyMaximum = 0 ;
   this.AV26LoginAttemptsToLockUser = 0 ;
   this.AV18GAMUnblockUserTimeout = 0 ;
   this.AV50UserRememberMeType = "" ;
   this.AV49UserRememberMeTimeOut = 0 ;
   this.AV82TOTPSecretKeyLength = 0 ;
   this.AV34RequiredEmail = false ;
   this.AV37RequiredPassword = false ;
   this.AV35RequiredFirstName = false ;
   this.AV36RequiredLastName = false ;
   this.AV53RequiredBirthday = false ;
   this.AV54RequiredGender = false ;
   this.AV19GenerateSessionStatistics = "" ;
   this.AV51UserSessionCacheTimeout = 0 ;
   this.AV20GiveAnonymousSession = false ;
   this.AV43SessionExpiresOnIPChange = false ;
   this.AV25LoginAttemptsToLockSession = 0 ;
   this.AV28MinimumAmountCharactersInLogin = 0 ;
   this.AV33RepositoryCacheTimeout = 0 ;
   this.AV88IntSecByDomainEnable = false ;
   this.AV87IntSecByDomainMode = "" ;
   this.AV90IntSecByDomainName = "" ;
   this.AV86IntSecByDomainJWTSecret = "" ;
   this.AV89IntSecByDomainEncryptionKey = "" ;
   this.AV70EmailServerHost = "" ;
   this.AV71EmailServerPort = 0 ;
   this.AV73EmailServerTimeout = 0 ;
   this.AV72EmailServerSecure = false ;
   this.AV79ServerSenderAddress = "" ;
   this.AV80ServerSenderName = "" ;
   this.AV74EmailServerUsesAuthentication = false ;
   this.AV68EmailServerAuthenticationUsername = "" ;
   this.AV69EmailServerAuthenticationUserPassword = "" ;
   this.AV65EmailServer_SendEmailWhenUserActivateAccount = false ;
   this.AV61EmailServer_EmailSubjectWhenUserActivateAccount = "" ;
   this.AV57EmailServer_EmailBodyWhenUserActivateAccount = "" ;
   this.AV67EmailServer_SendEmailWhenUserChangePassword = false ;
   this.AV63EmailServer_EmailSubjectWhenUserChangePassword = "" ;
   this.AV59EmailServer_EmailBodyWhenUserChangePassword = "" ;
   this.AV66EmailServer_SendEmailWhenUserChangeEmail = false ;
   this.AV62EmailServer_EmailSubjectWhenUserChangeEmail = "" ;
   this.AV58EmailServer_EmailBodyWhenUserChangeEmail = "" ;
   this.AV64EmailServer_SendEmailForRecoveryPassword = false ;
   this.AV60EmailServer_EmailSubjectForRecoveryPassword = "" ;
   this.AV56EmailServer_EmailBodyForRecoveryPassword = "" ;
   this.AV22Id = 0 ;
   this.AV40SecurityAdministratorEmail = "" ;
   this.AV8CanRegisterUsers = false ;
   this.Events = {"e120d2_client": ["'CONFIRM'", true] ,"e130d2_client": ["'CANCEL'", true] ,"e220d2_client": ["ENTER", true] ,"e230d2_client": ["CANCEL", true] ,"e150d1_client": ["VUSERIDENTIFICATION.CONTROLVALUECHANGED", false] ,"e160d1_client": ["VEMAILSERVERUSESAUTHENTICATION.CLICK", false] ,"e170d1_client": ["VEMAILSERVER_SENDEMAILWHENUSERACTIVATEACCOUNT.CLICK", false] ,"e180d1_client": ["VEMAILSERVER_SENDEMAILWHENUSERCHANGEPASSWORD.CLICK", false] ,"e190d1_client": ["VEMAILSERVER_SENDEMAILWHENUSERCHANGEEMAIL.CLICK", false] ,"e200d1_client": ["VEMAILSERVER_SENDEMAILFORRECOVERYPASSWORD.CLICK", false] ,"e210d1_client": ["VINTSECBYDOMAINENABLE.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV53RequiredBirthday',fld:'vREQUIREDBIRTHDAY',pic:''},{av:'AV54RequiredGender',fld:'vREQUIREDGENDER',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''},{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV88IntSecByDomainEnable',fld:'vINTSECBYDOMAINENABLE',pic:''},{av:'AV72EmailServerSecure',fld:'vEMAILSERVERSECURE',pic:''},{av:'AV74EmailServerUsesAuthentication',fld:'vEMAILSERVERUSESAUTHENTICATION',pic:''},{av:'AV65EmailServer_SendEmailWhenUserActivateAccount',fld:'vEMAILSERVER_SENDEMAILWHENUSERACTIVATEACCOUNT',pic:''},{av:'AV67EmailServer_SendEmailWhenUserChangePassword',fld:'vEMAILSERVER_SENDEMAILWHENUSERCHANGEPASSWORD',pic:''},{av:'AV66EmailServer_SendEmailWhenUserChangeEmail',fld:'vEMAILSERVER_SENDEMAILWHENUSERCHANGEEMAIL',pic:''},{av:'AV64EmailServer_SendEmailForRecoveryPassword',fld:'vEMAILSERVER_SENDEMAILFORRECOVERYPASSWORD',pic:''},{av:'AV40SecurityAdministratorEmail',fld:'vSECURITYADMINISTRATOREMAIL',pic:'',hsh:true},{av:'AV8CanRegisterUsers',fld:'vCANREGISTERUSERS',pic:'',hsh:true},{av:'AV22Id',fld:'vID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV77RepoId',fld:'vREPOID',pic:'ZZZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["'CONFIRM'"] = [[{av:'AV77RepoId',fld:'vREPOID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV29Name',fld:'vNAME',pic:''},{av:'AV12Dsc',fld:'vDSC',pic:''},{ctrl:'vDEFAULTAUTHTYPENAME'},{av:'AV9DefaultAuthTypeName',fld:'vDEFAULTAUTHTYPENAME',pic:''},{ctrl:'vUSERIDENTIFICATION'},{av:'AV47UserIdentification',fld:'vUSERIDENTIFICATION',pic:''},{ctrl:'vGENERATESESSIONSTATISTICS'},{av:'AV19GenerateSessionStatistics',fld:'vGENERATESESSIONSTATISTICS',pic:''},{ctrl:'vUSERACTIVATIONMETHOD'},{av:'AV44UserActivationMethod',fld:'vUSERACTIVATIONMETHOD',pic:''},{av:'AV45UserAutomaticActivationTimeout',fld:'vUSERAUTOMATICACTIVATIONTIMEOUT',pic:'ZZZ9'},{av:'AV18GAMUnblockUserTimeout',fld:'vGAMUNBLOCKUSERTIMEOUT',pic:'ZZZ9'},{ctrl:'vUSERREMEMBERMETYPE'},{av:'AV50UserRememberMeType',fld:'vUSERREMEMBERMETYPE',pic:''},{av:'AV49UserRememberMeTimeOut',fld:'vUSERREMEMBERMETIMEOUT',pic:'ZZZ9'},{av:'AV48UserRecoveryPasswordKeyTimeOut',fld:'vUSERRECOVERYPASSWORDKEYTIMEOUT',pic:'ZZZ9'},{av:'AV83UserRecoveryPasswordKeyDailyMaximum',fld:'vUSERRECOVERYPASSWORDKEYDAILYMAXIMUM',pic:'ZZZ9'},{av:'AV84UserRecoveryPasswordKeyMonthlyMaximum',fld:'vUSERRECOVERYPASSWORDKEYMONTHLYMAXIMUM',pic:'ZZZ9'},{ctrl:'vLOGOUTBEHAVIOR'},{av:'AV27LogoutBehavior',fld:'vLOGOUTBEHAVIOR',pic:''},{av:'AV28MinimumAmountCharactersInLogin',fld:'vMINIMUMAMOUNTCHARACTERSINLOGIN',pic:'Z9'},{av:'AV26LoginAttemptsToLockUser',fld:'vLOGINATTEMPTSTOLOCKUSER',pic:'Z9'},{av:'AV25LoginAttemptsToLockSession',fld:'vLOGINATTEMPTSTOLOCKSESSION',pic:'Z9'},{av:'AV51UserSessionCacheTimeout',fld:'vUSERSESSIONCACHETIMEOUT',pic:'ZZZZZ9'},{av:'AV33RepositoryCacheTimeout',fld:'vREPOSITORYCACHETIMEOUT',pic:'ZZZZZ9'},{av:'AV40SecurityAdministratorEmail',fld:'vSECURITYADMINISTRATOREMAIL',pic:'',hsh:true},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''},{av:'AV8CanRegisterUsers',fld:'vCANREGISTERUSERS',pic:'',hsh:true},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{ctrl:'vDEFAULTROLEID'},{av:'AV10DefaultRoleId',fld:'vDEFAULTROLEID',pic:'ZZZZZZZZZZZ9'},{ctrl:'vDEFAULTSECURITYPOLICYID'},{av:'AV11DefaultSecurityPolicyId',fld:'vDEFAULTSECURITYPOLICYID',pic:'ZZZZZZZZ9'},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{ctrl:'vENABLETRACING'},{av:'AV13EnableTracing',fld:'vENABLETRACING',pic:'ZZZ9'},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV88IntSecByDomainEnable',fld:'vINTSECBYDOMAINENABLE',pic:''},{ctrl:'vINTSECBYDOMAINMODE'},{av:'AV87IntSecByDomainMode',fld:'vINTSECBYDOMAINMODE',pic:''},{av:'AV90IntSecByDomainName',fld:'vINTSECBYDOMAINNAME',pic:''},{av:'AV86IntSecByDomainJWTSecret',fld:'vINTSECBYDOMAINJWTSECRET',pic:''},{av:'AV89IntSecByDomainEncryptionKey',fld:'vINTSECBYDOMAINENCRYPTIONKEY',pic:''},{av:'AV82TOTPSecretKeyLength',fld:'vTOTPSECRETKEYLENGTH',pic:'ZZZZZZZZZZZ9'},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV53RequiredBirthday',fld:'vREQUIREDBIRTHDAY',pic:''},{av:'AV54RequiredGender',fld:'vREQUIREDGENDER',pic:''},{av:'AV70EmailServerHost',fld:'vEMAILSERVERHOST',pic:''},{av:'AV71EmailServerPort',fld:'vEMAILSERVERPORT',pic:'ZZZ9'},{av:'AV72EmailServerSecure',fld:'vEMAILSERVERSECURE',pic:''},{av:'AV73EmailServerTimeout',fld:'vEMAILSERVERTIMEOUT',pic:'ZZZ9'},{av:'AV74EmailServerUsesAuthentication',fld:'vEMAILSERVERUSESAUTHENTICATION',pic:''},{av:'AV79ServerSenderAddress',fld:'vSERVERSENDERADDRESS',pic:''},{av:'AV80ServerSenderName',fld:'vSERVERSENDERNAME',pic:''},{av:'AV68EmailServerAuthenticationUsername',fld:'vEMAILSERVERAUTHENTICATIONUSERNAME',pic:''},{av:'AV69EmailServerAuthenticationUserPassword',fld:'vEMAILSERVERAUTHENTICATIONUSERPASSWORD',pic:''},{av:'AV65EmailServer_SendEmailWhenUserActivateAccount',fld:'vEMAILSERVER_SENDEMAILWHENUSERACTIVATEACCOUNT',pic:''},{av:'AV61EmailServer_EmailSubjectWhenUserActivateAccount',fld:'vEMAILSERVER_EMAILSUBJECTWHENUSERACTIVATEACCOUNT',pic:''},{av:'AV57EmailServer_EmailBodyWhenUserActivateAccount',fld:'vEMAILSERVER_EMAILBODYWHENUSERACTIVATEACCOUNT',pic:''},{av:'AV67EmailServer_SendEmailWhenUserChangePassword',fld:'vEMAILSERVER_SENDEMAILWHENUSERCHANGEPASSWORD',pic:''},{av:'AV63EmailServer_EmailSubjectWhenUserChangePassword',fld:'vEMAILSERVER_EMAILSUBJECTWHENUSERCHANGEPASSWORD',pic:''},{av:'AV59EmailServer_EmailBodyWhenUserChangePassword',fld:'vEMAILSERVER_EMAILBODYWHENUSERCHANGEPASSWORD',pic:''},{av:'AV66EmailServer_SendEmailWhenUserChangeEmail',fld:'vEMAILSERVER_SENDEMAILWHENUSERCHANGEEMAIL',pic:''},{av:'AV62EmailServer_EmailSubjectWhenUserChangeEmail',fld:'vEMAILSERVER_EMAILSUBJECTWHENUSERCHANGEEMAIL',pic:''},{av:'AV58EmailServer_EmailBodyWhenUserChangeEmail',fld:'vEMAILSERVER_EMAILBODYWHENUSERCHANGEEMAIL',pic:''},{av:'AV64EmailServer_SendEmailForRecoveryPassword',fld:'vEMAILSERVER_SENDEMAILFORRECOVERYPASSWORD',pic:''},{av:'AV60EmailServer_EmailSubjectForRecoveryPassword',fld:'vEMAILSERVER_EMAILSUBJECTFORRECOVERYPASSWORD',pic:''},{av:'AV56EmailServer_EmailBodyForRecoveryPassword',fld:'vEMAILSERVER_EMAILBODYFORRECOVERYPASSWORD',pic:''},{av:'AV22Id',fld:'vID',pic:'ZZZZZZZZZZZ9',hsh:true}],[{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'CANCEL'"] = [[],[]];
   this.EvtParms["VUSERIDENTIFICATION.CONTROLVALUECHANGED"] = [[{ctrl:'vUSERIDENTIFICATION'},{av:'AV47UserIdentification',fld:'vUSERIDENTIFICATION',pic:''}],[{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'gx.fn.getCtrlProperty("CELLUSEREMAILUNIQUE","Visible")',ctrl:'CELLUSEREMAILUNIQUE',prop:'Visible'},{av:'gx.fn.getCtrlProperty("CELLUSERREQUIEREDEMAIL","Visible")',ctrl:'CELLUSERREQUIEREDEMAIL',prop:'Visible'}]];
   this.EvtParms["VEMAILSERVERUSESAUTHENTICATION.CLICK"] = [[{av:'AV74EmailServerUsesAuthentication',fld:'vEMAILSERVERUSESAUTHENTICATION',pic:''}],[{av:'gx.fn.getCtrlProperty("vEMAILSERVERAUTHENTICATIONUSERNAME","Visible")',ctrl:'vEMAILSERVERAUTHENTICATIONUSERNAME',prop:'Visible'},{av:'gx.fn.getCtrlProperty("vEMAILSERVERAUTHENTICATIONUSERPASSWORD","Visible")',ctrl:'vEMAILSERVERAUTHENTICATIONUSERPASSWORD',prop:'Visible'}]];
   this.EvtParms["VEMAILSERVER_SENDEMAILWHENUSERACTIVATEACCOUNT.CLICK"] = [[{av:'AV65EmailServer_SendEmailWhenUserActivateAccount',fld:'vEMAILSERVER_SENDEMAILWHENUSERACTIVATEACCOUNT',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLUSERACTIVATEACCOUNT","Visible")',ctrl:'TBLUSERACTIVATEACCOUNT',prop:'Visible'}]];
   this.EvtParms["VEMAILSERVER_SENDEMAILWHENUSERCHANGEPASSWORD.CLICK"] = [[{av:'AV67EmailServer_SendEmailWhenUserChangePassword',fld:'vEMAILSERVER_SENDEMAILWHENUSERCHANGEPASSWORD',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLUSERCHANGEPASSWORD","Visible")',ctrl:'TBLUSERCHANGEPASSWORD',prop:'Visible'}]];
   this.EvtParms["VEMAILSERVER_SENDEMAILWHENUSERCHANGEEMAIL.CLICK"] = [[{av:'AV66EmailServer_SendEmailWhenUserChangeEmail',fld:'vEMAILSERVER_SENDEMAILWHENUSERCHANGEEMAIL',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLUSERCHANGEEMAIL","Visible")',ctrl:'TBLUSERCHANGEEMAIL',prop:'Visible'}]];
   this.EvtParms["VEMAILSERVER_SENDEMAILFORRECOVERYPASSWORD.CLICK"] = [[{av:'AV64EmailServer_SendEmailForRecoveryPassword',fld:'vEMAILSERVER_SENDEMAILFORRECOVERYPASSWORD',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLUSERRECOVERYPASSWORD","Visible")',ctrl:'TBLUSERRECOVERYPASSWORD',prop:'Visible'}]];
   this.EvtParms["VINTSECBYDOMAINENABLE.CLICK"] = [[{av:'AV88IntSecByDomainEnable',fld:'vINTSECBYDOMAINENABLE',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLINTSECBYDOMAIN","Visible")',ctrl:'TBLINTSECBYDOMAIN',prop:'Visible'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_LOGOUTBEHAVIOR"] = [[],[]];
   this.EvtParms["VALIDV_ENABLETRACING"] = [[],[]];
   this.EvtParms["VALIDV_USERIDENTIFICATION"] = [[],[]];
   this.EvtParms["VALIDV_USERACTIVATIONMETHOD"] = [[],[]];
   this.EvtParms["VALIDV_USERREMEMBERMETYPE"] = [[],[]];
   this.EvtParms["VALIDV_GENERATESESSIONSTATISTICS"] = [[],[]];
   this.EvtParms["VALIDV_INTSECBYDOMAINMODE"] = [[],[]];
   this.setVCMap("AV40SecurityAdministratorEmail", "vSECURITYADMINISTRATOREMAIL", 0, "svchar", 100, 0);
   this.setVCMap("AV8CanRegisterUsers", "vCANREGISTERUSERS", 0, "boolean", 1, 0);
   this.setVCMap("AV22Id", "vID", 0, "int", 12, 0);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0416" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_repositoryconfiguration);});
