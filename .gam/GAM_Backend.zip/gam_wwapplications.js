/*
               File: GAM_WWApplications
        Description: Applications
             Author: GeneXus .NET Generator version 18_0_4-173650
       Generated on: 7/1/2023 0:33:8.4
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwapplications', false, function () {
   this.ServerClass =  "gam_wwapplications" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwapplications.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.e220y1_client=function()
   {
      /* Search_Controlvaluechanged Routine */
      this.clearMessages();
      this.refreshOutputs([]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e190y1_client=function()
   {
      /* 'First' Routine */
      this.clearMessages();
      this.AV14CurrentPage = gx.num.trunc( 1 ,0) ;
      this.refreshOutputs([{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e200y1_client=function()
   {
      /* 'Previous' Routine */
      this.clearMessages();
      this.AV14CurrentPage = gx.num.trunc( this.AV14CurrentPage - 1 ,0) ;
      this.refreshOutputs([{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e210y1_client=function()
   {
      /* 'Next' Routine */
      this.clearMessages();
      this.AV14CurrentPage = gx.num.trunc( this.AV14CurrentPage + 1 ,0) ;
      this.refreshOutputs([{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e110y1_client=function()
   {
      /* 'Hide' Routine */
      this.clearMessages();
      if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
      {
         gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
         gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "Hide filters") );
      }
      else
      {
         gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
         gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "Show filters") );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'},{av:'gx.fn.getCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext")',ctrl:'GAM_HEADERWW_TOGGLEFILTERS',prop:'Tooltiptext'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e130y1_client=function()
   {
      /* 'Apply' Routine */
      this.clearMessages();
      this.refreshOutputs([]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e120y1_client=function()
   {
      /* 'ClearFilters' Routine */
      this.clearMessages();
      this.AV17FilterDescription =  ''  ;
      this.AV16FilterCompanyName =  ''  ;
      this.AV18FilterGUID =  ''  ;
      this.AV15FilterClientId =  ''  ;
      this.refreshOutputs([{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e140y2_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e170y2_client=function()
   {
      /* Name_Click Routine */
      return this.executeServerEvent("VNAME.CLICK", true, arguments[0], false, false);
   };
   this.e180y2_client=function()
   {
      /* Btnupd_Click Routine */
      return this.executeServerEvent("VBTNUPD.CLICK", true, arguments[0], false, false);
   };
   this.e230y2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e240y2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,38,40,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78];
   this.GXLastCtrlId =78;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",25,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwapplications",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Id",26,"vID",gx.getMessage( "Id"),"","Id","int",0,"px",12,12,"end",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   GridwwContainer.addSingleLineEdit("Name",27,"vNAME",gx.getMessage( "Application Name"),"","Name","char",0,"px",254,80,"start","e170y2_client",[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Status",28,"vSTATUS",gx.getMessage( "Status"),"","Status","svchar",100,"px",40,40,"start",null,[],"Status","Status",true,0,false,false,"",0,"column column-optional");
   GridwwContainer.addSingleLineEdit("Btnupd",29,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"start","e180y2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWW",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWW_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_HEADERWW_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_HEADERWW_ADDNEW",grid:0,evt:"e140y2_client"};
   GXValidFnc[14]={ id: 14, fld:"CELLSEARCH",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e220y1_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV12Search",gxold:"OV12Search",gxvar:"AV12Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV12Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWW_TOGGLEFILTERS",grid:0,evt:"e110y1_client"};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"SECTIONGRID",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GRIDCONTAINER",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV10Id",gxold:"OV10Id",gxvar:"AV10Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV10Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV10Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(25),gx.O.AV10Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(25),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV11Name",gxold:"OV11Name",gxvar:"AV11Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25),gx.O.AV11Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e170y2_client"};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTATUS",fmt:0,gxz:"ZV21Status",gxold:"OV21Status",gxvar:"AV21Status",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV21Status=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Status=Value},v2c:function(row){gx.fn.setGridControlValue("vSTATUS",row || gx.fn.currentGridRowImpl(25),gx.O.AV21Status,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV21Status=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vSTATUS",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[29]={ id:29 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",fmt:0,gxz:"ZV6BtnUpd",gxold:"OV6BtnUpd",gxvar:"AV6BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(25),gx.O.AV6BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e180y2_client"};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"GAM_PAGINGWW",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"GAM_PAGINGWW_TBLPAGINGBUTTONS",grid:0};
   GXValidFnc[38]={ id: 38, fld:"GAM_PAGINGWW_BTNFIRST",grid:0,evt:"e190y1_client"};
   GXValidFnc[40]={ id: 40, fld:"GAM_PAGINGWW_BTNPREVIOUS",grid:0,evt:"e200y1_client"};
   GXValidFnc[42]={ id: 42, fld:"GAM_PAGINGWW_BTNNEXT",grid:0,evt:"e210y1_client"};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id:46 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",fmt:0,gxz:"ZV14CurrentPage",gxold:"OV14CurrentPage",gxvar:"AV14CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV14CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV14CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV14CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[47]={ id: 47, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e110y1_client"};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id:58 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILTERGUID",fmt:0,gxz:"ZV18FilterGUID",gxold:"OV18FilterGUID",gxvar:"AV18FilterGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18FilterGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18FilterGUID=Value},v2c:function(){gx.fn.setControlValue("vFILTERGUID",gx.O.AV18FilterGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18FilterGUID=this.val()},val:function(){return gx.fn.getControlValue("vFILTERGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 58 , function() {
   });
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id:63 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILTERCOMPANYNAME",fmt:0,gxz:"ZV16FilterCompanyName",gxold:"OV16FilterCompanyName",gxvar:"AV16FilterCompanyName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16FilterCompanyName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16FilterCompanyName=Value},v2c:function(){gx.fn.setControlValue("vFILTERCOMPANYNAME",gx.O.AV16FilterCompanyName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16FilterCompanyName=this.val()},val:function(){return gx.fn.getControlValue("vFILTERCOMPANYNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 63 , function() {
   });
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id:68 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILTERDESCRIPTION",fmt:0,gxz:"ZV17FilterDescription",gxold:"OV17FilterDescription",gxvar:"AV17FilterDescription",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV17FilterDescription=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17FilterDescription=Value},v2c:function(){gx.fn.setControlValue("vFILTERDESCRIPTION",gx.O.AV17FilterDescription,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV17FilterDescription=this.val()},val:function(){return gx.fn.getControlValue("vFILTERDESCRIPTION")},nac:gx.falseFn};
   this.declareDomainHdlr( 68 , function() {
   });
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id:73 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILTERCLIENTID",fmt:0,gxz:"ZV15FilterClientId",gxold:"OV15FilterClientId",gxvar:"AV15FilterClientId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15FilterClientId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15FilterClientId=Value},v2c:function(){gx.fn.setControlValue("vFILTERCLIENTID",gx.O.AV15FilterClientId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15FilterClientId=this.val()},val:function(){return gx.fn.getControlValue("vFILTERCLIENTID")},nac:gx.falseFn};
   this.declareDomainHdlr( 73 , function() {
   });
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e120y1_client"};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e130y1_client"};
   this.AV12Search = "" ;
   this.ZV12Search = "" ;
   this.OV12Search = "" ;
   this.ZV10Id = 0 ;
   this.OV10Id = 0 ;
   this.ZV11Name = "" ;
   this.OV11Name = "" ;
   this.ZV21Status = "" ;
   this.OV21Status = "" ;
   this.ZV6BtnUpd = "" ;
   this.OV6BtnUpd = "" ;
   this.AV14CurrentPage = 0 ;
   this.ZV14CurrentPage = 0 ;
   this.OV14CurrentPage = 0 ;
   this.AV18FilterGUID = "" ;
   this.ZV18FilterGUID = "" ;
   this.OV18FilterGUID = "" ;
   this.AV16FilterCompanyName = "" ;
   this.ZV16FilterCompanyName = "" ;
   this.OV16FilterCompanyName = "" ;
   this.AV17FilterDescription = "" ;
   this.ZV17FilterDescription = "" ;
   this.OV17FilterDescription = "" ;
   this.AV15FilterClientId = "" ;
   this.ZV15FilterClientId = "" ;
   this.OV15FilterClientId = "" ;
   this.AV12Search = "" ;
   this.AV14CurrentPage = 0 ;
   this.AV18FilterGUID = "" ;
   this.AV16FilterCompanyName = "" ;
   this.AV17FilterDescription = "" ;
   this.AV15FilterClientId = "" ;
   this.AV10Id = 0 ;
   this.AV11Name = "" ;
   this.AV21Status = "" ;
   this.AV6BtnUpd = "" ;
   this.Events = {"e140y2_client": ["'ADDNEW'", true] ,"e170y2_client": ["VNAME.CLICK", true] ,"e180y2_client": ["VBTNUPD.CLICK", true] ,"e230y2_client": ["ENTER", true] ,"e240y2_client": ["CANCEL", true] ,"e220y1_client": ["VSEARCH.CONTROLVALUECHANGED", false] ,"e190y1_client": ["'FIRST'", false] ,"e200y1_client": ["'PREVIOUS'", false] ,"e210y1_client": ["'NEXT'", false] ,"e110y1_client": ["'HIDE'", false] ,"e130y1_client": ["'APPLY'", false] ,"e120y1_client": ["'CLEARFILTERS'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[{av:'AV6BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV11Name',fld:'vNAME',pic:''},{av:'AV21Status',fld:'vSTATUS',pic:''},{av:'gx.fn.getCtrlProperty("vSTATUS","Class")',ctrl:'vSTATUS',prop:'Class'},{ctrl:'GAM_PAGINGWW_BTNNEXT',prop:'Enabled'},{ctrl:'GAM_PAGINGWW_BTNFIRST',prop:'Enabled'},{ctrl:'GAM_PAGINGWW_BTNPREVIOUS',prop:'Enabled'}]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[]];
   this.EvtParms["'ADDNEW'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''},{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''},{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV10Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'FIRST'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["'PREVIOUS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["'NEXT'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["'HIDE'"] = [[{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'}],[{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'},{av:'gx.fn.getCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext")',ctrl:'GAM_HEADERWW_TOGGLEFILTERS',prop:'Tooltiptext'}]];
   this.EvtParms["'APPLY'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[]];
   this.EvtParms["'CLEARFILTERS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV14CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV12Search',fld:'vSEARCH',pic:''},{av:'AV18FilterGUID',fld:'vFILTERGUID',pic:''},{av:'AV16FilterCompanyName',fld:'vFILTERCOMPANYNAME',pic:''},{av:'AV17FilterDescription',fld:'vFILTERDESCRIPTION',pic:''},{av:'AV15FilterClientId',fld:'vFILTERCLIENTID',pic:''},{av:'subGridww_Recordcount'}],[]];
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[46]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[58]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[63]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[68]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[73]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[46]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[58]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[63]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[68]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[73]);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_wwapplications);});
