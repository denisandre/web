/*
               File: GAM_ApplicationEntry
        Description: Application
             Author: GeneXus .NET Generator version 18_0_4-173650
       Generated on: 7/1/2023 0:33:51.44
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_applicationentry', false, function () {
   this.ServerClass =  "gam_applicationentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_applicationentry.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
   };
   this.Validv_Clientrevoked=function()
   {
      return this.validCliEvt("Validv_Clientrevoked", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vCLIENTREVOKED");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV18ClientRevoked)===0) || new gx.date.gxdate( this.AV18ClientRevoked ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Client Revoked"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Ssorestmode=function()
   {
      return this.validCliEvt("Validv_Ssorestmode", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vSSORESTMODE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV63SSORestMode , "server" ) == 0 || gx.text.compare( this.AV63SSORestMode , "client" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Mode SSO Rest "), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Stsmode=function()
   {
      return this.validCliEvt("Validv_Stsmode", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vSTSMODE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV48STSMode , "server" ) == 0 || gx.text.compare( this.AV48STSMode , "gettoken" ) == 0 || gx.text.compare( this.AV48STSMode , "checktoken" ) == 0 || gx.text.compare( this.AV48STSMode , "fulltoken" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "STSMode"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s122_client=function()
   {
      /* 'UI_REMOTEAUTHENTICATIONWEB' Routine */
      if ( this.AV11ClientAllowRemoteAuth )
      {
         gx.fn.setCtrlProperty("TBLWEBAUTH","Visible", true );
         gx.fn.setCtrlProperty("TBLGENERALAUTH","Visible", true );
      }
      else
      {
         gx.fn.setCtrlProperty("TBLWEBAUTH","Visible", false );
         if ( ! this.AV61ClientAllowRemoteRestAuth )
         {
            gx.fn.setCtrlProperty("TBLGENERALAUTH","Visible", false );
         }
      }
   };
   this.s132_client=function()
   {
      /* 'UI_REMOTEAUTHENTICATIONREST' Routine */
      if ( this.AV61ClientAllowRemoteRestAuth )
      {
         gx.fn.setCtrlProperty("TBLRESTAUTH","Visible", true );
         gx.fn.setCtrlProperty("TBLGENERALAUTH","Visible", true );
      }
      else
      {
         gx.fn.setCtrlProperty("TBLRESTAUTH","Visible", false );
         if ( ! this.AV11ClientAllowRemoteAuth )
         {
            gx.fn.setCtrlProperty("TBLGENERALAUTH","Visible", false );
         }
      }
   };
   this.s142_client=function()
   {
      /* 'UI_SSOREST' Routine */
      if ( this.AV62SSORestEnable )
      {
         gx.fn.setCtrlProperty("TABLESSOREST","Visible", true );
         if ( gx.text.compare( this.AV63SSORestMode , "server" ) == 0 )
         {
            gx.fn.setCtrlProperty("TBLSSORESTMODECLIENT","Visible", false );
         }
         else if ( gx.text.compare( this.AV63SSORestMode , "client" ) == 0 )
         {
            gx.fn.setCtrlProperty("TBLSSORESTMODECLIENT","Visible", true );
         }
      }
      else
      {
         gx.fn.setCtrlProperty("TABLESSOREST","Visible", false );
      }
   };
   this.s162_client=function()
   {
      /* 'UI_STSPROTOCOL' Routine */
      if ( this.AV46STSProtocolEnable )
      {
         gx.fn.setCtrlProperty("TABLESTS","Visible", true );
         if ( gx.text.compare( this.AV48STSMode , "server" ) == 0 )
         {
            gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", true );
            gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", false );
            gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", false );
         }
         else if ( gx.text.compare( this.AV48STSMode , "gettoken" ) == 0 )
         {
            gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", false );
            gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", true );
            gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", true );
         }
         else if ( gx.text.compare( this.AV48STSMode , "checktoken" ) == 0 )
         {
            gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", true );
            gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", false );
            gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", true );
         }
         else if ( gx.text.compare( this.AV48STSMode , "fulltoken" ) == 0 )
         {
            gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", true );
            gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", true );
            gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", true );
         }
      }
      else
      {
         gx.fn.setCtrlProperty("TABLESTS","Visible", false );
      }
   };
   this.s172_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e22101_client=function()
   {
      /* Gam_headerentry_tableback_Click Routine */
      this.clearMessages();
      this.call("gam_wwapplications.aspx", [], null, []);
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e23101_client=function()
   {
      /* Clientallowremoteauth_Click Routine */
      this.clearMessages();
      this.s122_client();
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBLGENERALAUTH","Visible")',ctrl:'TBLGENERALAUTH',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLWEBAUTH","Visible")',ctrl:'TBLWEBAUTH',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e24101_client=function()
   {
      /* Clientallowremoterestauth_Click Routine */
      this.clearMessages();
      this.s132_client();
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBLGENERALAUTH","Visible")',ctrl:'TBLGENERALAUTH',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLRESTAUTH","Visible")',ctrl:'TBLRESTAUTH',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e12101_client=function()
   {
      /* 'Delete' Routine */
      this.clearMessages();
      this.call("gam_applicationentry.aspx", ["DLT", this.AV37Id], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e13101_client=function()
   {
      /* 'Permissions' Routine */
      this.clearMessages();
      this.call("gam_wwapppermissions.aspx", [this.AV37Id], null, ["ApplicationId"]);
      this.refreshOutputs([{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e14101_client=function()
   {
      /* 'Menus' Routine */
      this.clearMessages();
      this.call("gam_wwappmenus.aspx", [this.AV37Id], null, ["ApplicationId"]);
      this.refreshOutputs([{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e11101_client=function()
   {
      /* 'Edit' Routine */
      this.clearMessages();
      this.call("gam_applicationentry.aspx", ["UPD", this.AV37Id], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e15101_client=function()
   {
      /* Ssorestmode_Click Routine */
      this.clearMessages();
      this.s142_client();
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBLSSORESTMODECLIENT","Visible")',ctrl:'TBLSSORESTMODECLIENT',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESSOREST","Visible")',ctrl:'TABLESSOREST',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e25101_client=function()
   {
      /* Stsprotocolenable_Click Routine */
      this.clearMessages();
      this.s162_client();
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible")',ctrl:'TABLESTSSERVERCHECKTOKEN',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible")',ctrl:'TABLESTSCLIENTGETTOKEN',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTSCLIENT","Visible")',ctrl:'TABLESTSCLIENT',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTS","Visible")',ctrl:'TABLESTS',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e26101_client=function()
   {
      /* Stsmode_Controlvaluechanged Routine */
      this.clearMessages();
      if ( gx.text.compare( this.AV48STSMode , "server" ) == 0 )
      {
         gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", true );
         gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", false );
         gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", false );
      }
      else if ( gx.text.compare( this.AV48STSMode , "gettoken" ) == 0 )
      {
         gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", false );
         gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", true );
         gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", true );
      }
      else if ( gx.text.compare( this.AV48STSMode , "checktoken" ) == 0 )
      {
         gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", true );
         gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", false );
         gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", true );
      }
      else if ( gx.text.compare( this.AV48STSMode , "fulltoken" ) == 0 )
      {
         gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", true );
         gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", true );
         gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", true );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible")',ctrl:'TABLESTSSERVERCHECKTOKEN',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible")',ctrl:'TABLESTSCLIENTGETTOKEN',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTSCLIENT","Visible")',ctrl:'TABLESTSCLIENT',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e27101_client=function()
   {
      /* Ssorestenable_Controlvaluechanged Routine */
      this.clearMessages();
      this.s142_client();
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBLSSORESTMODECLIENT","Visible")',ctrl:'TBLSSORESTMODECLIENT',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESSOREST","Visible")',ctrl:'TABLESSOREST',prop:'Visible'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e17102_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e18102_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e19102_client=function()
   {
      /* 'GenerateKeyGAMRemote' Routine */
      return this.executeServerEvent("'GENERATEKEYGAMREMOTE'", false, null, false, false);
   };
   this.e20102_client=function()
   {
      /* 'Revoke-Authorize' Routine */
      return this.executeServerEvent("'REVOKE-AUTHORIZE'", true, null, false, false);
   };
   this.e28102_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e29102_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,140,141,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,258,259,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,289,290,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,340,341,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,382,383,384,385,386,387,388,389,390,391];
   this.GXLastCtrlId =391;
   this.TAB2Container = gx.uc.getNew(this, 138, 59, "gx.ui.controls.BasicTab", "TAB2Container", "Tab2", "TAB2");
   var TAB2Container = this.TAB2Container;
   TAB2Container.setProp("Enabled", "Enabled", true, "boolean");
   TAB2Container.setProp("ActivePage", "Activepage", '', "int");
   TAB2Container.setProp("ActivePageControlName", "Activepagecontrolname", "", "char");
   TAB2Container.setProp("PageCount", "Pagecount", 4, "num");
   TAB2Container.setProp("Class", "Class", "Tab", "str");
   TAB2Container.setProp("HistoryManagement", "Historymanagement", false, "bool");
   TAB2Container.setProp("Visible", "Visible", true, "bool");
   TAB2Container.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(TAB2Container);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERENTRY",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERENTRY_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERENTRY_TABLEBACK",grid:0,evt:"e22101_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERENTRY_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERENTRY_TABLETITLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERENTRY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERENTRY_TXTSTATUS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GAM_HEADERENTRY_TBLTOOLBARS",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"GAM_HEADERENTRY_BUTTONSTOOLBAR_INNER",grid:0};
   GXValidFnc[30]={ id: 30, fld:"BUTTONEDIT", format:0,grid:0,evt:"e11101_client", ctrltype: "textblock"};
   GXValidFnc[31]={ id: 31, fld:"BUTTONDELETE", format:0,grid:0,evt:"e12101_client", ctrltype: "textblock"};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"GAM_HEADERENTRY_MENUTABLE",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[38]={ id: 38, fld:"GAM_HEADERENTRY_MENUTOOLBAR_INNER",grid:0};
   GXValidFnc[39]={ id: 39, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[40]={ id: 40, fld:"BUTTONPERMISSIONS", format:0,grid:0,evt:"e13101_client", ctrltype: "textblock"};
   GXValidFnc[41]={ id: 41, fld:"BUTTONMENU", format:0,grid:0,evt:"e14101_client", ctrltype: "textblock"};
   GXValidFnc[42]={ id: 42, fld:"BUTTONREVOKE", format:0,grid:0,evt:"e20102_client", ctrltype: "textblock"};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"GAM_DATACARD",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"GAM_DATACARD_TABLEGENERALTITLE",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"GAM_DATACARD_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"GAM_DATACARD_TABLEDATAGENERAL",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id:59 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV37Id",gxold:"OV37Id",gxvar:"AV37Id",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV37Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV37Id=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vID",gx.O.AV37Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV37Id=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 59 , function() {
   });
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id:64 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",fmt:0,gxz:"ZV35GUID",gxold:"OV35GUID",gxvar:"AV35GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV35GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV35GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV35GUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV35GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 64 , function() {
   });
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id:69 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV43Name",gxold:"OV43Name",gxvar:"AV43Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV43Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV43Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV43Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV43Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 69 , function() {
   });
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id:74 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV22Dsc",gxold:"OV22Dsc",gxvar:"AV22Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV22Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV22Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV22Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV22Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 74 , function() {
   });
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id:79 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vVERSION",fmt:0,gxz:"ZV54Version",gxold:"OV54Version",gxvar:"AV54Version",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV54Version=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV54Version=Value},v2c:function(){gx.fn.setControlValue("vVERSION",gx.O.AV54Version,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV54Version=this.val()},val:function(){return gx.fn.getControlValue("vVERSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 79 , function() {
   });
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id:84 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOMPANY",fmt:0,gxz:"ZV20Company",gxold:"OV20Company",gxvar:"AV20Company",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV20Company=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20Company=Value},v2c:function(){gx.fn.setControlValue("vCOMPANY",gx.O.AV20Company,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20Company=this.val()},val:function(){return gx.fn.getControlValue("vCOMPANY")},nac:gx.falseFn};
   this.declareDomainHdlr( 84 , function() {
   });
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   GXValidFnc[87]={ id: 87, fld:"",grid:0};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id:89 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOPYRIGHT",fmt:0,gxz:"ZV21Copyright",gxold:"OV21Copyright",gxvar:"AV21Copyright",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV21Copyright=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Copyright=Value},v2c:function(){gx.fn.setControlValue("vCOPYRIGHT",gx.O.AV21Copyright,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV21Copyright=this.val()},val:function(){return gx.fn.getControlValue("vCOPYRIGHT")},nac:gx.falseFn};
   this.declareDomainHdlr( 89 , function() {
   });
   GXValidFnc[90]={ id: 90, fld:"",grid:0};
   GXValidFnc[91]={ id: 91, fld:"",grid:0};
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id:94 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSEABSOLUTEURLBYENVIRONMENT",fmt:0,gxz:"ZV51UseAbsoluteUrlByEnvironment",gxold:"OV51UseAbsoluteUrlByEnvironment",gxvar:"AV51UseAbsoluteUrlByEnvironment",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV51UseAbsoluteUrlByEnvironment=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV51UseAbsoluteUrlByEnvironment=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vUSEABSOLUTEURLBYENVIRONMENT",gx.O.AV51UseAbsoluteUrlByEnvironment,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV51UseAbsoluteUrlByEnvironment=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vUSEABSOLUTEURLBYENVIRONMENT")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 94 , function() {
   });
   GXValidFnc[95]={ id: 95, fld:"",grid:0};
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id: 98, fld:"",grid:0};
   GXValidFnc[99]={ id:99 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vHOMEOBJECT",fmt:0,gxz:"ZV36HomeObject",gxold:"OV36HomeObject",gxvar:"AV36HomeObject",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV36HomeObject=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV36HomeObject=Value},v2c:function(){gx.fn.setControlValue("vHOMEOBJECT",gx.O.AV36HomeObject,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV36HomeObject=this.val()},val:function(){return gx.fn.getControlValue("vHOMEOBJECT")},nac:gx.falseFn};
   this.declareDomainHdlr( 99 , function() {
   });
   GXValidFnc[100]={ id: 100, fld:"",grid:0};
   GXValidFnc[101]={ id: 101, fld:"",grid:0};
   GXValidFnc[102]={ id: 102, fld:"",grid:0};
   GXValidFnc[103]={ id: 103, fld:"",grid:0};
   GXValidFnc[104]={ id:104 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCOUNTACTIVATIONOBJECT",fmt:0,gxz:"ZV68AccountActivationObject",gxold:"OV68AccountActivationObject",gxvar:"AV68AccountActivationObject",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV68AccountActivationObject=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV68AccountActivationObject=Value},v2c:function(){gx.fn.setControlValue("vACCOUNTACTIVATIONOBJECT",gx.O.AV68AccountActivationObject,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV68AccountActivationObject=this.val()},val:function(){return gx.fn.getControlValue("vACCOUNTACTIVATIONOBJECT")},nac:gx.falseFn};
   this.declareDomainHdlr( 104 , function() {
   });
   GXValidFnc[105]={ id: 105, fld:"",grid:0};
   GXValidFnc[106]={ id: 106, fld:"",grid:0};
   GXValidFnc[107]={ id: 107, fld:"",grid:0};
   GXValidFnc[108]={ id: 108, fld:"",grid:0};
   GXValidFnc[109]={ id:109 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLOGOUTOBJECT",fmt:0,gxz:"ZV39LogoutObject",gxold:"OV39LogoutObject",gxvar:"AV39LogoutObject",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV39LogoutObject=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV39LogoutObject=Value},v2c:function(){gx.fn.setControlValue("vLOGOUTOBJECT",gx.O.AV39LogoutObject,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV39LogoutObject=this.val()},val:function(){return gx.fn.getControlValue("vLOGOUTOBJECT")},nac:gx.falseFn};
   this.declareDomainHdlr( 109 , function() {
   });
   GXValidFnc[110]={ id: 110, fld:"",grid:0};
   GXValidFnc[111]={ id: 111, fld:"",grid:0};
   GXValidFnc[112]={ id: 112, fld:"",grid:0};
   GXValidFnc[113]={ id: 113, fld:"",grid:0};
   GXValidFnc[114]={ id:114 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMAINMENU",fmt:0,gxz:"ZV40MainMenu",gxold:"OV40MainMenu",gxvar:"AV40MainMenu",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV40MainMenu=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV40MainMenu=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vMAINMENU",gx.O.AV40MainMenu)},c2v:function(){if(this.val()!==undefined)gx.O.AV40MainMenu=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vMAINMENU",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[115]={ id: 115, fld:"",grid:0};
   GXValidFnc[116]={ id: 116, fld:"",grid:0};
   GXValidFnc[117]={ id: 117, fld:"",grid:0};
   GXValidFnc[118]={ id: 118, fld:"",grid:0};
   GXValidFnc[119]={ id:119 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCESSREQUIRESPERMISSION",fmt:0,gxz:"ZV5AccessRequiresPermission",gxold:"OV5AccessRequiresPermission",gxvar:"AV5AccessRequiresPermission",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV5AccessRequiresPermission=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV5AccessRequiresPermission=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vACCESSREQUIRESPERMISSION",gx.O.AV5AccessRequiresPermission,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5AccessRequiresPermission=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vACCESSREQUIRESPERMISSION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 119 , function() {
   });
   GXValidFnc[120]={ id: 120, fld:"",grid:0};
   GXValidFnc[121]={ id: 121, fld:"",grid:0};
   GXValidFnc[122]={ id: 122, fld:"",grid:0};
   GXValidFnc[123]={ id: 123, fld:"",grid:0};
   GXValidFnc[124]={ id:124 ,lvl:0,type:"dtime",len:10,dec:5,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Clientrevoked,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTREVOKED",fmt:0,gxz:"ZV18ClientRevoked",gxold:"OV18ClientRevoked",gxvar:"AV18ClientRevoked",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/9999 99:99",dec:5},ucs:[],op:[124],ip:[124],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18ClientRevoked=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV18ClientRevoked=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vCLIENTREVOKED",gx.O.AV18ClientRevoked,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18ClientRevoked=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getDateTimeValue("vCLIENTREVOKED")},nac:gx.falseFn};
   this.declareDomainHdlr( 124 , function() {
   });
   GXValidFnc[125]={ id: 125, fld:"",grid:0};
   GXValidFnc[126]={ id: 126, fld:"STENCIL1",grid:0};
   GXValidFnc[127]={ id: 127, fld:"",grid:0};
   GXValidFnc[128]={ id: 128, fld:"",grid:0};
   GXValidFnc[129]={ id: 129, fld:"STENCIL1_TABLEGENERALTITLE",grid:0};
   GXValidFnc[130]={ id: 130, fld:"",grid:0};
   GXValidFnc[131]={ id: 131, fld:"",grid:0};
   GXValidFnc[132]={ id: 132, fld:"STENCIL1_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[133]={ id: 133, fld:"",grid:0};
   GXValidFnc[134]={ id: 134, fld:"",grid:0};
   GXValidFnc[135]={ id: 135, fld:"STENCIL1_TABLEDATAGENERAL",grid:0};
   GXValidFnc[136]={ id: 136, fld:"",grid:0};
   GXValidFnc[137]={ id: 137, fld:"",grid:0};
   GXValidFnc[140]={ id: 140, fld:"TABPAGE3_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[141]={ id: 141, fld:"",grid:0};
   GXValidFnc[143]={ id: 143, fld:"TABPAGE3TABLE1",grid:0};
   GXValidFnc[144]={ id: 144, fld:"",grid:0};
   GXValidFnc[145]={ id: 145, fld:"",grid:0};
   GXValidFnc[146]={ id: 146, fld:"",grid:0};
   GXValidFnc[147]={ id: 147, fld:"",grid:0};
   GXValidFnc[148]={ id:148 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTID",fmt:0,gxz:"ZV14ClientId",gxold:"OV14ClientId",gxvar:"AV14ClientId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14ClientId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14ClientId=Value},v2c:function(){gx.fn.setControlValue("vCLIENTID",gx.O.AV14ClientId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14ClientId=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTID")},nac:gx.falseFn};
   this.declareDomainHdlr( 148 , function() {
   });
   GXValidFnc[149]={ id: 149, fld:"",grid:0};
   GXValidFnc[150]={ id: 150, fld:"",grid:0};
   GXValidFnc[151]={ id: 151, fld:"",grid:0};
   GXValidFnc[152]={ id: 152, fld:"",grid:0};
   GXValidFnc[153]={ id:153 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTSECRET",fmt:0,gxz:"ZV19ClientSecret",gxold:"OV19ClientSecret",gxvar:"AV19ClientSecret",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV19ClientSecret=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19ClientSecret=Value},v2c:function(){gx.fn.setControlValue("vCLIENTSECRET",gx.O.AV19ClientSecret,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV19ClientSecret=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTSECRET")},nac:gx.falseFn};
   this.declareDomainHdlr( 153 , function() {
   });
   GXValidFnc[154]={ id: 154, fld:"",grid:0};
   GXValidFnc[155]={ id: 155, fld:"",grid:0};
   GXValidFnc[156]={ id: 156, fld:"",grid:0};
   GXValidFnc[157]={ id: 157, fld:"",grid:0};
   GXValidFnc[158]={ id:158 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTACCESSUNIQUEBYUSER",fmt:0,gxz:"ZV8ClientAccessUniqueByUser",gxold:"OV8ClientAccessUniqueByUser",gxvar:"AV8ClientAccessUniqueByUser",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV8ClientAccessUniqueByUser=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV8ClientAccessUniqueByUser=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTACCESSUNIQUEBYUSER",gx.O.AV8ClientAccessUniqueByUser,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV8ClientAccessUniqueByUser=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTACCESSUNIQUEBYUSER")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[159]={ id: 159, fld:"",grid:0};
   GXValidFnc[160]={ id: 160, fld:"",grid:0};
   GXValidFnc[161]={ id: 161, fld:"GROUP1",grid:0};
   GXValidFnc[162]={ id: 162, fld:"GROUP1TABLE1",grid:0};
   GXValidFnc[163]={ id: 163, fld:"",grid:0};
   GXValidFnc[164]={ id: 164, fld:"",grid:0};
   GXValidFnc[165]={ id: 165, fld:"",grid:0};
   GXValidFnc[166]={ id: 166, fld:"",grid:0};
   GXValidFnc[167]={ id:167 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWREMOTEAUTH",fmt:0,gxz:"ZV11ClientAllowRemoteAuth",gxold:"OV11ClientAllowRemoteAuth",gxvar:"AV11ClientAllowRemoteAuth",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV11ClientAllowRemoteAuth=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV11ClientAllowRemoteAuth=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWREMOTEAUTH",gx.O.AV11ClientAllowRemoteAuth,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11ClientAllowRemoteAuth=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWREMOTEAUTH")},nac:gx.falseFn,evt:"e23101_client",values:['true','false']};
   this.declareDomainHdlr( 167 , function() {
   });
   GXValidFnc[168]={ id: 168, fld:"",grid:0};
   GXValidFnc[169]={ id: 169, fld:"",grid:0};
   GXValidFnc[170]={ id: 170, fld:"TBLWEBAUTH",grid:0};
   GXValidFnc[171]={ id: 171, fld:"",grid:0};
   GXValidFnc[172]={ id: 172, fld:"",grid:0};
   GXValidFnc[173]={ id: 173, fld:"",grid:0};
   GXValidFnc[174]={ id: 174, fld:"",grid:0};
   GXValidFnc[175]={ id:175 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERROLES",fmt:0,gxz:"ZV10ClientAllowGetUserRoles",gxold:"OV10ClientAllowGetUserRoles",gxvar:"AV10ClientAllowGetUserRoles",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV10ClientAllowGetUserRoles=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV10ClientAllowGetUserRoles=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERROLES",gx.O.AV10ClientAllowGetUserRoles,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10ClientAllowGetUserRoles=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERROLES")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 175 , function() {
   });
   GXValidFnc[176]={ id: 176, fld:"",grid:0};
   GXValidFnc[177]={ id: 177, fld:"",grid:0};
   GXValidFnc[178]={ id: 178, fld:"",grid:0};
   GXValidFnc[179]={ id: 179, fld:"",grid:0};
   GXValidFnc[180]={ id:180 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERADDDATA",fmt:0,gxz:"ZV9ClientAllowGetUserAddData",gxold:"OV9ClientAllowGetUserAddData",gxvar:"AV9ClientAllowGetUserAddData",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV9ClientAllowGetUserAddData=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV9ClientAllowGetUserAddData=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERADDDATA",gx.O.AV9ClientAllowGetUserAddData,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV9ClientAllowGetUserAddData=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERADDDATA")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 180 , function() {
   });
   GXValidFnc[181]={ id: 181, fld:"",grid:0};
   GXValidFnc[182]={ id: 182, fld:"",grid:0};
   GXValidFnc[183]={ id: 183, fld:"",grid:0};
   GXValidFnc[184]={ id: 184, fld:"",grid:0};
   GXValidFnc[185]={ id:185 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETSESSIONINIPROP",fmt:0,gxz:"ZV57ClientAllowGetSessionIniProp",gxold:"OV57ClientAllowGetSessionIniProp",gxvar:"AV57ClientAllowGetSessionIniProp",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV57ClientAllowGetSessionIniProp=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV57ClientAllowGetSessionIniProp=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETSESSIONINIPROP",gx.O.AV57ClientAllowGetSessionIniProp,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV57ClientAllowGetSessionIniProp=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETSESSIONINIPROP")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 185 , function() {
   });
   GXValidFnc[186]={ id: 186, fld:"",grid:0};
   GXValidFnc[187]={ id: 187, fld:"",grid:0};
   GXValidFnc[188]={ id: 188, fld:"",grid:0};
   GXValidFnc[189]={ id: 189, fld:"",grid:0};
   GXValidFnc[190]={ id:190 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTIMAGEURL",fmt:0,gxz:"ZV15ClientImageURL",gxold:"OV15ClientImageURL",gxvar:"AV15ClientImageURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15ClientImageURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15ClientImageURL=Value},v2c:function(){gx.fn.setControlValue("vCLIENTIMAGEURL",gx.O.AV15ClientImageURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15ClientImageURL=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTIMAGEURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 190 , function() {
   });
   GXValidFnc[191]={ id: 191, fld:"",grid:0};
   GXValidFnc[192]={ id: 192, fld:"",grid:0};
   GXValidFnc[193]={ id: 193, fld:"",grid:0};
   GXValidFnc[194]={ id: 194, fld:"",grid:0};
   GXValidFnc[195]={ id:195 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTLOCALLOGINURL",fmt:0,gxz:"ZV16ClientLocalLoginURL",gxold:"OV16ClientLocalLoginURL",gxvar:"AV16ClientLocalLoginURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16ClientLocalLoginURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16ClientLocalLoginURL=Value},v2c:function(){gx.fn.setControlValue("vCLIENTLOCALLOGINURL",gx.O.AV16ClientLocalLoginURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16ClientLocalLoginURL=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTLOCALLOGINURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 195 , function() {
   });
   GXValidFnc[196]={ id: 196, fld:"",grid:0};
   GXValidFnc[197]={ id: 197, fld:"",grid:0};
   GXValidFnc[198]={ id: 198, fld:"",grid:0};
   GXValidFnc[199]={ id: 199, fld:"",grid:0};
   GXValidFnc[200]={ id:200 ,lvl:0,type:"vchar",len:32768,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTCALLBACKURL",fmt:0,gxz:"ZV12ClientCallbackURL",gxold:"OV12ClientCallbackURL",gxvar:"AV12ClientCallbackURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12ClientCallbackURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12ClientCallbackURL=Value},v2c:function(){gx.fn.setControlValue("vCLIENTCALLBACKURL",gx.O.AV12ClientCallbackURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12ClientCallbackURL=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTCALLBACKURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 200 , function() {
   });
   GXValidFnc[201]={ id: 201, fld:"",grid:0};
   GXValidFnc[202]={ id: 202, fld:"",grid:0};
   GXValidFnc[203]={ id: 203, fld:"",grid:0};
   GXValidFnc[204]={ id: 204, fld:"",grid:0};
   GXValidFnc[205]={ id:205 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTCALLBACKURLISCUSTOM",fmt:0,gxz:"ZV66ClientCallbackURLisCustom",gxold:"OV66ClientCallbackURLisCustom",gxvar:"AV66ClientCallbackURLisCustom",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV66ClientCallbackURLisCustom=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV66ClientCallbackURLisCustom=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTCALLBACKURLISCUSTOM",gx.O.AV66ClientCallbackURLisCustom,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV66ClientCallbackURLisCustom=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTCALLBACKURLISCUSTOM")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 205 , function() {
   });
   GXValidFnc[206]={ id: 206, fld:"",grid:0};
   GXValidFnc[207]={ id: 207, fld:"",grid:0};
   GXValidFnc[208]={ id: 208, fld:"",grid:0};
   GXValidFnc[209]={ id: 209, fld:"",grid:0};
   GXValidFnc[210]={ id:210 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTCALLBACKURLSTATENAME",fmt:0,gxz:"ZV67ClientCallbackURLStateName",gxold:"OV67ClientCallbackURLStateName",gxvar:"AV67ClientCallbackURLStateName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV67ClientCallbackURLStateName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV67ClientCallbackURLStateName=Value},v2c:function(){gx.fn.setControlValue("vCLIENTCALLBACKURLSTATENAME",gx.O.AV67ClientCallbackURLStateName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV67ClientCallbackURLStateName=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTCALLBACKURLSTATENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 210 , function() {
   });
   GXValidFnc[211]={ id: 211, fld:"",grid:0};
   GXValidFnc[212]={ id: 212, fld:"",grid:0};
   GXValidFnc[213]={ id: 213, fld:"GROUP2",grid:0};
   GXValidFnc[214]={ id: 214, fld:"GROUP2TABLE1",grid:0};
   GXValidFnc[215]={ id: 215, fld:"",grid:0};
   GXValidFnc[216]={ id: 216, fld:"",grid:0};
   GXValidFnc[217]={ id: 217, fld:"",grid:0};
   GXValidFnc[218]={ id: 218, fld:"",grid:0};
   GXValidFnc[219]={ id:219 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWREMOTERESTAUTH",fmt:0,gxz:"ZV61ClientAllowRemoteRestAuth",gxold:"OV61ClientAllowRemoteRestAuth",gxvar:"AV61ClientAllowRemoteRestAuth",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV61ClientAllowRemoteRestAuth=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV61ClientAllowRemoteRestAuth=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWREMOTERESTAUTH",gx.O.AV61ClientAllowRemoteRestAuth,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV61ClientAllowRemoteRestAuth=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWREMOTERESTAUTH")},nac:gx.falseFn,evt:"e24101_client",values:['true','false']};
   this.declareDomainHdlr( 219 , function() {
   });
   GXValidFnc[220]={ id: 220, fld:"",grid:0};
   GXValidFnc[221]={ id: 221, fld:"",grid:0};
   GXValidFnc[222]={ id: 222, fld:"TBLRESTAUTH",grid:0};
   GXValidFnc[223]={ id: 223, fld:"",grid:0};
   GXValidFnc[224]={ id: 224, fld:"",grid:0};
   GXValidFnc[225]={ id: 225, fld:"",grid:0};
   GXValidFnc[226]={ id: 226, fld:"",grid:0};
   GXValidFnc[227]={ id:227 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERROLESREST",fmt:0,gxz:"ZV60ClientAllowGetUserRolesRest",gxold:"OV60ClientAllowGetUserRolesRest",gxvar:"AV60ClientAllowGetUserRolesRest",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV60ClientAllowGetUserRolesRest=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV60ClientAllowGetUserRolesRest=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERROLESREST",gx.O.AV60ClientAllowGetUserRolesRest,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV60ClientAllowGetUserRolesRest=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERROLESREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 227 , function() {
   });
   GXValidFnc[228]={ id: 228, fld:"",grid:0};
   GXValidFnc[229]={ id: 229, fld:"",grid:0};
   GXValidFnc[230]={ id: 230, fld:"",grid:0};
   GXValidFnc[231]={ id: 231, fld:"",grid:0};
   GXValidFnc[232]={ id:232 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERADDDATAREST",fmt:0,gxz:"ZV59ClientAllowGetUserAddDataRest",gxold:"OV59ClientAllowGetUserAddDataRest",gxvar:"AV59ClientAllowGetUserAddDataRest",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV59ClientAllowGetUserAddDataRest=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV59ClientAllowGetUserAddDataRest=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERADDDATAREST",gx.O.AV59ClientAllowGetUserAddDataRest,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV59ClientAllowGetUserAddDataRest=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERADDDATAREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 232 , function() {
   });
   GXValidFnc[233]={ id: 233, fld:"",grid:0};
   GXValidFnc[234]={ id: 234, fld:"",grid:0};
   GXValidFnc[235]={ id: 235, fld:"",grid:0};
   GXValidFnc[236]={ id: 236, fld:"",grid:0};
   GXValidFnc[237]={ id:237 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETSESSIONINIPROPREST",fmt:0,gxz:"ZV58ClientAllowGetSessionIniPropRest",gxold:"OV58ClientAllowGetSessionIniPropRest",gxvar:"AV58ClientAllowGetSessionIniPropRest",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV58ClientAllowGetSessionIniPropRest=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV58ClientAllowGetSessionIniPropRest=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETSESSIONINIPROPREST",gx.O.AV58ClientAllowGetSessionIniPropRest,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV58ClientAllowGetSessionIniPropRest=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETSESSIONINIPROPREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 237 , function() {
   });
   GXValidFnc[238]={ id: 238, fld:"",grid:0};
   GXValidFnc[239]={ id: 239, fld:"",grid:0};
   GXValidFnc[240]={ id: 240, fld:"TBLGENERALAUTH",grid:0};
   GXValidFnc[241]={ id: 241, fld:"",grid:0};
   GXValidFnc[242]={ id: 242, fld:"",grid:0};
   GXValidFnc[243]={ id: 243, fld:"GROUP3",grid:0};
   GXValidFnc[244]={ id: 244, fld:"GROUP3TABLE1",grid:0};
   GXValidFnc[245]={ id: 245, fld:"",grid:0};
   GXValidFnc[246]={ id: 246, fld:"",grid:0};
   GXValidFnc[247]={ id: 247, fld:"",grid:0};
   GXValidFnc[248]={ id: 248, fld:"",grid:0};
   GXValidFnc[249]={ id:249 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTENCRYPTIONKEY",fmt:0,gxz:"ZV13ClientEncryptionKey",gxold:"OV13ClientEncryptionKey",gxvar:"AV13ClientEncryptionKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV13ClientEncryptionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13ClientEncryptionKey=Value},v2c:function(){gx.fn.setControlValue("vCLIENTENCRYPTIONKEY",gx.O.AV13ClientEncryptionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13ClientEncryptionKey=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTENCRYPTIONKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 249 , function() {
   });
   GXValidFnc[250]={ id: 250, fld:"",grid:0};
   GXValidFnc[251]={ id: 251, fld:"GENERATEKEYGAMREMOTE",grid:0,evt:"e19102_client"};
   GXValidFnc[252]={ id: 252, fld:"",grid:0};
   GXValidFnc[253]={ id: 253, fld:"",grid:0};
   GXValidFnc[254]={ id: 254, fld:"",grid:0};
   GXValidFnc[255]={ id: 255, fld:"",grid:0};
   GXValidFnc[256]={ id:256 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTREPOSITORYGUID",fmt:0,gxz:"ZV17ClientRepositoryGUID",gxold:"OV17ClientRepositoryGUID",gxvar:"AV17ClientRepositoryGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV17ClientRepositoryGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17ClientRepositoryGUID=Value},v2c:function(){gx.fn.setControlValue("vCLIENTREPOSITORYGUID",gx.O.AV17ClientRepositoryGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV17ClientRepositoryGUID=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTREPOSITORYGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 256 , function() {
   });
   GXValidFnc[258]={ id: 258, fld:"SSOREST_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[259]={ id: 259, fld:"",grid:0};
   GXValidFnc[261]={ id: 261, fld:"SSORESTTABLE1",grid:0};
   GXValidFnc[262]={ id: 262, fld:"",grid:0};
   GXValidFnc[263]={ id: 263, fld:"",grid:0};
   GXValidFnc[264]={ id: 264, fld:"",grid:0};
   GXValidFnc[265]={ id: 265, fld:"",grid:0};
   GXValidFnc[266]={ id:266 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e27101_client',evt_cvcing:null,rgrid:[],fld:"vSSORESTENABLE",fmt:0,gxz:"ZV62SSORestEnable",gxold:"OV62SSORestEnable",gxvar:"AV62SSORestEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV62SSORestEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV62SSORestEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vSSORESTENABLE",gx.O.AV62SSORestEnable,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV62SSORestEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vSSORESTENABLE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 266 , function() {
   });
   GXValidFnc[267]={ id: 267, fld:"",grid:0};
   GXValidFnc[268]={ id: 268, fld:"",grid:0};
   GXValidFnc[269]={ id: 269, fld:"TABLESSOREST",grid:0};
   GXValidFnc[270]={ id: 270, fld:"",grid:0};
   GXValidFnc[271]={ id: 271, fld:"",grid:0};
   GXValidFnc[272]={ id: 272, fld:"",grid:0};
   GXValidFnc[273]={ id: 273, fld:"",grid:0};
   GXValidFnc[274]={ id:274 ,lvl:0,type:"char",len:10,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Ssorestmode,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSSORESTMODE",fmt:0,gxz:"ZV63SSORestMode",gxold:"OV63SSORestMode",gxvar:"AV63SSORestMode",ucs:[],op:[274],ip:[274],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV63SSORestMode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV63SSORestMode=Value},v2c:function(){gx.fn.setComboBoxValue("vSSORESTMODE",gx.O.AV63SSORestMode);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV63SSORestMode=this.val()},val:function(){return gx.fn.getControlValue("vSSORESTMODE")},nac:gx.falseFn,evt:"e15101_client"};
   this.declareDomainHdlr( 274 , function() {
   });
   GXValidFnc[275]={ id: 275, fld:"",grid:0};
   GXValidFnc[276]={ id: 276, fld:"",grid:0};
   GXValidFnc[277]={ id: 277, fld:"TBLSSORESTMODECLIENT",grid:0};
   GXValidFnc[278]={ id: 278, fld:"",grid:0};
   GXValidFnc[279]={ id: 279, fld:"",grid:0};
   GXValidFnc[280]={ id: 280, fld:"",grid:0};
   GXValidFnc[281]={ id: 281, fld:"",grid:0};
   GXValidFnc[282]={ id:282 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSSORESTUSERAUTHTYPENAME",fmt:0,gxz:"ZV65SSORestUserAuthTypeName",gxold:"OV65SSORestUserAuthTypeName",gxvar:"AV65SSORestUserAuthTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV65SSORestUserAuthTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV65SSORestUserAuthTypeName=Value},v2c:function(){gx.fn.setComboBoxValue("vSSORESTUSERAUTHTYPENAME",gx.O.AV65SSORestUserAuthTypeName);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV65SSORestUserAuthTypeName=this.val()},val:function(){return gx.fn.getControlValue("vSSORESTUSERAUTHTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 282 , function() {
   });
   GXValidFnc[283]={ id: 283, fld:"",grid:0};
   GXValidFnc[284]={ id: 284, fld:"",grid:0};
   GXValidFnc[285]={ id: 285, fld:"",grid:0};
   GXValidFnc[286]={ id: 286, fld:"",grid:0};
   GXValidFnc[287]={ id:287 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSSORESTSERVERURL",fmt:0,gxz:"ZV64SSORestServerURL",gxold:"OV64SSORestServerURL",gxvar:"AV64SSORestServerURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV64SSORestServerURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV64SSORestServerURL=Value},v2c:function(){gx.fn.setControlValue("vSSORESTSERVERURL",gx.O.AV64SSORestServerURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV64SSORestServerURL=this.val()},val:function(){return gx.fn.getControlValue("vSSORESTSERVERURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 287 , function() {
   });
   GXValidFnc[289]={ id: 289, fld:"STS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[290]={ id: 290, fld:"",grid:0};
   GXValidFnc[292]={ id: 292, fld:"STSTABLE1",grid:0};
   GXValidFnc[293]={ id: 293, fld:"",grid:0};
   GXValidFnc[294]={ id: 294, fld:"",grid:0};
   GXValidFnc[295]={ id: 295, fld:"",grid:0};
   GXValidFnc[296]={ id: 296, fld:"",grid:0};
   GXValidFnc[297]={ id:297 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSPROTOCOLENABLE",fmt:0,gxz:"ZV46STSProtocolEnable",gxold:"OV46STSProtocolEnable",gxvar:"AV46STSProtocolEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV46STSProtocolEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV46STSProtocolEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vSTSPROTOCOLENABLE",gx.O.AV46STSProtocolEnable,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV46STSProtocolEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vSTSPROTOCOLENABLE")},nac:gx.falseFn,evt:"e25101_client",values:['true','false']};
   GXValidFnc[298]={ id: 298, fld:"",grid:0};
   GXValidFnc[299]={ id: 299, fld:"",grid:0};
   GXValidFnc[300]={ id: 300, fld:"TABLESTS",grid:0};
   GXValidFnc[301]={ id: 301, fld:"",grid:0};
   GXValidFnc[302]={ id: 302, fld:"",grid:0};
   GXValidFnc[303]={ id: 303, fld:"",grid:0};
   GXValidFnc[304]={ id: 304, fld:"",grid:0};
   GXValidFnc[305]={ id:305 ,lvl:0,type:"char",len:10,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Stsmode,isvalid:null,evt_cvc:'e26101_client',evt_cvcing:null,rgrid:[],fld:"vSTSMODE",fmt:0,gxz:"ZV48STSMode",gxold:"OV48STSMode",gxvar:"AV48STSMode",ucs:[],op:[305],ip:[305],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV48STSMode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV48STSMode=Value},v2c:function(){gx.fn.setComboBoxValue("vSTSMODE",gx.O.AV48STSMode);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV48STSMode=this.val()},val:function(){return gx.fn.getControlValue("vSTSMODE")},nac:gx.falseFn};
   this.declareDomainHdlr( 305 , function() {
   });
   GXValidFnc[306]={ id: 306, fld:"",grid:0};
   GXValidFnc[307]={ id: 307, fld:"",grid:0};
   GXValidFnc[308]={ id: 308, fld:"TABLESTSSERVERCHECKTOKEN",grid:0};
   GXValidFnc[309]={ id: 309, fld:"",grid:0};
   GXValidFnc[310]={ id: 310, fld:"",grid:0};
   GXValidFnc[311]={ id: 311, fld:"",grid:0};
   GXValidFnc[312]={ id: 312, fld:"",grid:0};
   GXValidFnc[313]={ id:313 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSAUTHORIZATIONUSERNAME",fmt:0,gxz:"ZV45STSAuthorizationUserName",gxold:"OV45STSAuthorizationUserName",gxvar:"AV45STSAuthorizationUserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV45STSAuthorizationUserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV45STSAuthorizationUserName=Value},v2c:function(){gx.fn.setControlValue("vSTSAUTHORIZATIONUSERNAME",gx.O.AV45STSAuthorizationUserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV45STSAuthorizationUserName=this.val()},val:function(){return gx.fn.getControlValue("vSTSAUTHORIZATIONUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 313 , function() {
   });
   GXValidFnc[314]={ id: 314, fld:"",grid:0};
   GXValidFnc[315]={ id: 315, fld:"",grid:0};
   GXValidFnc[316]={ id: 316, fld:"",grid:0};
   GXValidFnc[317]={ id:317 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSAUTHORIZATIONUSERGUID",fmt:0,gxz:"ZV44STSAuthorizationUserGUID",gxold:"OV44STSAuthorizationUserGUID",gxvar:"AV44STSAuthorizationUserGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV44STSAuthorizationUserGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV44STSAuthorizationUserGUID=Value},v2c:function(){gx.fn.setControlValue("vSTSAUTHORIZATIONUSERGUID",gx.O.AV44STSAuthorizationUserGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV44STSAuthorizationUserGUID=this.val()},val:function(){return gx.fn.getControlValue("vSTSAUTHORIZATIONUSERGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 317 , function() {
   });
   GXValidFnc[318]={ id: 318, fld:"",grid:0};
   GXValidFnc[319]={ id: 319, fld:"",grid:0};
   GXValidFnc[320]={ id: 320, fld:"TABLESTSCLIENTGETTOKEN",grid:0};
   GXValidFnc[321]={ id: 321, fld:"",grid:0};
   GXValidFnc[322]={ id: 322, fld:"",grid:0};
   GXValidFnc[323]={ id: 323, fld:"",grid:0};
   GXValidFnc[324]={ id: 324, fld:"",grid:0};
   GXValidFnc[325]={ id:325 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSSERVERCLIENTPASSWORD",fmt:0,gxz:"ZV47STSServerClientPassword",gxold:"OV47STSServerClientPassword",gxvar:"AV47STSServerClientPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV47STSServerClientPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV47STSServerClientPassword=Value},v2c:function(){gx.fn.setControlValue("vSTSSERVERCLIENTPASSWORD",gx.O.AV47STSServerClientPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV47STSServerClientPassword=this.val()},val:function(){return gx.fn.getControlValue("vSTSSERVERCLIENTPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 325 , function() {
   });
   GXValidFnc[326]={ id: 326, fld:"",grid:0};
   GXValidFnc[327]={ id: 327, fld:"",grid:0};
   GXValidFnc[328]={ id: 328, fld:"TABLESTSCLIENT",grid:0};
   GXValidFnc[329]={ id: 329, fld:"",grid:0};
   GXValidFnc[330]={ id: 330, fld:"",grid:0};
   GXValidFnc[331]={ id: 331, fld:"",grid:0};
   GXValidFnc[332]={ id: 332, fld:"",grid:0};
   GXValidFnc[333]={ id:333 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSSERVERURL",fmt:0,gxz:"ZV50STSServerURL",gxold:"OV50STSServerURL",gxvar:"AV50STSServerURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV50STSServerURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV50STSServerURL=Value},v2c:function(){gx.fn.setControlValue("vSTSSERVERURL",gx.O.AV50STSServerURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV50STSServerURL=this.val()},val:function(){return gx.fn.getControlValue("vSTSSERVERURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 333 , function() {
   });
   GXValidFnc[334]={ id: 334, fld:"",grid:0};
   GXValidFnc[335]={ id: 335, fld:"",grid:0};
   GXValidFnc[336]={ id: 336, fld:"",grid:0};
   GXValidFnc[337]={ id: 337, fld:"",grid:0};
   GXValidFnc[338]={ id:338 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSSERVERREPOSITORYGUID",fmt:0,gxz:"ZV49STSServerRepositoryGUID",gxold:"OV49STSServerRepositoryGUID",gxvar:"AV49STSServerRepositoryGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV49STSServerRepositoryGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV49STSServerRepositoryGUID=Value},v2c:function(){gx.fn.setControlValue("vSTSSERVERREPOSITORYGUID",gx.O.AV49STSServerRepositoryGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV49STSServerRepositoryGUID=this.val()},val:function(){return gx.fn.getControlValue("vSTSSERVERREPOSITORYGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 338 , function() {
   });
   GXValidFnc[340]={ id: 340, fld:"ENVIRONMENT_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[341]={ id: 341, fld:"",grid:0};
   GXValidFnc[343]={ id: 343, fld:"ENVIRONMENTTABLE1",grid:0};
   GXValidFnc[344]={ id: 344, fld:"",grid:0};
   GXValidFnc[345]={ id: 345, fld:"",grid:0};
   GXValidFnc[346]={ id: 346, fld:"",grid:0};
   GXValidFnc[347]={ id: 347, fld:"",grid:0};
   GXValidFnc[348]={ id:348 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTNAME",fmt:0,gxz:"ZV26EnvironmentName",gxold:"OV26EnvironmentName",gxvar:"AV26EnvironmentName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV26EnvironmentName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV26EnvironmentName=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTNAME",gx.O.AV26EnvironmentName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV26EnvironmentName=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 348 , function() {
   });
   GXValidFnc[349]={ id: 349, fld:"",grid:0};
   GXValidFnc[350]={ id: 350, fld:"",grid:0};
   GXValidFnc[351]={ id: 351, fld:"",grid:0};
   GXValidFnc[352]={ id: 352, fld:"",grid:0};
   GXValidFnc[353]={ id:353 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTSECUREPROTOCOL",fmt:0,gxz:"ZV30EnvironmentSecureProtocol",gxold:"OV30EnvironmentSecureProtocol",gxvar:"AV30EnvironmentSecureProtocol",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV30EnvironmentSecureProtocol=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV30EnvironmentSecureProtocol=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vENVIRONMENTSECUREPROTOCOL",gx.O.AV30EnvironmentSecureProtocol,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV30EnvironmentSecureProtocol=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vENVIRONMENTSECUREPROTOCOL")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[354]={ id: 354, fld:"",grid:0};
   GXValidFnc[355]={ id: 355, fld:"",grid:0};
   GXValidFnc[356]={ id: 356, fld:"",grid:0};
   GXValidFnc[357]={ id: 357, fld:"",grid:0};
   GXValidFnc[358]={ id:358 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTHOST",fmt:0,gxz:"ZV25EnvironmentHost",gxold:"OV25EnvironmentHost",gxvar:"AV25EnvironmentHost",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25EnvironmentHost=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25EnvironmentHost=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTHOST",gx.O.AV25EnvironmentHost,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25EnvironmentHost=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTHOST")},nac:gx.falseFn};
   this.declareDomainHdlr( 358 , function() {
   });
   GXValidFnc[359]={ id: 359, fld:"",grid:0};
   GXValidFnc[360]={ id: 360, fld:"",grid:0};
   GXValidFnc[361]={ id: 361, fld:"",grid:0};
   GXValidFnc[362]={ id: 362, fld:"",grid:0};
   GXValidFnc[363]={ id:363 ,lvl:0,type:"int",len:5,dec:0,sign:false,pic:"ZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTPORT",fmt:0,gxz:"ZV27EnvironmentPort",gxold:"OV27EnvironmentPort",gxvar:"AV27EnvironmentPort",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV27EnvironmentPort=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV27EnvironmentPort=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vENVIRONMENTPORT",gx.O.AV27EnvironmentPort,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV27EnvironmentPort=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vENVIRONMENTPORT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[364]={ id: 364, fld:"",grid:0};
   GXValidFnc[365]={ id: 365, fld:"",grid:0};
   GXValidFnc[366]={ id: 366, fld:"",grid:0};
   GXValidFnc[367]={ id: 367, fld:"",grid:0};
   GXValidFnc[368]={ id:368 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTVIRTUALDIRECTORY",fmt:0,gxz:"ZV31EnvironmentVirtualDirectory",gxold:"OV31EnvironmentVirtualDirectory",gxvar:"AV31EnvironmentVirtualDirectory",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV31EnvironmentVirtualDirectory=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV31EnvironmentVirtualDirectory=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTVIRTUALDIRECTORY",gx.O.AV31EnvironmentVirtualDirectory,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV31EnvironmentVirtualDirectory=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTVIRTUALDIRECTORY")},nac:gx.falseFn};
   this.declareDomainHdlr( 368 , function() {
   });
   GXValidFnc[369]={ id: 369, fld:"",grid:0};
   GXValidFnc[370]={ id: 370, fld:"",grid:0};
   GXValidFnc[371]={ id: 371, fld:"",grid:0};
   GXValidFnc[372]={ id: 372, fld:"",grid:0};
   GXValidFnc[373]={ id:373 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTPROGRAMPACKAGE",fmt:0,gxz:"ZV29EnvironmentProgramPackage",gxold:"OV29EnvironmentProgramPackage",gxvar:"AV29EnvironmentProgramPackage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV29EnvironmentProgramPackage=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29EnvironmentProgramPackage=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTPROGRAMPACKAGE",gx.O.AV29EnvironmentProgramPackage,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV29EnvironmentProgramPackage=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTPROGRAMPACKAGE")},nac:gx.falseFn};
   this.declareDomainHdlr( 373 , function() {
   });
   GXValidFnc[374]={ id: 374, fld:"",grid:0};
   GXValidFnc[375]={ id: 375, fld:"",grid:0};
   GXValidFnc[376]={ id: 376, fld:"",grid:0};
   GXValidFnc[377]={ id: 377, fld:"",grid:0};
   GXValidFnc[378]={ id:378 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTPROGRAMEXTENSION",fmt:0,gxz:"ZV28EnvironmentProgramExtension",gxold:"OV28EnvironmentProgramExtension",gxvar:"AV28EnvironmentProgramExtension",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV28EnvironmentProgramExtension=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV28EnvironmentProgramExtension=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTPROGRAMEXTENSION",gx.O.AV28EnvironmentProgramExtension,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV28EnvironmentProgramExtension=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTPROGRAMEXTENSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 378 , function() {
   });
   GXValidFnc[379]={ id: 379, fld:"",grid:0};
   GXValidFnc[380]={ id: 380, fld:"",grid:0};
   GXValidFnc[382]={ id: 382, fld:"",grid:0};
   GXValidFnc[383]={ id: 383, fld:"",grid:0};
   GXValidFnc[384]={ id: 384, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[385]={ id: 385, fld:"",grid:0};
   GXValidFnc[386]={ id: 386, fld:"",grid:0};
   GXValidFnc[387]={ id: 387, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[388]={ id: 388, fld:"",grid:0};
   GXValidFnc[389]={ id: 389, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e18102_client"};
   GXValidFnc[390]={ id: 390, fld:"",grid:0};
   GXValidFnc[391]={ id: 391, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e17102_client"};
   this.AV37Id = 0 ;
   this.ZV37Id = 0 ;
   this.OV37Id = 0 ;
   this.AV35GUID = "" ;
   this.ZV35GUID = "" ;
   this.OV35GUID = "" ;
   this.AV43Name = "" ;
   this.ZV43Name = "" ;
   this.OV43Name = "" ;
   this.AV22Dsc = "" ;
   this.ZV22Dsc = "" ;
   this.OV22Dsc = "" ;
   this.AV54Version = "" ;
   this.ZV54Version = "" ;
   this.OV54Version = "" ;
   this.AV20Company = "" ;
   this.ZV20Company = "" ;
   this.OV20Company = "" ;
   this.AV21Copyright = "" ;
   this.ZV21Copyright = "" ;
   this.OV21Copyright = "" ;
   this.AV51UseAbsoluteUrlByEnvironment = false ;
   this.ZV51UseAbsoluteUrlByEnvironment = false ;
   this.OV51UseAbsoluteUrlByEnvironment = false ;
   this.AV36HomeObject = "" ;
   this.ZV36HomeObject = "" ;
   this.OV36HomeObject = "" ;
   this.AV68AccountActivationObject = "" ;
   this.ZV68AccountActivationObject = "" ;
   this.OV68AccountActivationObject = "" ;
   this.AV39LogoutObject = "" ;
   this.ZV39LogoutObject = "" ;
   this.OV39LogoutObject = "" ;
   this.AV40MainMenu = 0 ;
   this.ZV40MainMenu = 0 ;
   this.OV40MainMenu = 0 ;
   this.AV5AccessRequiresPermission = false ;
   this.ZV5AccessRequiresPermission = false ;
   this.OV5AccessRequiresPermission = false ;
   this.AV18ClientRevoked = gx.date.nullDate() ;
   this.ZV18ClientRevoked = gx.date.nullDate() ;
   this.OV18ClientRevoked = gx.date.nullDate() ;
   this.AV14ClientId = "" ;
   this.ZV14ClientId = "" ;
   this.OV14ClientId = "" ;
   this.AV19ClientSecret = "" ;
   this.ZV19ClientSecret = "" ;
   this.OV19ClientSecret = "" ;
   this.AV8ClientAccessUniqueByUser = false ;
   this.ZV8ClientAccessUniqueByUser = false ;
   this.OV8ClientAccessUniqueByUser = false ;
   this.AV11ClientAllowRemoteAuth = false ;
   this.ZV11ClientAllowRemoteAuth = false ;
   this.OV11ClientAllowRemoteAuth = false ;
   this.AV10ClientAllowGetUserRoles = false ;
   this.ZV10ClientAllowGetUserRoles = false ;
   this.OV10ClientAllowGetUserRoles = false ;
   this.AV9ClientAllowGetUserAddData = false ;
   this.ZV9ClientAllowGetUserAddData = false ;
   this.OV9ClientAllowGetUserAddData = false ;
   this.AV57ClientAllowGetSessionIniProp = false ;
   this.ZV57ClientAllowGetSessionIniProp = false ;
   this.OV57ClientAllowGetSessionIniProp = false ;
   this.AV15ClientImageURL = "" ;
   this.ZV15ClientImageURL = "" ;
   this.OV15ClientImageURL = "" ;
   this.AV16ClientLocalLoginURL = "" ;
   this.ZV16ClientLocalLoginURL = "" ;
   this.OV16ClientLocalLoginURL = "" ;
   this.AV12ClientCallbackURL = "" ;
   this.ZV12ClientCallbackURL = "" ;
   this.OV12ClientCallbackURL = "" ;
   this.AV66ClientCallbackURLisCustom = false ;
   this.ZV66ClientCallbackURLisCustom = false ;
   this.OV66ClientCallbackURLisCustom = false ;
   this.AV67ClientCallbackURLStateName = "" ;
   this.ZV67ClientCallbackURLStateName = "" ;
   this.OV67ClientCallbackURLStateName = "" ;
   this.AV61ClientAllowRemoteRestAuth = false ;
   this.ZV61ClientAllowRemoteRestAuth = false ;
   this.OV61ClientAllowRemoteRestAuth = false ;
   this.AV60ClientAllowGetUserRolesRest = false ;
   this.ZV60ClientAllowGetUserRolesRest = false ;
   this.OV60ClientAllowGetUserRolesRest = false ;
   this.AV59ClientAllowGetUserAddDataRest = false ;
   this.ZV59ClientAllowGetUserAddDataRest = false ;
   this.OV59ClientAllowGetUserAddDataRest = false ;
   this.AV58ClientAllowGetSessionIniPropRest = false ;
   this.ZV58ClientAllowGetSessionIniPropRest = false ;
   this.OV58ClientAllowGetSessionIniPropRest = false ;
   this.AV13ClientEncryptionKey = "" ;
   this.ZV13ClientEncryptionKey = "" ;
   this.OV13ClientEncryptionKey = "" ;
   this.AV17ClientRepositoryGUID = "" ;
   this.ZV17ClientRepositoryGUID = "" ;
   this.OV17ClientRepositoryGUID = "" ;
   this.AV62SSORestEnable = false ;
   this.ZV62SSORestEnable = false ;
   this.OV62SSORestEnable = false ;
   this.AV63SSORestMode = "" ;
   this.ZV63SSORestMode = "" ;
   this.OV63SSORestMode = "" ;
   this.AV65SSORestUserAuthTypeName = "" ;
   this.ZV65SSORestUserAuthTypeName = "" ;
   this.OV65SSORestUserAuthTypeName = "" ;
   this.AV64SSORestServerURL = "" ;
   this.ZV64SSORestServerURL = "" ;
   this.OV64SSORestServerURL = "" ;
   this.AV46STSProtocolEnable = false ;
   this.ZV46STSProtocolEnable = false ;
   this.OV46STSProtocolEnable = false ;
   this.AV48STSMode = "" ;
   this.ZV48STSMode = "" ;
   this.OV48STSMode = "" ;
   this.AV45STSAuthorizationUserName = "" ;
   this.ZV45STSAuthorizationUserName = "" ;
   this.OV45STSAuthorizationUserName = "" ;
   this.AV44STSAuthorizationUserGUID = "" ;
   this.ZV44STSAuthorizationUserGUID = "" ;
   this.OV44STSAuthorizationUserGUID = "" ;
   this.AV47STSServerClientPassword = "" ;
   this.ZV47STSServerClientPassword = "" ;
   this.OV47STSServerClientPassword = "" ;
   this.AV50STSServerURL = "" ;
   this.ZV50STSServerURL = "" ;
   this.OV50STSServerURL = "" ;
   this.AV49STSServerRepositoryGUID = "" ;
   this.ZV49STSServerRepositoryGUID = "" ;
   this.OV49STSServerRepositoryGUID = "" ;
   this.AV26EnvironmentName = "" ;
   this.ZV26EnvironmentName = "" ;
   this.OV26EnvironmentName = "" ;
   this.AV30EnvironmentSecureProtocol = false ;
   this.ZV30EnvironmentSecureProtocol = false ;
   this.OV30EnvironmentSecureProtocol = false ;
   this.AV25EnvironmentHost = "" ;
   this.ZV25EnvironmentHost = "" ;
   this.OV25EnvironmentHost = "" ;
   this.AV27EnvironmentPort = 0 ;
   this.ZV27EnvironmentPort = 0 ;
   this.OV27EnvironmentPort = 0 ;
   this.AV31EnvironmentVirtualDirectory = "" ;
   this.ZV31EnvironmentVirtualDirectory = "" ;
   this.OV31EnvironmentVirtualDirectory = "" ;
   this.AV29EnvironmentProgramPackage = "" ;
   this.ZV29EnvironmentProgramPackage = "" ;
   this.OV29EnvironmentProgramPackage = "" ;
   this.AV28EnvironmentProgramExtension = "" ;
   this.ZV28EnvironmentProgramExtension = "" ;
   this.OV28EnvironmentProgramExtension = "" ;
   this.AV37Id = 0 ;
   this.AV35GUID = "" ;
   this.AV43Name = "" ;
   this.AV22Dsc = "" ;
   this.AV54Version = "" ;
   this.AV20Company = "" ;
   this.AV21Copyright = "" ;
   this.AV51UseAbsoluteUrlByEnvironment = false ;
   this.AV36HomeObject = "" ;
   this.AV68AccountActivationObject = "" ;
   this.AV39LogoutObject = "" ;
   this.AV40MainMenu = 0 ;
   this.AV5AccessRequiresPermission = false ;
   this.AV18ClientRevoked = gx.date.nullDate() ;
   this.AV14ClientId = "" ;
   this.AV19ClientSecret = "" ;
   this.AV8ClientAccessUniqueByUser = false ;
   this.AV11ClientAllowRemoteAuth = false ;
   this.AV10ClientAllowGetUserRoles = false ;
   this.AV9ClientAllowGetUserAddData = false ;
   this.AV57ClientAllowGetSessionIniProp = false ;
   this.AV15ClientImageURL = "" ;
   this.AV16ClientLocalLoginURL = "" ;
   this.AV12ClientCallbackURL = "" ;
   this.AV66ClientCallbackURLisCustom = false ;
   this.AV67ClientCallbackURLStateName = "" ;
   this.AV61ClientAllowRemoteRestAuth = false ;
   this.AV60ClientAllowGetUserRolesRest = false ;
   this.AV59ClientAllowGetUserAddDataRest = false ;
   this.AV58ClientAllowGetSessionIniPropRest = false ;
   this.AV13ClientEncryptionKey = "" ;
   this.AV17ClientRepositoryGUID = "" ;
   this.AV62SSORestEnable = false ;
   this.AV63SSORestMode = "" ;
   this.AV65SSORestUserAuthTypeName = "" ;
   this.AV64SSORestServerURL = "" ;
   this.AV46STSProtocolEnable = false ;
   this.AV48STSMode = "" ;
   this.AV45STSAuthorizationUserName = "" ;
   this.AV44STSAuthorizationUserGUID = "" ;
   this.AV47STSServerClientPassword = "" ;
   this.AV50STSServerURL = "" ;
   this.AV49STSServerRepositoryGUID = "" ;
   this.AV26EnvironmentName = "" ;
   this.AV30EnvironmentSecureProtocol = false ;
   this.AV25EnvironmentHost = "" ;
   this.AV27EnvironmentPort = 0 ;
   this.AV31EnvironmentVirtualDirectory = "" ;
   this.AV29EnvironmentProgramPackage = "" ;
   this.AV28EnvironmentProgramExtension = "" ;
   this.Gx_mode = "" ;
   this.Events = {"e17102_client": ["'CONFIRM'", true] ,"e18102_client": ["'CANCEL'", true] ,"e19102_client": ["'GENERATEKEYGAMREMOTE'", true] ,"e20102_client": ["'REVOKE-AUTHORIZE'", true] ,"e28102_client": ["ENTER", true] ,"e29102_client": ["CANCEL", true] ,"e22101_client": ["GAM_HEADERENTRY_TABLEBACK.CLICK", false] ,"e23101_client": ["VCLIENTALLOWREMOTEAUTH.CLICK", false] ,"e24101_client": ["VCLIENTALLOWREMOTERESTAUTH.CLICK", false] ,"e12101_client": ["'DELETE'", false] ,"e13101_client": ["'PERMISSIONS'", false] ,"e14101_client": ["'MENUS'", false] ,"e11101_client": ["'EDIT'", false] ,"e15101_client": ["VSSORESTMODE.CLICK", false] ,"e25101_client": ["VSTSPROTOCOLENABLE.CLICK", false] ,"e26101_client": ["VSTSMODE.CONTROLVALUECHANGED", false] ,"e27101_client": ["VSSORESTENABLE.CONTROLVALUECHANGED", false]};
   this.EvtParms["REFRESH"] = [[{av:'AV51UseAbsoluteUrlByEnvironment',fld:'vUSEABSOLUTEURLBYENVIRONMENT',pic:''},{av:'AV5AccessRequiresPermission',fld:'vACCESSREQUIRESPERMISSION',pic:''},{av:'AV8ClientAccessUniqueByUser',fld:'vCLIENTACCESSUNIQUEBYUSER',pic:''},{av:'AV11ClientAllowRemoteAuth',fld:'vCLIENTALLOWREMOTEAUTH',pic:''},{av:'AV10ClientAllowGetUserRoles',fld:'vCLIENTALLOWGETUSERROLES',pic:''},{av:'AV9ClientAllowGetUserAddData',fld:'vCLIENTALLOWGETUSERADDDATA',pic:''},{av:'AV57ClientAllowGetSessionIniProp',fld:'vCLIENTALLOWGETSESSIONINIPROP',pic:''},{av:'AV66ClientCallbackURLisCustom',fld:'vCLIENTCALLBACKURLISCUSTOM',pic:''},{av:'AV61ClientAllowRemoteRestAuth',fld:'vCLIENTALLOWREMOTERESTAUTH',pic:''},{av:'AV60ClientAllowGetUserRolesRest',fld:'vCLIENTALLOWGETUSERROLESREST',pic:''},{av:'AV59ClientAllowGetUserAddDataRest',fld:'vCLIENTALLOWGETUSERADDDATAREST',pic:''},{av:'AV58ClientAllowGetSessionIniPropRest',fld:'vCLIENTALLOWGETSESSIONINIPROPREST',pic:''},{av:'AV62SSORestEnable',fld:'vSSORESTENABLE',pic:''},{av:'AV46STSProtocolEnable',fld:'vSTSPROTOCOLENABLE',pic:''},{av:'AV30EnvironmentSecureProtocol',fld:'vENVIRONMENTSECUREPROTOCOL',pic:''},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true}],[]];
   this.EvtParms["'CONFIRM'"] = [[{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV43Name',fld:'vNAME',pic:''},{av:'AV22Dsc',fld:'vDSC',pic:''},{av:'AV54Version',fld:'vVERSION',pic:''},{av:'AV21Copyright',fld:'vCOPYRIGHT',pic:''},{av:'AV20Company',fld:'vCOMPANY',pic:''},{av:'AV51UseAbsoluteUrlByEnvironment',fld:'vUSEABSOLUTEURLBYENVIRONMENT',pic:''},{av:'AV36HomeObject',fld:'vHOMEOBJECT',pic:''},{av:'AV68AccountActivationObject',fld:'vACCOUNTACTIVATIONOBJECT',pic:''},{av:'AV39LogoutObject',fld:'vLOGOUTOBJECT',pic:''},{ctrl:'vMAINMENU'},{av:'AV40MainMenu',fld:'vMAINMENU',pic:'ZZZZZZZZZZZ9'},{av:'AV5AccessRequiresPermission',fld:'vACCESSREQUIRESPERMISSION',pic:''},{av:'AV14ClientId',fld:'vCLIENTID',pic:''},{av:'AV19ClientSecret',fld:'vCLIENTSECRET',pic:''},{av:'AV8ClientAccessUniqueByUser',fld:'vCLIENTACCESSUNIQUEBYUSER',pic:''},{av:'AV11ClientAllowRemoteAuth',fld:'vCLIENTALLOWREMOTEAUTH',pic:''},{av:'AV10ClientAllowGetUserRoles',fld:'vCLIENTALLOWGETUSERROLES',pic:''},{av:'AV9ClientAllowGetUserAddData',fld:'vCLIENTALLOWGETUSERADDDATA',pic:''},{av:'AV57ClientAllowGetSessionIniProp',fld:'vCLIENTALLOWGETSESSIONINIPROP',pic:''},{av:'AV16ClientLocalLoginURL',fld:'vCLIENTLOCALLOGINURL',pic:''},{av:'AV12ClientCallbackURL',fld:'vCLIENTCALLBACKURL',pic:''},{av:'AV66ClientCallbackURLisCustom',fld:'vCLIENTCALLBACKURLISCUSTOM',pic:''},{av:'AV67ClientCallbackURLStateName',fld:'vCLIENTCALLBACKURLSTATENAME',pic:''},{av:'AV15ClientImageURL',fld:'vCLIENTIMAGEURL',pic:''},{av:'AV61ClientAllowRemoteRestAuth',fld:'vCLIENTALLOWREMOTERESTAUTH',pic:''},{av:'AV60ClientAllowGetUserRolesRest',fld:'vCLIENTALLOWGETUSERROLESREST',pic:''},{av:'AV59ClientAllowGetUserAddDataRest',fld:'vCLIENTALLOWGETUSERADDDATAREST',pic:''},{av:'AV58ClientAllowGetSessionIniPropRest',fld:'vCLIENTALLOWGETSESSIONINIPROPREST',pic:''},{av:'AV13ClientEncryptionKey',fld:'vCLIENTENCRYPTIONKEY',pic:''},{av:'AV17ClientRepositoryGUID',fld:'vCLIENTREPOSITORYGUID',pic:''},{av:'AV62SSORestEnable',fld:'vSSORESTENABLE',pic:''},{ctrl:'vSSORESTMODE'},{av:'AV63SSORestMode',fld:'vSSORESTMODE',pic:''},{ctrl:'vSSORESTUSERAUTHTYPENAME'},{av:'AV65SSORestUserAuthTypeName',fld:'vSSORESTUSERAUTHTYPENAME',pic:''},{av:'AV64SSORestServerURL',fld:'vSSORESTSERVERURL',pic:''},{av:'AV46STSProtocolEnable',fld:'vSTSPROTOCOLENABLE',pic:''},{av:'AV45STSAuthorizationUserName',fld:'vSTSAUTHORIZATIONUSERNAME',pic:''},{av:'AV44STSAuthorizationUserGUID',fld:'vSTSAUTHORIZATIONUSERGUID',pic:''},{ctrl:'vSTSMODE'},{av:'AV48STSMode',fld:'vSTSMODE',pic:''},{av:'AV50STSServerURL',fld:'vSTSSERVERURL',pic:''},{av:'AV47STSServerClientPassword',fld:'vSTSSERVERCLIENTPASSWORD',pic:''},{av:'AV49STSServerRepositoryGUID',fld:'vSTSSERVERREPOSITORYGUID',pic:''},{av:'AV26EnvironmentName',fld:'vENVIRONMENTNAME',pic:''},{av:'AV30EnvironmentSecureProtocol',fld:'vENVIRONMENTSECUREPROTOCOL',pic:''},{av:'AV25EnvironmentHost',fld:'vENVIRONMENTHOST',pic:''},{av:'AV27EnvironmentPort',fld:'vENVIRONMENTPORT',pic:'ZZZZ9'},{av:'AV31EnvironmentVirtualDirectory',fld:'vENVIRONMENTVIRTUALDIRECTORY',pic:''},{av:'AV29EnvironmentProgramPackage',fld:'vENVIRONMENTPROGRAMPACKAGE',pic:''},{av:'AV28EnvironmentProgramExtension',fld:'vENVIRONMENTPROGRAMEXTENSION',pic:''}],[{av:'AV44STSAuthorizationUserGUID',fld:'vSTSAUTHORIZATIONUSERGUID',pic:''},{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'CANCEL'"] = [[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true}],[]];
   this.EvtParms["GAM_HEADERENTRY_TABLEBACK.CLICK"] = [[],[]];
   this.EvtParms["VCLIENTALLOWREMOTEAUTH.CLICK"] = [[{av:'AV11ClientAllowRemoteAuth',fld:'vCLIENTALLOWREMOTEAUTH',pic:''},{av:'AV61ClientAllowRemoteRestAuth',fld:'vCLIENTALLOWREMOTERESTAUTH',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLGENERALAUTH","Visible")',ctrl:'TBLGENERALAUTH',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLWEBAUTH","Visible")',ctrl:'TBLWEBAUTH',prop:'Visible'}]];
   this.EvtParms["VCLIENTALLOWREMOTERESTAUTH.CLICK"] = [[{av:'AV61ClientAllowRemoteRestAuth',fld:'vCLIENTALLOWREMOTERESTAUTH',pic:''},{av:'AV11ClientAllowRemoteAuth',fld:'vCLIENTALLOWREMOTEAUTH',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLGENERALAUTH","Visible")',ctrl:'TBLGENERALAUTH',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLRESTAUTH","Visible")',ctrl:'TBLRESTAUTH',prop:'Visible'}]];
   this.EvtParms["'GENERATEKEYGAMREMOTE'"] = [[],[{av:'AV13ClientEncryptionKey',fld:'vCLIENTENCRYPTIONKEY',pic:''}]];
   this.EvtParms["'REVOKE-AUTHORIZE'"] = [[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'gx.fn.getCtrlProperty("GAM_HEADERENTRY_TXTSTATUS","Caption")',ctrl:'GAM_HEADERENTRY_TXTSTATUS',prop:'Caption'},{av:'gx.fn.getCtrlProperty("GAM_HEADERENTRY_TXTSTATUS","Class")',ctrl:'GAM_HEADERENTRY_TXTSTATUS',prop:'Class'},{av:'gx.fn.getCtrlProperty("BUTTONREVOKE","Caption")',ctrl:'BUTTONREVOKE',prop:'Caption'},{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'DELETE'"] = [[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'PERMISSIONS'"] = [[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'MENUS'"] = [[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'EDIT'"] = [[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV37Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VSSORESTMODE.CLICK"] = [[{av:'AV62SSORestEnable',fld:'vSSORESTENABLE',pic:''},{ctrl:'vSSORESTMODE'},{av:'AV63SSORestMode',fld:'vSSORESTMODE',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLSSORESTMODECLIENT","Visible")',ctrl:'TBLSSORESTMODECLIENT',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESSOREST","Visible")',ctrl:'TABLESSOREST',prop:'Visible'}]];
   this.EvtParms["VSTSPROTOCOLENABLE.CLICK"] = [[{av:'AV46STSProtocolEnable',fld:'vSTSPROTOCOLENABLE',pic:''},{ctrl:'vSTSMODE'},{av:'AV48STSMode',fld:'vSTSMODE',pic:''}],[{av:'gx.fn.getCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible")',ctrl:'TABLESTSSERVERCHECKTOKEN',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible")',ctrl:'TABLESTSCLIENTGETTOKEN',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTSCLIENT","Visible")',ctrl:'TABLESTSCLIENT',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTS","Visible")',ctrl:'TABLESTS',prop:'Visible'}]];
   this.EvtParms["VSTSMODE.CONTROLVALUECHANGED"] = [[{ctrl:'vSTSMODE'},{av:'AV48STSMode',fld:'vSTSMODE',pic:''}],[{av:'gx.fn.getCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible")',ctrl:'TABLESTSSERVERCHECKTOKEN',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible")',ctrl:'TABLESTSCLIENTGETTOKEN',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESTSCLIENT","Visible")',ctrl:'TABLESTSCLIENT',prop:'Visible'}]];
   this.EvtParms["VSSORESTENABLE.CONTROLVALUECHANGED"] = [[{av:'AV62SSORestEnable',fld:'vSSORESTENABLE',pic:''},{ctrl:'vSSORESTMODE'},{av:'AV63SSORestMode',fld:'vSSORESTMODE',pic:''}],[{av:'gx.fn.getCtrlProperty("TBLSSORESTMODECLIENT","Visible")',ctrl:'TBLSSORESTMODECLIENT',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLESSOREST","Visible")',ctrl:'TABLESSOREST',prop:'Visible'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_CLIENTREVOKED"] = [[],[]];
   this.EvtParms["VALIDV_SSORESTMODE"] = [[],[]];
   this.EvtParms["VALIDV_STSMODE"] = [[],[]];
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0381" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_applicationentry);});
