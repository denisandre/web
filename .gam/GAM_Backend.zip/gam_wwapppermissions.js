/*
               File: GAM_WWAppPermissions
        Description: Application permissions
             Author: GeneXus .NET Generator version 18_0_4-173650
       Generated on: 7/1/2023 0:33:10.48
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwapppermissions', false, function () {
   this.ServerClass =  "gam_wwapppermissions" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwapppermissions.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV8ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.Validv_Accesstype=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(34);
      return this.validCliEvt("Validv_Accesstype", 34, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vACCESSTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV5AccessType , "A" ) == 0 || gx.text.compare( this.AV5AccessType , "R" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Default Access"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Permissionaccesstypedefault=function()
   {
      return this.validCliEvt("Validv_Permissionaccesstypedefault", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vPERMISSIONACCESSTYPEDEFAULT");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV19PermissionAccessTypeDefault , "A" ) == 0 || gx.text.compare( this.AV19PermissionAccessTypeDefault , "R" ) == 0 || (gx.text.compare('',this.AV19PermissionAccessTypeDefault)==0) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Permission Access Type Default"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Permissiontypefilter=function()
   {
      return this.validCliEvt("Validv_Permissiontypefilter", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vPERMISSIONTYPEFILTER");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV20PermissionTypeFilter , "A" ) == 0 || gx.text.compare( this.AV20PermissionTypeFilter , "F" ) == 0 || gx.text.compare( this.AV20PermissionTypeFilter , "P" ) == 0 || gx.text.compare( this.AV20PermissionTypeFilter , "C" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Permission Type Filter"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Isautomaticpermission=function()
   {
      return this.validCliEvt("Validv_Isautomaticpermission", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vISAUTOMATICPERMISSION");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV16isAutomaticPermission , "A" ) == 0 || gx.text.compare( this.AV16isAutomaticPermission , "T" ) == 0 || gx.text.compare( this.AV16isAutomaticPermission , "F" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "is Automatic Permission"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e111c1_client=function()
   {
      /* 'AddNew' Routine */
      this.clearMessages();
      this.call("gam_apppermissionentry.aspx", ["INS", this.AV8ApplicationId, ""], null, ["Mode","ApplicationId","GUID"]);
      this.refreshOutputs([{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e141c1_client=function()
   {
      /* 'Apply' Routine */
      this.clearMessages();
      this.refreshOutputs([]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e131c1_client=function()
   {
      /* 'ClearFilters' Routine */
      this.clearMessages();
      this.AV19PermissionAccessTypeDefault =  ''  ;
      this.AV20PermissionTypeFilter =  ''  ;
      this.AV16isAutomaticPermission =  ''  ;
      this.refreshOutputs([{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e121c1_client=function()
   {
      /* 'Hide' Routine */
      this.clearMessages();
      if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
      {
         gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
         gx.fn.setCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "Hide filters") );
      }
      else
      {
         gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
         gx.fn.setCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "Show filters") );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'},{av:'gx.fn.getCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext")',ctrl:'GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS',prop:'Tooltiptext'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e211c2_client=function()
   {
      /* Name_Click Routine */
      this.clearMessages();
      this.call("gam_apppermissionentry.aspx", ["DSP", this.AV8ApplicationId, this.AV15Id], null, ["Mode","ApplicationId","GUID"]);
      this.refreshOutputs([{av:'AV15Id',fld:'vID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e221c2_client=function()
   {
      /* Btnupd_Click Routine */
      this.clearMessages();
      this.call("gam_apppermissionentry.aspx", ["UPD", this.AV8ApplicationId, this.AV15Id], null, ["Mode","ApplicationId","GUID"]);
      this.refreshOutputs([{av:'AV15Id',fld:'vID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e231c2_client=function()
   {
      /* Btndlt_Click Routine */
      this.clearMessages();
      this.call("gam_apppermissionentry.aspx", ["DLT", this.AV8ApplicationId, this.AV15Id], null, ["Mode","ApplicationId","GUID"]);
      this.refreshOutputs([{av:'AV15Id',fld:'vID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e241c1_client=function()
   {
      /* Gam_headerwwbackfilters_tableback_Click Routine */
      this.clearMessages();
      this.call("gam_applicationentry.aspx", ["DSP", this.AV8ApplicationId], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e251c1_client=function()
   {
      /* Search_Controlvaluechanged Routine */
      this.clearMessages();
      this.refreshOutputs([]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e181c1_client=function()
   {
      /* 'First' Routine */
      this.clearMessages();
      this.AV25CurrentPage = gx.num.trunc( 1 ,0) ;
      this.refreshOutputs([{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e191c1_client=function()
   {
      /* 'Previous' Routine */
      this.clearMessages();
      this.AV25CurrentPage = gx.num.trunc( this.AV25CurrentPage - 1 ,0) ;
      this.refreshOutputs([{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e201c1_client=function()
   {
      /* 'Next' Routine */
      this.clearMessages();
      this.AV25CurrentPage = gx.num.trunc( this.AV25CurrentPage + 1 ,0) ;
      this.refreshOutputs([{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e171c2_client=function()
   {
      /* Btnchildrens_Click Routine */
      return this.executeServerEvent("VBTNCHILDRENS.CLICK", true, arguments[0], false, false);
   };
   this.e261c2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e271c2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,35,36,37,38,39,40,41,42,43,44,45,46,47,48,51,53,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86];
   this.GXLastCtrlId =86;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",34,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwapppermissions",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",35,"vNAME",gx.getMessage( "Permission name"),"","Name","char",0,"px",120,80,"start","e211c2_client",[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Dsc",36,"vDSC",gx.getMessage( "Description"),"","Dsc","char",0,"px",254,80,"start",null,[],"Dsc","Dsc",true,0,false,false,"Attribute",0,"column column-optional");
   GridwwContainer.addComboBox("Accesstype",37,"vACCESSTYPE",gx.getMessage( "Default Access"),"AccessType","char",null,0,true,false,130,"px","column column-optional");
   GridwwContainer.addCheckBox("Isparent",38,"vISPARENT",gx.getMessage( "Is Parent"),"","IsParent","boolean","true","false",null,true,false,100,"px","column column-optional");
   GridwwContainer.addSingleLineEdit("Btnchildrens",39,"vBTNCHILDRENS","","","BtnChildrens","char",100,"px",20,20,"start","e171c2_client",[],"Btnchildrens","BtnChildrens",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btnupd",40,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"start","e221c2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btndlt",41,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"start","e231c2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Id",42,"vID",gx.getMessage( "GUID"),"","Id","char",0,"px",40,40,"start",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWBACKFILTERS",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWBACKFILTERS_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERWWBACKFILTERS_TABLEBACK",grid:0,evt:"e241c1_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERWWBACKFILTERS_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWWBACKFILTERS_TABLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERWWBACKFILTERS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERWWBACKFILTERS_ADDNEW",grid:0,evt:"e111c1_client"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e251c1_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV29Search",gxold:"OV29Search",gxvar:"AV29Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV29Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV29Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV29Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"SECTIONGRID",grid:0};
   GXValidFnc[31]={ id: 31, fld:"GRIDTABLE",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV18Name",gxold:"OV18Name",gxvar:"AV18Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV18Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(34),gx.O.AV18Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV18Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn,evt:"e211c2_client"};
   GXValidFnc[36]={ id:36 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV11Dsc",gxold:"OV11Dsc",gxvar:"AV11Dsc",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Dsc=Value},v2c:function(row){gx.fn.setGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(34),gx.O.AV11Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11Dsc=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn};
   GXValidFnc[37]={ id:37 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:this.Validv_Accesstype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCESSTYPE",fmt:0,gxz:"ZV5AccessType",gxold:"OV5AccessType",gxvar:"AV5AccessType",ucs:[],op:[37],ip:[37],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV5AccessType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5AccessType=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(34),gx.O.AV5AccessType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5AccessType=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn};
   GXValidFnc[38]={ id:38 ,lvl:2,type:"boolean",len:4,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vISPARENT",fmt:0,gxz:"ZV17IsParent",gxold:"OV17IsParent",gxvar:"AV17IsParent",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV17IsParent=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV17IsParent=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vISPARENT",row || gx.fn.currentGridRowImpl(34),gx.O.AV17IsParent,true)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17IsParent=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vISPARENT",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[39]={ id:39 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNCHILDRENS",fmt:0,gxz:"ZV22BtnChildrens",gxold:"OV22BtnChildrens",gxvar:"AV22BtnChildrens",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV22BtnChildrens=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV22BtnChildrens=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNCHILDRENS",row || gx.fn.currentGridRowImpl(34),gx.O.AV22BtnChildrens,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV22BtnChildrens=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNCHILDRENS",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn,evt:"e171c2_client"};
   GXValidFnc[40]={ id:40 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",fmt:0,gxz:"ZV10BtnUpd",gxold:"OV10BtnUpd",gxvar:"AV10BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV10BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(34),gx.O.AV10BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn,evt:"e221c2_client"};
   GXValidFnc[41]={ id:41 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV23BtnDlt",gxold:"OV23BtnDlt",gxvar:"AV23BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV23BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV23BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(34),gx.O.AV23BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV23BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn,evt:"e231c2_client"};
   GXValidFnc[42]={ id:42 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV15Id",gxold:"OV15Id",gxvar:"AV15Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV15Id=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15Id=Value},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(34),gx.O.AV15Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV15Id=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vID",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"GAM_PAGINGWW",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"GAM_PAGINGWW_TBLPAGINGBUTTONS",grid:0};
   GXValidFnc[51]={ id: 51, fld:"GAM_PAGINGWW_BTNFIRST",grid:0,evt:"e181c1_client"};
   GXValidFnc[53]={ id: 53, fld:"GAM_PAGINGWW_BTNPREVIOUS",grid:0,evt:"e191c1_client"};
   GXValidFnc[55]={ id: 55, fld:"GAM_PAGINGWW_BTNNEXT",grid:0,evt:"e201c1_client"};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id:59 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",fmt:0,gxz:"ZV25CurrentPage",gxold:"OV25CurrentPage",gxvar:"AV25CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV25CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV25CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV25CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[60]={ id: 60, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e121c1_client"};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id:71 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Permissionaccesstypedefault,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPERMISSIONACCESSTYPEDEFAULT",fmt:0,gxz:"ZV19PermissionAccessTypeDefault",gxold:"OV19PermissionAccessTypeDefault",gxvar:"AV19PermissionAccessTypeDefault",ucs:[],op:[71],ip:[71],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV19PermissionAccessTypeDefault=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19PermissionAccessTypeDefault=Value},v2c:function(){gx.fn.setComboBoxValue("vPERMISSIONACCESSTYPEDEFAULT",gx.O.AV19PermissionAccessTypeDefault);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV19PermissionAccessTypeDefault=this.val()},val:function(){return gx.fn.getControlValue("vPERMISSIONACCESSTYPEDEFAULT")},nac:gx.falseFn};
   this.declareDomainHdlr( 71 , function() {
   });
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id:76 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Permissiontypefilter,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPERMISSIONTYPEFILTER",fmt:0,gxz:"ZV20PermissionTypeFilter",gxold:"OV20PermissionTypeFilter",gxvar:"AV20PermissionTypeFilter",ucs:[],op:[76],ip:[76],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV20PermissionTypeFilter=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20PermissionTypeFilter=Value},v2c:function(){gx.fn.setComboBoxValue("vPERMISSIONTYPEFILTER",gx.O.AV20PermissionTypeFilter);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20PermissionTypeFilter=this.val()},val:function(){return gx.fn.getControlValue("vPERMISSIONTYPEFILTER")},nac:gx.falseFn};
   this.declareDomainHdlr( 76 , function() {
   });
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id:81 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Isautomaticpermission,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vISAUTOMATICPERMISSION",fmt:0,gxz:"ZV16isAutomaticPermission",gxold:"OV16isAutomaticPermission",gxvar:"AV16isAutomaticPermission",ucs:[],op:[81],ip:[81],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV16isAutomaticPermission=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16isAutomaticPermission=Value},v2c:function(){gx.fn.setComboBoxValue("vISAUTOMATICPERMISSION",gx.O.AV16isAutomaticPermission);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16isAutomaticPermission=this.val()},val:function(){return gx.fn.getControlValue("vISAUTOMATICPERMISSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 81 , function() {
   });
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id: 84, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e131c1_client"};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e141c1_client"};
   this.AV29Search = "" ;
   this.ZV29Search = "" ;
   this.OV29Search = "" ;
   this.ZV18Name = "" ;
   this.OV18Name = "" ;
   this.ZV11Dsc = "" ;
   this.OV11Dsc = "" ;
   this.ZV5AccessType = "" ;
   this.OV5AccessType = "" ;
   this.ZV17IsParent = false ;
   this.OV17IsParent = false ;
   this.ZV22BtnChildrens = "" ;
   this.OV22BtnChildrens = "" ;
   this.ZV10BtnUpd = "" ;
   this.OV10BtnUpd = "" ;
   this.ZV23BtnDlt = "" ;
   this.OV23BtnDlt = "" ;
   this.ZV15Id = "" ;
   this.OV15Id = "" ;
   this.AV25CurrentPage = 0 ;
   this.ZV25CurrentPage = 0 ;
   this.OV25CurrentPage = 0 ;
   this.AV19PermissionAccessTypeDefault = "" ;
   this.ZV19PermissionAccessTypeDefault = "" ;
   this.OV19PermissionAccessTypeDefault = "" ;
   this.AV20PermissionTypeFilter = "" ;
   this.ZV20PermissionTypeFilter = "" ;
   this.OV20PermissionTypeFilter = "" ;
   this.AV16isAutomaticPermission = "" ;
   this.ZV16isAutomaticPermission = "" ;
   this.OV16isAutomaticPermission = "" ;
   this.AV29Search = "" ;
   this.AV25CurrentPage = 0 ;
   this.AV19PermissionAccessTypeDefault = "" ;
   this.AV20PermissionTypeFilter = "" ;
   this.AV16isAutomaticPermission = "" ;
   this.AV8ApplicationId = 0 ;
   this.AV18Name = "" ;
   this.AV11Dsc = "" ;
   this.AV5AccessType = "" ;
   this.AV17IsParent = false ;
   this.AV22BtnChildrens = "" ;
   this.AV10BtnUpd = "" ;
   this.AV23BtnDlt = "" ;
   this.AV15Id = "" ;
   this.Events = {"e171c2_client": ["VBTNCHILDRENS.CLICK", true] ,"e261c2_client": ["ENTER", true] ,"e271c2_client": ["CANCEL", true] ,"e111c1_client": ["'ADDNEW'", false] ,"e141c1_client": ["'APPLY'", false] ,"e131c1_client": ["'CLEARFILTERS'", false] ,"e121c1_client": ["'HIDE'", false] ,"e211c2_client": ["VNAME.CLICK", false] ,"e221c2_client": ["VBTNUPD.CLICK", false] ,"e231c2_client": ["VBTNDLT.CLICK", false] ,"e241c1_client": ["GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK", false] ,"e251c1_client": ["VSEARCH.CONTROLVALUECHANGED", false] ,"e181c1_client": ["'FIRST'", false] ,"e191c1_client": ["'PREVIOUS'", false] ,"e201c1_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[{av:'gx.fn.getCtrlProperty("GAM_HEADERWWBACKFILTERS_TITLE","Caption")',ctrl:'GAM_HEADERWWBACKFILTERS_TITLE',prop:'Caption'},{av:'AV10BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV23BtnDlt',fld:'vBTNDLT',pic:''},{av:'AV22BtnChildrens',fld:'vBTNCHILDRENS',pic:''},{av:'AV15Id',fld:'vID',pic:''},{av:'AV18Name',fld:'vNAME',pic:''},{av:'AV11Dsc',fld:'vDSC',pic:''},{ctrl:'vACCESSTYPE'},{av:'AV5AccessType',fld:'vACCESSTYPE',pic:''},{av:'AV17IsParent',fld:'vISPARENT',pic:''},{ctrl:'GAM_PAGINGWW_BTNNEXT',prop:'Enabled'},{ctrl:'GAM_PAGINGWW_BTNFIRST',prop:'Enabled'},{ctrl:'GAM_PAGINGWW_BTNPREVIOUS',prop:'Enabled'}]];
   this.EvtParms["'ADDNEW'"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'APPLY'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[]];
   this.EvtParms["'CLEARFILTERS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}]];
   this.EvtParms["'HIDE'"] = [[{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'}],[{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'},{av:'gx.fn.getCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext")',ctrl:'GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS',prop:'Tooltiptext'}]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15Id',fld:'vID',pic:''}],[{av:'AV15Id',fld:'vID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15Id',fld:'vID',pic:''}],[{av:'AV15Id',fld:'vID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15Id',fld:'vID',pic:''}],[{av:'AV15Id',fld:'vID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNCHILDRENS.CLICK"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15Id',fld:'vID',pic:''}],[{av:'AV15Id',fld:'vID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[]];
   this.EvtParms["'FIRST'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["'PREVIOUS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["'NEXT'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV25CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV29Search',fld:'vSEARCH',pic:''},{ctrl:'vPERMISSIONACCESSTYPEDEFAULT'},{av:'AV19PermissionAccessTypeDefault',fld:'vPERMISSIONACCESSTYPEDEFAULT',pic:''},{ctrl:'vPERMISSIONTYPEFILTER'},{av:'AV20PermissionTypeFilter',fld:'vPERMISSIONTYPEFILTER',pic:''},{ctrl:'vISAUTOMATICPERMISSION'},{av:'AV16isAutomaticPermission',fld:'vISAUTOMATICPERMISSION',pic:''},{av:'subGridww_Recordcount'}],[]];
   this.EvtParms["VALIDV_PERMISSIONACCESSTYPEDEFAULT"] = [[],[]];
   this.EvtParms["VALIDV_PERMISSIONTYPEFILTER"] = [[],[]];
   this.EvtParms["VALIDV_ISAUTOMATICPERMISSION"] = [[],[]];
   this.EvtParms["VALIDV_ACCESSTYPE"] = [[{ctrl:'vACCESSTYPE'},{av:'AV5AccessType',fld:'vACCESSTYPE',pic:''}],[{ctrl:'vACCESSTYPE'},{av:'AV5AccessType',fld:'vACCESSTYPE',pic:''}]];
   this.setVCMap("AV8ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV8ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV8ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV8ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV8ApplicationId"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[59]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[25]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[71]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[76]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[81]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV8ApplicationId"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[59]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[25]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[71]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[76]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[81]);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_wwapppermissions);});
