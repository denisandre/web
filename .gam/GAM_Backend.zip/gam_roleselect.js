/*
               File: GAM_RoleSelect
        Description: Select child roles
             Author: GeneXus .NET Generator version 18_0_4-173650
       Generated on: 7/1/2023 0:33:22.63
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_roleselect', false, function () {
   this.ServerClass =  "gam_roleselect" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_roleselect.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV19RoleIdAux=gx.fn.getIntegerValue("vROLEIDAUX",gx.thousandSeparator) ;
      this.AV15isOK=gx.fn.getControlValue("vISOK") ;
      this.AV18RoleId=gx.fn.getIntegerValue("vROLEID",gx.thousandSeparator) ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.s112_client=function()
   {
      /* 'SHOWMESSAGES' Routine */
      this.createWebComponent('Wcmessages','GAM_Messages',[]);
   };
   this.e131n1_client=function()
   {
      /* 'Apply' Routine */
      this.clearMessages();
      this.refreshOutputs([]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e121n1_client=function()
   {
      /* 'ClearFilters' Routine */
      this.clearMessages();
      this.AV23FilRoleGUID =  ''  ;
      this.AV10FilExternalId =  ''  ;
      this.refreshOutputs([{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e111n1_client=function()
   {
      /* 'Hide' Routine */
      this.clearMessages();
      if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
      {
         gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
         gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "Hide filters") );
      }
      else
      {
         gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
         gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "Show filters") );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'},{av:'gx.fn.getCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext")',ctrl:'GAM_HEADERWW_TOGGLEFILTERS',prop:'Tooltiptext'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e181n1_client=function()
   {
      /* 'First' Routine */
      this.clearMessages();
      this.AV7CurrentPage = gx.num.trunc( 1 ,0) ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e191n1_client=function()
   {
      /* 'Previous' Routine */
      this.clearMessages();
      this.AV7CurrentPage = gx.num.trunc( this.AV7CurrentPage - 1 ,0) ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e201n1_client=function()
   {
      /* 'Next' Routine */
      this.clearMessages();
      this.AV7CurrentPage = gx.num.trunc( this.AV7CurrentPage + 1 ,0) ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e141n2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e151n2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e211n2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e221n2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,37,39,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,71,72,73,74,75,76,77,78,79,80];
   this.GXLastCtrlId =80;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",25,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_roleselect",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,true,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addCheckBox("Select",26,"vSELECT",gx.getMessage( "Select"),"","Select","boolean","true","false",null,true,false,60,"px","column");
   GridwwContainer.addSingleLineEdit("Name",27,"vNAME",gx.getMessage( "Role"),"","Name","char",0,"px",254,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Id",28,"vID",gx.getMessage( "Key Numeric Long"),"","Id","int",0,"px",12,12,"end",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWW",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWW_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_HEADERWW_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_HEADERWW_ADDNEW",grid:0,evt:"e231n1_client"};
   GXValidFnc[14]={ id: 14, fld:"CELLSEARCH",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV27Search",gxold:"OV27Search",gxvar:"AV27Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV27Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV27Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV27Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV27Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWW_TOGGLEFILTERS",grid:0,evt:"e111n1_client"};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"SECTION1",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GRIDTABLE",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"boolean",len:4,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSELECT",fmt:0,gxz:"ZV22Select",gxold:"OV22Select",gxvar:"AV22Select",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV22Select=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV22Select=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vSELECT",row || gx.fn.currentGridRowImpl(25),gx.O.AV22Select,true)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV22Select=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vSELECT",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV16Name",gxold:"OV16Name",gxvar:"AV16Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV16Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25),gx.O.AV16Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV14Id",gxold:"OV14Id",gxvar:"AV14Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV14Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV14Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(25),gx.O.AV14Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV14Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(25),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"GAM_PAGINGWW",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"GAM_PAGINGWW_TBLPAGINGBUTTONS",grid:0};
   GXValidFnc[37]={ id: 37, fld:"GAM_PAGINGWW_BTNFIRST",grid:0,evt:"e181n1_client"};
   GXValidFnc[39]={ id: 39, fld:"GAM_PAGINGWW_BTNPREVIOUS",grid:0,evt:"e191n1_client"};
   GXValidFnc[41]={ id: 41, fld:"GAM_PAGINGWW_BTNNEXT",grid:0,evt:"e201n1_client"};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id:45 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",fmt:0,gxz:"ZV7CurrentPage",gxold:"OV7CurrentPage",gxvar:"AV7CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV7CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV7CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV7CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[46]={ id: 46, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e111n1_client"};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id:57 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILROLEGUID",fmt:0,gxz:"ZV23FilRoleGUID",gxold:"OV23FilRoleGUID",gxvar:"AV23FilRoleGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV23FilRoleGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV23FilRoleGUID=Value},v2c:function(){gx.fn.setControlValue("vFILROLEGUID",gx.O.AV23FilRoleGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV23FilRoleGUID=this.val()},val:function(){return gx.fn.getControlValue("vFILROLEGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 57 , function() {
   });
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id:62 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILEXTERNALID",fmt:0,gxz:"ZV10FilExternalId",gxold:"OV10FilExternalId",gxvar:"AV10FilExternalId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10FilExternalId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10FilExternalId=Value},v2c:function(){gx.fn.setControlValue("vFILEXTERNALID",gx.O.AV10FilExternalId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10FilExternalId=this.val()},val:function(){return gx.fn.getControlValue("vFILEXTERNALID")},nac:gx.falseFn};
   this.declareDomainHdlr( 62 , function() {
   });
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e121n1_client"};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e131n1_client"};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"GAM_FOOTERPOPUP",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"GAM_FOOTERPOPUP_TABLEBUTTONS",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"GAM_FOOTERPOPUP_BTNCANCEL",grid:0,evt:"e151n2_client"};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"GAM_FOOTERPOPUP_BTNCONFIRM",grid:0,evt:"e141n2_client"};
   this.AV27Search = "" ;
   this.ZV27Search = "" ;
   this.OV27Search = "" ;
   this.ZV22Select = false ;
   this.OV22Select = false ;
   this.ZV16Name = "" ;
   this.OV16Name = "" ;
   this.ZV14Id = 0 ;
   this.OV14Id = 0 ;
   this.AV7CurrentPage = 0 ;
   this.ZV7CurrentPage = 0 ;
   this.OV7CurrentPage = 0 ;
   this.AV23FilRoleGUID = "" ;
   this.ZV23FilRoleGUID = "" ;
   this.OV23FilRoleGUID = "" ;
   this.AV10FilExternalId = "" ;
   this.ZV10FilExternalId = "" ;
   this.OV10FilExternalId = "" ;
   this.AV27Search = "" ;
   this.AV7CurrentPage = 0 ;
   this.AV23FilRoleGUID = "" ;
   this.AV10FilExternalId = "" ;
   this.AV18RoleId = 0 ;
   this.AV19RoleIdAux = 0 ;
   this.AV22Select = false ;
   this.AV16Name = "" ;
   this.AV14Id = 0 ;
   this.AV15isOK = false ;
   this.Events = {"e141n2_client": ["'CONFIRM'", true] ,"e151n2_client": ["'CANCEL'", true] ,"e211n2_client": ["ENTER", true] ,"e221n2_client": ["CANCEL", true] ,"e131n1_client": ["'APPLY'", false] ,"e121n1_client": ["'CLEARFILTERS'", false] ,"e111n1_client": ["'HIDE'", false] ,"e181n1_client": ["'FIRST'", false] ,"e191n1_client": ["'PREVIOUS'", false] ,"e201n1_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV27Search',fld:'vSEARCH',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV18RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV27Search',fld:'vSEARCH',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}],[{ctrl:'FORM',prop:'Caption'},{av:'AV22Select',fld:'vSELECT',pic:''},{av:'AV14Id',fld:'vID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV16Name',fld:'vNAME',pic:''},{ctrl:'GAM_PAGINGWW_BTNNEXT',prop:'Enabled'},{ctrl:'GAM_PAGINGWW_BTNFIRST',prop:'Enabled'},{ctrl:'GAM_PAGINGWW_BTNPREVIOUS',prop:'Enabled'}]];
   this.EvtParms["'CONFIRM'"] = [[{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV22Select',fld:'vSELECT',grid:25,pic:''},{av:'GRIDWW_nFirstRecordOnPage'},{av:'nRC_GXsfl_25',ctrl:'GRIDWW',grid:25,prop:'GridRC',grid:25},{av:'AV14Id',fld:'vID',grid:25,pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV15isOK',fld:'vISOK',pic:''},{av:'AV18RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9',hsh:true}],[{av:'AV15isOK',fld:'vISOK',pic:''},{ctrl:'WCMESSAGES'}]];
   this.EvtParms["'CANCEL'"] = [[{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV18RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["'APPLY'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV27Search',fld:'vSEARCH',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV18RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["'CLEARFILTERS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV27Search',fld:'vSEARCH',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV18RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9',hsh:true}],[{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''}]];
   this.EvtParms["'HIDE'"] = [[{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'}],[{av:'gx.fn.getCtrlProperty("GAM_FILTERSWW","Class")',ctrl:'GAM_FILTERSWW',prop:'Class'},{av:'gx.fn.getCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext")',ctrl:'GAM_HEADERWW_TOGGLEFILTERS',prop:'Tooltiptext'}]];
   this.EvtParms["'FIRST'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV27Search',fld:'vSEARCH',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV18RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9',hsh:true}],[{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["'PREVIOUS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV27Search',fld:'vSEARCH',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV18RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9',hsh:true}],[{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["'NEXT'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV19RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV27Search',fld:'vSEARCH',pic:''},{av:'AV10FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV23FilRoleGUID',fld:'vFILROLEGUID',pic:''},{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'AV18RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9',hsh:true}],[{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV19RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   this.setVCMap("AV15isOK", "vISOK", 0, "boolean", 4, 0);
   this.setVCMap("AV18RoleId", "vROLEID", 0, "int", 12, 0);
   this.setVCMap("AV19RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   this.setVCMap("AV19RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   GridwwContainer.addRefreshingVar({rfrVar:"AV19RoleIdAux"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[62]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[57]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[45]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV18RoleId"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV19RoleIdAux"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[62]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[57]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[45]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV18RoleId"});
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0070" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_roleselect);});
